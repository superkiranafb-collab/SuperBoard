# SuperBoard Web - Next.js ERP Frontend

Modern React frontend for the SuperBoard ERP system built with Next.js 14, TypeScript, and Tailwind CSS.

## Features

- **Next.js 14 App Router**: Modern React framework with server components
- **TypeScript**: Full type safety across the codebase
- **Tailwind CSS**: Utility-first styling with custom design system
- **React Query**: Server state management with caching
- **Zustand**: Lightweight client state management
- **React Hook Form + Zod**: Form validation
- **Radix UI**: Accessible component primitives
- **Lucide React**: Beautiful icons

## Tech Stack

- **Framework**: Next.js 14.1+
- **Language**: TypeScript 5.3+
- **Styling**: Tailwind CSS 3.4+
- **State Management**: TanStack Query 5 + Zustand 4
- **Forms**: React Hook Form 7 + Zod 3
- **UI Components**: Radix UI + Custom components
- **Icons**: Lucide React
- **Notifications**: React Hot Toast

## Project Structure

```
src/
├── app/                    # Next.js App Router pages
│   ├── dashboard/          # Dashboard pages (protected)
│   ├── login/              # Authentication pages
│   ├── globals.css         # Global styles + CSS variables
│   ├── layout.tsx          # Root layout
│   ├── providers.tsx       # React Query + Toast providers
│   └── page.tsx            # Home page (redirects to dashboard)
├── components/
│   └── ui/                 # Reusable UI components
├── hooks/
│   └── use-api.ts          # React Query hooks for API
├── lib/
│   ├── api.ts              # Axios API client
│   └── utils.ts            # Utility functions
├── store/
│   └── auth.ts             # Zustand auth store
├── middleware.ts           # Next.js middleware
└── types/                  # TypeScript types
```

## Getting Started

### Prerequisites

- Node.js 18+
- pnpm (recommended) or npm/yarn
- Backend API running (see backend README)

### Installation

```bash
cd web
pnpm install
# or
npm install
```

### Environment Variables

Create `.env.local`:

```env
NEXT_PUBLIC_API_URL=http://localhost:8000/api/v1
```

### Development

```bash
pnpm dev
# or
npm run dev
```

Open http://localhost:3000

### Build

```bash
pnpm build
pnpm start
```

## API Integration

The API client (`src/lib/api.ts`) provides:

- Automatic token management (access + refresh)
- Request/response interceptors
- Type-safe methods for all endpoints
- Error handling with automatic logout on 401

### React Query Hooks

Pre-built hooks in `src/hooks/use-api.ts`:

```typescript
// Queries
const { data: products } = useProducts({ category: 'beverages' });
const { data: order } = useSalesOrder('SO-2024-001');

// Mutations
const createOrder = useCreateSalesOrder();
createOrder.mutate({ customerId: '...', lines: [...] });
```

## Authentication

The auth store (`src/store/auth.ts`) handles:

- Login/logout
- Token persistence (localStorage)
- Automatic token refresh
- Auth state synchronization

## UI Components

Base components in `src/components/ui/`:

- `Button` - Multiple variants (default, outline, ghost, destructive, success)
- `Input` - With label, error, helper text
- `Card` - Header, title, description, content, footer
- `Badge` - Status indicators with variants

## Design System

CSS variables in `globals.css` for theming:

- Light/dark mode support
- Primary, secondary, destructive, success, warning, info colors
- Consistent spacing, border radius, shadows
- Inter font family

## Adding New Pages

1. Create page in `src/app/[module]/page.tsx`
2. Add API hooks in `src/hooks/use-api.ts`
3. Add types in `src/types/`
4. Add navigation item in dashboard layout

## Testing

```bash
# Type checking
pnpm type-check

# Linting
pnpm lint

# Unit tests (when added)
pnpm test
```

## Deployment

### Vercel (Recommended)

1. Connect repository to Vercel
2. Set environment variables
3. Deploy

### Docker

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## Contributing

1. Follow existing code style
2. Add types for new features
3. Update documentation
4. Run lint and type-check before PR

## License

Proprietary - SuperBoard ERP