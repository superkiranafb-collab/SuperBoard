import { useQuery, useMutation, useQueryClient, QueryKey } from '@tanstack/react-query';
import { api } from '@/lib/api';

// Generic hooks
export function useApiQuery<T>(key: QueryKey, fetcher: () => Promise<T>, options?: { enabled?: boolean; staleTime?: number }) {
  return useQuery({
    queryKey: key,
    queryFn: fetcher,
    enabled: options?.enabled ?? true,
    staleTime: options?.staleTime ?? 60000,
  });
}

export function useApiMutation<TData, TVariables>(
  mutationFn: (variables: TVariables) => Promise<TData>,
  options?: {
    onSuccess?: (data: TData, variables: TVariables) => void;
    onError?: (error: Error, variables: TVariables) => void;
    invalidateKeys?: QueryKey[];
  }
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn,
    onSuccess: (data, variables) => {
      options?.onSuccess?.(data, variables);
      options?.invalidateKeys?.forEach((key) => {
        queryClient.invalidateQueries({ queryKey: key });
      });
    },
    onError: options?.onError,
  });
}

// Organization hooks
export function useOrganizations() {
  return useApiQuery(['organizations'], () => api.getOrganizations());
}

export function useOrganization(id: string) {
  return useApiQuery(['organizations', id], () => api.getOrganization(id), { enabled: !!id });
}

export function useCreateOrganization() {
  return useApiMutation(
    (data: unknown) => api.createOrganization(data),
    { invalidateKeys: [['organizations']] }
  );
}

export function useUpdateOrganization() {
  return useApiMutation(
    ({ id, data }: { id: string; data: unknown }) => api.updateOrganization(id, data),
    { invalidateKeys: [['organizations']] }
  );
}

// User hooks
export function useUsers(params?: Record<string, unknown>) {
  return useApiQuery(['users', params], () => api.getUsers(params));
}

export function useUser(id: string) {
  return useApiQuery(['users', id], () => api.getUser(id), { enabled: !!id });
}

export function useCreateUser() {
  return useApiMutation(
    (data: unknown) => api.createUser(data),
    { invalidateKeys: [['users']] }
  );
}

export function useUpdateUser() {
  return useApiMutation(
    ({ id, data }: { id: string; data: unknown }) => api.updateUser(id, data),
    { invalidateKeys: [['users']] }
  );
}

// Product hooks
export function useProducts(params?: Record<string, unknown>) {
  return useApiQuery(['products', params], () => api.getProducts(params));
}

export function useProduct(id: string) {
  return useApiQuery(['products', id], () => api.getProduct(id), { enabled: !!id });
}

export function useCreateProduct() {
  return useApiMutation(
    (data: unknown) => api.createProduct(data),
    { invalidateKeys: [['products']] }
  );
}

export function useUpdateProduct() {
  return useApiMutation(
    ({ id, data }: { id: string; data: unknown }) => api.updateProduct(id, data),
    { invalidateKeys: [['products']] }
  );
}

// Customer hooks
export function useCustomers(params?: Record<string, unknown>) {
  return useApiQuery(['customers', params], () => api.getCustomers(params));
}

export function useCustomer(id: string) {
  return useApiQuery(['customers', id], () => api.getCustomer(id), { enabled: !!id });
}

export function useCreateCustomer() {
  return useApiMutation(
    (data: unknown) => api.createCustomer(data),
    { invalidateKeys: [['customers']] }
  );
}

export function useUpdateCustomer() {
  return useApiMutation(
    ({ id, data }: { id: string; data: unknown }) => api.updateCustomer(id, data),
    { invalidateKeys: [['customers']] }
  );
}

// Sales Order hooks
export function useSalesOrders(params?: Record<string, unknown>) {
  return useApiQuery(['salesOrders', params], () => api.getSalesOrders(params));
}

export function useSalesOrder(id: string) {
  return useApiQuery(['salesOrders', id], () => api.getSalesOrder(id), { enabled: !!id });
}

export function useCreateSalesOrder() {
  return useApiMutation(
    (data: unknown) => api.createSalesOrder(data),
    { invalidateKeys: [['salesOrders']] }
  );
}

export function useUpdateSalesOrder() {
  return useApiMutation(
    ({ id, data }: { id: string; data: unknown }) => api.updateSalesOrder(id, data),
    { invalidateKeys: [['salesOrders']] }
  );
}

// Purchase Order hooks
export function usePurchaseOrders(params?: Record<string, unknown>) {
  return useApiQuery(['purchaseOrders', params], () => api.getPurchaseOrders(params));
}

export function useCreatePurchaseOrder() {
  return useApiMutation(
    (data: unknown) => api.createPurchaseOrder(data),
    { invalidateKeys: [['purchaseOrders']] }
  );
}

// Manufacturing hooks
export function useWorkOrders(params?: Record<string, unknown>) {
  return useApiQuery(['workOrders', params], () => api.getWorkOrders(params));
}

export function useWorkOrder(id: string) {
  return useApiQuery(['workOrders', id], () => api.getWorkOrder(id), { enabled: !!id });
}

export function useCreateWorkOrder() {
  return useApiMutation(
    (data: unknown) => api.createWorkOrder(data),
    { invalidateKeys: [['workOrders']] }
  );
}

export function useBOMs(params?: Record<string, unknown>) {
  return useApiQuery(['boms', params], () => api.getBOMs(params));
}

export function useCreateBOM() {
  return useApiMutation(
    (data: unknown) => api.createBOM(data),
    { invalidateKeys: [['boms']] }
  );
}

// Inventory hooks
export function useInventory(params?: Record<string, unknown>) {
  return useApiQuery(['inventory', params], () => api.getInventory(params));
}

export function useBatches(params?: Record<string, unknown>) {
  return useApiQuery(['batches', params], () => api.getBatches(params));
}

export function useMovements(params?: Record<string, unknown>) {
  return useApiQuery(['movements', params], () => api.getMovements(params));
}

// Finance hooks
export function useChartOfAccounts(params?: Record<string, unknown>) {
  return useApiQuery(['chartOfAccounts', params], () => api.getChartOfAccounts(params));
}

export function useJournalEntries(params?: Record<string, unknown>) {
  return useApiQuery(['journalEntries', params], () => api.getJournalEntries(params));
}

export function useCreateJournalEntry() {
  return useApiMutation(
    (data: unknown) => api.createJournalEntry(data),
    { invalidateKeys: [['journalEntries']] }
  );
}

export function useExpenseClaims(params?: Record<string, unknown>) {
  return useApiQuery(['expenseClaims', params], () => api.getExpenseClaims(params));
}

export function useCreateExpenseClaim() {
  return useApiMutation(
    (data: unknown) => api.createExpenseClaim(data),
    { invalidateKeys: [['expenseClaims']] }
  );
}

// HR hooks
export function useAttendance(params?: Record<string, unknown>) {
  return useApiQuery(['attendance', params], () => api.getAttendance(params));
}

export function useCreateAttendance() {
  return useApiMutation(
    (data: unknown) => api.createAttendance(data),
    { invalidateKeys: [['attendance']] }
  );
}

export function useLeaveApplications(params?: Record<string, unknown>) {
  return useApiQuery(['leaveApplications', params], () => api.getLeaveApplications(params));
}

export function useCreateLeaveApplication() {
  return useApiMutation(
    (data: unknown) => api.createLeaveApplication(data),
    { invalidateKeys: [['leaveApplications']] }
  );
}

// Logistics hooks
export function useDeliveryTrips(params?: Record<string, unknown>) {
  return useApiQuery(['deliveryTrips', params], () => api.getDeliveryTrips(params));
}

export function useVehicles(params?: Record<string, unknown>) {
  return useApiQuery(['vehicles', params], () => api.getVehicles(params));
}

export function useDrivers(params?: Record<string, unknown>) {
  return useApiQuery(['drivers', params], () => api.getDrivers(params));
}

// AI hooks
export function useChatWithAI() {
  return useApiMutation(
    ({ message, context }: { message: string; context?: unknown }) => api.chatWithAI(message, context),
  );
}

export function useMorningReport() {
  return useApiQuery(['morningReport'], () => api.getMorningReport());
}