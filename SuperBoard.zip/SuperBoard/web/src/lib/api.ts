import axios, { AxiosError, AxiosInstance, InternalAxiosRequestConfig } from 'axios';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

class ApiClient {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  private setupInterceptors() {
    // Request interceptor - add auth token
    this.client.interceptors.request.use(
      (config: InternalAxiosRequestConfig) => {
        if (typeof window !== 'undefined') {
          const token = localStorage.getItem('access_token');
          if (token) {
            config.headers.Authorization = `Bearer ${token}`;
          }
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor - handle token refresh
    this.client.interceptors.response.use(
      (response) => response,
      async (error: AxiosError) => {
        const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

        if (error.response?.status === 401 && !originalRequest._retry) {
          originalRequest._retry = true;

          try {
            const refreshToken = localStorage.getItem('refresh_token');
            if (refreshToken) {
              const response = await axios.post(`${API_BASE_URL}/auth/refresh`, {
                refresh_token: refreshToken,
              });

              const { access_token, refresh_token } = response.data;
              localStorage.setItem('access_token', access_token);
              localStorage.setItem('refresh_token', refresh_token);

              originalRequest.headers.Authorization = `Bearer ${access_token}`;
              return this.client(originalRequest);
            }
          } catch (refreshError) {
            // Refresh failed, redirect to login
            if (typeof window !== 'undefined') {
              localStorage.removeItem('access_token');
              localStorage.removeItem('refresh_token');
              window.location.href = '/login';
            }
          }
        }

        return Promise.reject(error);
      }
    );
  }

  // Generic methods
  async get<T>(url: string, params?: Record<string, unknown>) {
    const response = await this.client.get<T>(url, { params });
    return response.data;
  }

  async post<T>(url: string, data?: unknown) {
    const response = await this.client.post<T>(url, data);
    return response.data;
  }

  async put<T>(url: string, data?: unknown) {
    const response = await this.client.put<T>(url, data);
    return response.data;
  }

  async patch<T>(url: string, data?: unknown) {
    const response = await this.client.patch<T>(url, data);
    return response.data;
  }

  async delete<T>(url: string) {
    const response = await this.client.delete<T>(url);
    return response.data;
  }

  // Auth methods
  async login(username: string, password: string) {
    return this.post<{ access_token: string; refresh_token: string; user: unknown }>('/auth/login', {
      username,
      password,
    });
  }

  async refreshToken(refreshToken: string) {
    return this.post<{ access_token: string; refresh_token: string }>('/auth/refresh', {
      refresh_token: refreshToken,
    });
  }

  async logout() {
    return this.post('/auth/logout');
  }

  // Organization methods
  async getOrganizations() {
    return this.get('/organizations');
  }

  async getOrganization(id: string) {
    return this.get(`/organizations/${id}`);
  }

  async createOrganization(data: unknown) {
    return this.post('/organizations', data);
  }

  async updateOrganization(id: string, data: unknown) {
    return this.put(`/organizations/${id}`, data);
  }

  // User methods
  async getUsers(params?: Record<string, unknown>) {
    return this.get('/users', params);
  }

  async getUser(id: string) {
    return this.get(`/users/${id}`);
  }

  async createUser(data: unknown) {
    return this.post('/users', data);
  }

  async updateUser(id: string, data: unknown) {
    return this.put(`/users/${id}`, data);
  }

  // Product methods
  async getProducts(params?: Record<string, unknown>) {
    return this.get('/products', params);
  }

  async getProduct(id: string) {
    return this.get(`/products/${id}`);
  }

  async createProduct(data: unknown) {
    return this.post('/products', data);
  }

  async updateProduct(id: string, data: unknown) {
    return this.put(`/products/${id}`, data);
  }

  // Customer methods
  async getCustomers(params?: Record<string, unknown>) {
    return this.get('/customers', params);
  }

  async getCustomer(id: string) {
    return this.get(`/customers/${id}`);
  }

  async createCustomer(data: unknown) {
    return this.post('/customers', data);
  }

  async updateCustomer(id: string, data: unknown) {
    return this.put(`/customers/${id}`, data);
  }

  // Sales Order methods
  async getSalesOrders(params?: Record<string, unknown>) {
    return this.get('/sales/orders', params);
  }

  async getSalesOrder(id: string) {
    return this.get(`/sales/orders/${id}`);
  }

  async createSalesOrder(data: unknown) {
    return this.post('/sales/orders', data);
  }

  async updateSalesOrder(id: string, data: unknown) {
    return this.put(`/sales/orders/${id}`, data);
  }

  // Purchase Order methods
  async getPurchaseOrders(params?: Record<string, unknown>) {
    return this.get('/purchase/orders', params);
  }

  async getPurchaseOrder(id: string) {
    return this.get(`/purchase/orders/${id}`);
  }

  async createPurchaseOrder(data: unknown) {
    return this.post('/purchase/orders', data);
  }

  // Manufacturing methods
  async getWorkOrders(params?: Record<string, unknown>) {
    return this.get('/manufacturing/work-orders', params);
  }

  async getWorkOrder(id: string) {
    return this.get(`/manufacturing/work-orders/${id}`);
  }

  async createWorkOrder(data: unknown) {
    return this.post('/manufacturing/work-orders', data);
  }

  async updateWorkOrder(id: string, data: unknown) {
    return this.put(`/manufacturing/work-orders/${id}`, data);
  }

  async getBOMs(params?: Record<string, unknown>) {
    return this.get('/manufacturing/boms', params);
  }

  async getBOM(id: string) {
    return this.get(`/manufacturing/boms/${id}`);
  }

  async createBOM(data: unknown) {
    return this.post('/manufacturing/boms', data);
  }

  // Inventory methods
  async getInventory(params?: Record<string, unknown>) {
    return this.get('/inventory', params);
  }

  async getInventoryItem(id: string) {
    return this.get(`/inventory/${id}`);
  }

  async getBatches(params?: Record<string, unknown>) {
    return this.get('/inventory/batches', params);
  }

  async getMovements(params?: Record<string, unknown>) {
    return this.get('/inventory/movements', params);
  }

  // Finance methods
  async getChartOfAccounts(params?: Record<string, unknown>) {
    return this.get('/finance/chart-of-accounts', params);
  }

  async getJournalEntries(params?: Record<string, unknown>) {
    return this.get('/finance/journal-entries', params);
  }

  async createJournalEntry(data: unknown) {
    return this.post('/finance/journal-entries', data);
  }

  async getExpenseClaims(params?: Record<string, unknown>) {
    return this.get('/finance/expense-claims', params);
  }

  async createExpenseClaim(data: unknown) {
    return this.post('/finance/expense-claims', data);
  }

  // HR methods
  async getAttendance(params?: Record<string, unknown>) {
    return this.get('/hr/attendance', params);
  }

  async createAttendance(data: unknown) {
    return this.post('/hr/attendance', data);
  }

  async getLeaveApplications(params?: Record<string, unknown>) {
    return this.get('/hr/leave-applications', params);
  }

  async createLeaveApplication(data: unknown) {
    return this.post('/hr/leave-applications', data);
  }

  // Logistics methods
  async getDeliveryTrips(params?: Record<string, unknown>) {
    return this.get('/logistics/trips', params);
  }

  async getVehicles(params?: Record<string, unknown>) {
    return this.get('/logistics/vehicles', params);
  }

  async getDrivers(params?: Record<string, unknown>) {
    return this.get('/logistics/drivers', params);
  }

  // AI Assistant
  async chatWithAI(message: string, context?: unknown) {
    return this.post('/ai/chat', { message, context });
  }

  async getMorningReport() {
    return this.get('/ai/morning-report');
  }
}

export const api = new ApiClient();
export default api;