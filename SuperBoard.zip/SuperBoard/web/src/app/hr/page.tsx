'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Plus, Search, Filter, Calendar, Clock, UserCheck, UserX, FileText } from 'lucide-react';
import { cn, getStatusColor } from '@/lib/utils';

const mockAttendance = [
  { id: 'ATT-001', employee: 'John Doe', date: '2024-01-15', checkIn: '09:00', checkOut: '18:00', hours: 8.5, overtime: 0.5, status: 'Present' },
  { id: 'ATT-002', employee: 'Jane Smith', date: '2024-01-15', checkIn: '09:15', checkOut: '18:15', hours: 8.0, overtime: 0, status: 'Present' },
  { id: 'ATT-003', employee: 'Bob Wilson', date: '2024-01-15', checkIn: '08:55', checkOut: '17:55', hours: 8.0, overtime: 0, status: 'Present' },
  { id: 'ATT-004', employee: 'Alice Brown', date: '2024-01-15', checkIn: '-', checkOut: '-', hours: 0, overtime: 0, status: 'Absent' },
  { id: 'ATT-005', employee: 'Charlie Davis', date: '2024-01-15', checkIn: '09:30', checkOut: '18:30', hours: 8.0, overtime: 0, status: 'Late' },
];

const mockLeaveApplications = [
  { id: 'LA-001', employee: 'John Doe', type: 'Annual Leave', startDate: '2024-01-20', endDate: '2024-01-22', days: 3, status: 'Approved' },
  { id: 'LA-002', employee: 'Jane Smith', type: 'Sick Leave', startDate: '2024-01-18', endDate: '2024-01-19', days: 2, status: 'Pending' },
  { id: 'LA-003', employee: 'Bob Wilson', type: 'Casual Leave', startDate: '2024-01-25', endDate: '2024-01-25', days: 1, status: 'Pending' },
  { id: 'LA-004', employee: 'Alice Brown', type: 'Annual Leave', startDate: '2024-02-01', endDate: '2024-02-05', days: 5, status: 'Rejected' },
];

export default function HRPage() {
  const [activeTab, setActiveTab] = useState('attendance');
  const [search, setSearch] = useState('');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Human Resources</h1>
          <p className="text-muted-foreground">Manage attendance, leave, and employee records</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          {activeTab === 'attendance' ? 'Mark Attendance' : 'New Leave Request'}
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-muted p-1 rounded-lg">
        {[
          { id: 'attendance', label: 'Attendance', icon: Calendar },
          { id: 'leave', label: 'Leave Management', icon: FileText },
          { id: 'employees', label: 'Employees', icon: Users },
          { id: 'payroll', label: 'Payroll', icon: Clock },
        ].map((tab) => (
          <Button
            key={tab.id}
            variant={activeTab === tab.id ? 'default' : 'ghost'}
            size="sm"
            className="gap-2"
            onClick={() => setActiveTab(tab.id)}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </Button>
        ))}
      </div>

      {/* Attendance Stats */}
      {activeTab === 'attendance' && (
        <>
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Present Today</p>
                    <p className="mt-1 text-3xl font-bold">187</p>
                    <p className="mt-1 text-sm text-success">94.5% attendance</p>
                  </div>
                  <div className="rounded-lg bg-success/10 p-3">
                    <UserCheck className="h-6 w-6 text-success" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Absent Today</p>
                    <p className="mt-1 text-3xl font-bold">11</p>
                    <p className="mt-1 text-sm text-destructive">5.5% absent</p>
                  </div>
                  <div className="rounded-lg bg-destructive/10 p-3">
                    <UserX className="h-6 w-6 text-destructive" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Late Arrivals</p>
                    <p className="mt-1 text-3xl font-bold">8</p>
                    <p className="mt-1 text-sm text-warning">4.0% late</p>
                  </div>
                  <div className="rounded-lg bg-warning/10 p-3">
                    <Clock className="h-6 w-6 text-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Employees</p>
                    <p className="mt-1 text-3xl font-bold">198</p>
                    <p className="mt-1 text-sm text-success">+3 this month</p>
                  </div>
                  <div className="rounded-lg bg-info/10 p-3">
                    <Users className="h-6 w-6 text-info" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )

      {/* Leave Stats */}
      {activeTab === 'leave' && (
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Pending Approvals</p>
                  <p className="mt-1 text-3xl font-bold">12</p>
                  <p className="mt-1 text-sm text-warning">Action required</p>
                </div>
                <div className="rounded-lg bg-warning/10 p-3">
                  <FileText className="h-6 w-6 text-warning" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Approved This Month</p>
                  <p className="mt-1 text-3xl font-bold">45</p>
                  <p className="mt-1 text-sm text-success">+12 vs last month</p>
                </div>
                <div className="rounded-lg bg-success/10 p-3">
                  <UserCheck className="h-6 w-6 text-success" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Rejected This Month</p>
                  <p className="mt-1 text-3xl font-bold">3</p>
                  <p className="mt-1 text-sm text-destructive">Low rejection rate</p>
                </div>
                <div className="rounded-lg bg-destructive/10 p-3">
                  <UserX className="h-6 w-6 text-destructive" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Leave Balance (Avg)</p>
                  <p className="mt-1 text-3xl font-bold">14.5</p>
                  <p className="mt-1 text-sm text-muted-foreground">days per employee</p>
                </div>
                <div className="rounded-lg bg-info/10 p-3">
                  <Clock className="h-6 w-6 text-info" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={`Search ${activeTab === 'attendance' ? 'attendance' : 'leave applications'}...`}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <select className="flex h-10 w-40 items-center rounded-md border border-input bg-background px-3 py-2 text-sm">
                <option value="all">All Status</option>
                <option value="present">Present</option>
                <option value="absent">Absent</option>
                <option value="late">Late</option>
              </select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Attendance Table */}
      {activeTab === 'attendance' && (
        <Card>
          <CardContent className="pt-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                    <th className="p-4">Record ID</th>
                    <th className="p-4">Employee</th>
                    <th className="p-4">Date</th>
                    <th className="p-4">Check In</th>
                    <th className="p-4">Check Out</th>
                    <th className="p-4 text-right">Work Hours</th>
                    <th className="p-4 text-right">Overtime</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockAttendance
                    .filter((att) => 
                      att.employee.toLowerCase().includes(search.toLowerCase())
                    )
                    .map((att) => (
                      <tr key={att.id} className="border-b last:border-0 hover:bg-muted/50">
                        <td className="p-4 font-medium">{att.id}</td>
                        <td className="p-4">{att.employee}</td>
                        <td className="p-4">{att.date}</td>
                        <td className="p-4">{att.checkIn}</td>
                        <td className="p-4">{att.checkOut}</td>
                        <td className="p-4 text-right font-medium">{att.hours}h</td>
                        <td className="p-4 text-right text-warning">{att.overtime}h</td>
                        <td className="p-4">
                          <Badge variant="outline" className={getStatusColor(att.status)}>
                            {att.status}
                          </Badge>
                        </td>
                        <td className="p-4 text-right">
                          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                            <FileText className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Leave Applications Table */}
      {activeTab === 'leave' && (
        <Card>
          <CardContent className="pt-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                    <th className="p-4">Application ID</th>
                    <th className="p-4">Employee</th>
                    <th className="p-4">Leave Type</th>
                    <th className="p-4">Start Date</th>
                    <th className="p-4">End Date</th>
                    <th className="p-4 text-right">Days</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockLeaveApplications
                    .filter((la) => 
                      la.employee.toLowerCase().includes(search.toLowerCase()) ||
                      la.type.toLowerCase().includes(search.toLowerCase())
                    )
                    .map((la) => {
                      const statusColors: Record<string, string> = {
                        Pending: 'bg-warning/10 text-warning border-warning/20',
                        Approved: 'bg-success/10 text-success border-success/20',
                        Rejected: 'bg-destructive/10 text-destructive border-destructive/20',
                      };
                      return (
                        <tr key={la.id} className="border-b last:border-0 hover:bg-muted/50">
                          <td className="p-4 font-medium">{la.id}</td>
                          <td className="p-4">{la.employee}</td>
                          <td className="p-4">{la.type}</td>
                          <td className="p-4">{la.startDate}</td>
                          <td className="p-4">{la.endDate}</td>
                          <td className="p-4 text-right font-medium">{la.days} days</td>
                          <td className="p-4">
                            <Badge variant="outline" className={statusColors[la.status] || statusColors.Pending}>
                              {la.status}
                            </Badge>
                          </td>
                          <td className="p-4 text-right">
                            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                              <FileText className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Employees & Payroll Placeholders */}
      {(activeTab === 'employees' || activeTab === 'payroll') && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-12">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium">{activeTab === 'employees' ? 'Employee Directory' : 'Payroll Management'}</h3>
              <p className="text-muted-foreground mt-2">This feature is coming soon.</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}