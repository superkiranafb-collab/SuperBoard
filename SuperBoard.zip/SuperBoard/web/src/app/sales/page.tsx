'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Plus, Search, Filter, ChevronDown } from 'lucide-react';
import { cn, formatCurrency, getStatusColor } from '@/lib/utils';
import { useSalesOrders, useCreateSalesOrder } from '@/hooks/use-api';

const mockOrders = [
  { id: 'SO-2024-001', customer: 'Acme Corporation', status: 'Confirmed', amount: 45000, date: '2024-01-15', items: 3 },
  { id: 'SO-2024-002', customer: 'Global Traders', status: 'Shipped', amount: 125000, date: '2024-01-14', items: 5 },
  { id: 'SO-2024-003', customer: 'Metro Distributors', status: 'Delivered', amount: 78500, date: '2024-01-13', items: 2 },
  { id: 'SO-2024-004', customer: 'Quick Mart', status: 'Draft', amount: 32000, date: '2024-01-15', items: 4 },
  { id: 'SO-2024-005', customer: 'Super Retail', status: 'Cancelled', amount: 15000, date: '2024-01-12', items: 1 },
];

export default function SalesPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  
  const statuses = ['All', 'Draft', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Sales Orders</h1>
          <p className="text-muted-foreground">Manage your sales orders and quotations</p>
        </div>
        <Button onClick={() => {}} className="gap-2">
          <Plus className="h-4 w-4" />
          New Order
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search orders..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="flex h-10 w-40 items-center rounded-md border border-input bg-background px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                {statuses.map((status) => (
                  <option key={status} value={status}>
                    {status}
                  </option>
                ))}
              </select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Orders Table */}
      <Card>
        <CardContent className="pt-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                  <th className="p-4">Order Number</th>
                  <th className="p-4">Customer</th>
                  <th className="p-4">Items</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Amount</th>
                  <th className="p-4 text-right">Date</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {mockOrders
                  .filter((order) => 
                    order.id.toLowerCase().includes(search.toLowerCase()) ||
                    order.customer.toLowerCase().includes(search.toLowerCase())
                  )
                  .filter((order) => statusFilter === 'All' || order.status === statusFilter)
                  .map((order) => (
                    <tr key={order.id} className="border-b last:border-0 hover:bg-muted/50">
                      <td className="p-4 font-medium">{order.id}</td>
                      <td className="p-4">{order.customer}</td>
                      <td className="p-4">{order.items}</td>
                      <td className="p-4">
                        <Badge variant="outline" className={getStatusColor(order.status)}>
                          {order.status}
                        </Badge>
                      </td>
                      <td className="p-4 text-right font-medium">{formatCurrency(order.amount)}</td>
                      <td className="p-4 text-right text-sm text-muted-foreground">{order.date}</td>
                      <td className="p-4 text-right">
                        <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                          <ChevronDown className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}