'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Plus, Search, Filter, CreditCard, AlertTriangle, TrendingUp } from 'lucide-react';
import { cn, formatCurrency, getStatusColor } from '@/lib/utils';

const mockCustomers = [
  { code: 'CUST-001', name: 'Acme Corporation', contact: 'Rajesh Kumar', email: 'rajesh@acme.com', phone: '+91-9876543210', outstanding: 250000, creditLimit: 500000, status: 'active' },
  { code: 'CUST-002', name: 'Global Traders', contact: 'Priya Sharma', email: 'priya@global.com', phone: '+91-9876543211', outstanding: 180000, creditLimit: 300000, status: 'active' },
  { code: 'CUST-003', name: 'Metro Distributors', contact: 'Amit Singh', email: 'amit@metro.com', phone: '+91-9876543212', outstanding: 320000, creditLimit: 500000, status: 'active' },
  { code: 'CUST-004', name: 'Quick Mart', contact: 'Neha Patel', email: 'neha@quickmart.com', phone: '+91-9876543213', outstanding: 75000, creditLimit: 100000, status: 'active' },
  { code: 'CUST-005', name: 'Super Retail', contact: 'Vikram Joshi', email: 'vikram@superretail.com', phone: '+91-9876543214', outstanding: 500000, creditLimit: 500000, status: 'overdue' },
  { code: 'CUST-006', name: 'City Wholesale', contact: 'Anita Reddy', email: 'anita@citywholesale.com', phone: '+91-9876543215', outstanding: 120000, creditLimit: 200000, status: 'active' },
];

export default function CustomersPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  
  const statuses = ['All', 'Active', 'Overdue', 'Inactive'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Customers</h1>
          <p className="text-muted-foreground">Manage customer accounts and credit limits</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          New Customer
        </Button>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Customers</p>
                <p className="mt-1 text-3xl font-bold">247</p>
                <p className="mt-1 text-sm text-success">+12 this month</p>
              </div>
              <div className="rounded-lg bg-success/10 p-3">
                <Users className="h-6 w-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Outstanding</p>
                <p className="mt-1 text-3xl font-bold">{formatCurrency(1495000)}</p>
                <p className="mt-1 text-sm text-warning">5 overdue accounts</p>
              </div>
              <div className="rounded-lg bg-warning/10 p-3">
                <CreditCard className="h-6 w-6 text-warning" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Credit Utilization</p>
                <p className="mt-1 text-3xl font-bold">68%</p>
                <p className="mt-1 text-sm text-success">Within limits</p>
              </div>
              <div className="rounded-lg bg-info/10 p-3">
                <TrendingUp className="h-6 w-6 text-info" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Overdue Accounts</p>
                <p className="mt-1 text-3xl font-bold">5</p>
                <p className="mt-1 text-sm text-destructive">Action required</p>
              </div>
              <div className="rounded-lg bg-destructive/10 p-3">
                <AlertTriangle className="h-6 w-6 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search customers..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="flex h-10 w-40 items-center rounded-md border border-input bg-background px-3 py-2 text-sm"
              >
                {statuses.map((status) => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Customers Table */}
      <Card>
        <CardContent className="pt-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                  <th className="p-4">Customer</th>
                  <th className="p-4">Contact Person</th>
                  <th className="p-4">Email</th>
                  <th className="p-4">Phone</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Outstanding</th>
                  <th className="p-4 text-right">Credit Limit</th>
                  <th className="p-4 text-right">Utilization</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {mockCustomers
                  .filter((customer) => 
                    customer.name.toLowerCase().includes(search.toLowerCase()) ||
                    customer.code.toLowerCase().includes(search.toLowerCase()) ||
                    customer.contact.toLowerCase().includes(search.toLowerCase()) ||
                    customer.email.toLowerCase().includes(search.toLowerCase())
                  )
                  .filter((customer) => statusFilter === 'All' || customer.status === statusFilter.toLowerCase())
                  .map((customer) => {
                    const utilization = customer.creditLimit > 0 
                      ? Math.round((customer.outstanding / customer.creditLimit) * 100) 
                      : 0;
                    const isOverdue = customer.outstanding > customer.creditLimit || customer.status === 'overdue';
                    return (
                      <tr key={customer.code} className="border-b last:border-0 hover:bg-muted/50">
                        <td className="p-4">
                          <div>
                            <p className="font-medium">{customer.name}</p>
                            <p className="text-sm text-muted-foreground">{customer.code}</p>
                          </div>
                        </td>
                        <td className="p-4">{customer.contact}</td>
                        <td className="p-4">{customer.email}</td>
                        <td className="p-4">{customer.phone}</td>
                        <td className="p-4">
                          <Badge variant="outline" className={isOverdue ? 'bg-destructive/10 text-destructive border-destructive/20' : 'bg-success/10 text-success border-success/20'}>
                            {customer.status === 'overdue' ? 'Overdue' : 'Active'}
                          </Badge>
                        </td>
                        <td className="p-4 text-right font-medium {isOverdue ? 'text-destructive' : ''}">
                          {formatCurrency(customer.outstanding)}
                        </td>
                        <td className="p-4 text-right">{formatCurrency(customer.creditLimit)}</td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all ${
                                  utilization > 90 ? 'bg-destructive' : utilization > 70 ? 'bg-warning' : 'bg-success'
                                }`}
                                style={{ width: `${Math.min(utilization, 100)}%` }}
                              />
                            </div>
                            <span className="text-sm font-medium w-12 text-right">{utilization}%</span>
                          </div>
                        </td>
                        <td className="p-4 text-right">
                          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                            <AlertTriangle className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}