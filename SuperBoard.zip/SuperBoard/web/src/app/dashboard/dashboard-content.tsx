'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Factory,
  Truck,
  Users,
  CreditCard,
  FileText,
  TrendingUp,
  AlertTriangle,
  Clock,
  CheckCircle,
  XCircle,
} from 'lucide-react';
import { cn, formatCurrency, getStatusColor } from '@/lib/utils';

const stats = [
  {
    title: 'Total Revenue',
    value: '₹12.5L',
    change: '+12.5%',
    changeType: 'positive',
    icon: CreditCard,
    iconColor: 'text-success',
    bgColor: 'bg-success/10',
  },
  {
    title: 'Pending Orders',
    value: '24',
    change: '5 urgent',
    changeType: 'neutral',
    icon: ShoppingCart,
    iconColor: 'text-warning',
    bgColor: 'bg-warning/10',
  },
  {
    title: 'Low Stock Items',
    value: '8',
    change: 'Reorder needed',
    changeType: 'negative',
    icon: AlertTriangle,
    iconColor: 'text-destructive',
    bgColor: 'bg-destructive/10',
  },
  {
    title: 'Active Production',
    value: '3',
    change: '2 completing today',
    changeType: 'positive',
    icon: Factory,
    iconColor: 'text-info',
    bgColor: 'bg-info/10',
  },
];

const quickActions = [
  { label: 'New Order', icon: ShoppingCart, href: '/sales/new', color: 'bg-primary/10 text-primary' },
  { label: 'Stock Check', icon: Package, href: '/inventory', color: 'bg-success/10 text-success' },
  { label: 'New Production', icon: Factory, href: '/manufacturing/new', color: 'bg-warning/10 text-warning' },
  { label: 'Create Trip', icon: Truck, href: '/logistics/new', color: 'bg-info/10 text-info' },
  { label: 'New Customer', icon: Users, href: '/customers/new', color: 'bg-secondary/10 text-secondary' },
  { label: 'Expense Claim', icon: CreditCard, href: '/finance/expenses/new', color: 'bg-accent/10 text-accent' },
  { label: 'Leave Request', icon: FileText, href: '/hr/leave/new', color: 'bg-purple/10 text-purple' },
  { label: 'AI Assistant', icon: LayoutDashboard, href: '/ai', color: 'bg-primary/10 text-primary' },
];

const recentActivity = [
  {
    id: '1',
    icon: ShoppingCart,
    iconColor: 'text-primary',
    bgColor: 'bg-primary/10',
    title: 'New Sales Order #SO-2024-001',
    description: 'Acme Corporation • ₹45,000',
    time: '2 min ago',
  },
  {
    id: '2',
    icon: Package,
    iconColor: 'text-success',
    bgColor: 'bg-success/10',
    title: 'Stock Receipt #GRN-2024-015',
    description: 'Raw Materials • 500 units received',
    time: '15 min ago',
  },
  {
    id: '3',
    icon: Factory,
    iconColor: 'text-warning',
    bgColor: 'bg-warning/10',
    title: 'Production Completed #WO-2024-042',
    description: 'Orange Juice Batch #B-2024-089',
    time: '1 hour ago',
  },
  {
    id: '4',
    icon: Truck,
    iconColor: 'text-info',
    bgColor: 'bg-info/10',
    title: 'Delivery Trip #DT-2024-156',
    description: 'Mumbai Route • 8 stops completed',
    time: '3 hours ago',
  },
  {
    id: '5',
    icon: AlertTriangle,
    iconColor: 'text-destructive',
    bgColor: 'bg-destructive/10',
    title: 'Low Stock Alert',
    description: 'Sugar (50kg bags) • Below reorder level',
    time: '5 hours ago',
  },
];

const topProducts = [
  { name: 'Orange Juice 1L', sku: 'PRD-001', sold: 1250, revenue: 125000, trend: 'up' },
  { name: 'Atta Wheat Flour 10kg', sku: 'PRD-002', sold: 980, revenue: 294000, trend: 'up' },
  { name: 'Apple Juice 1L', sku: 'PRD-003', sold: 750, revenue: 82500, trend: 'down' },
  { name: 'Mixed Fruit Juice 1L', sku: 'PRD-004', sold: 620, revenue: 74400, trend: 'up' },
  { name: 'Glass Bottles 1L', sku: 'PRD-005', sold: 5000, revenue: 75000, trend: 'neutral' },
];

const recentOrders = [
  { id: 'SO-2024-001', customer: 'Acme Corporation', status: 'Confirmed', amount: 45000, date: '2024-01-15' },
  { id: 'SO-2024-002', customer: 'Global Traders', status: 'Shipped', amount: 125000, date: '2024-01-14' },
  { id: 'SO-2024-003', customer: 'Metro Distributors', status: 'Delivered', amount: 78500, date: '2024-01-13' },
  { id: 'SO-2024-004', customer: 'Quick Mart', status: 'Draft', amount: 32000, date: '2024-01-15' },
  { id: 'SO-2024-005', customer: 'Super Retail', status: 'Cancelled', amount: 15000, date: '2024-01-12' },
];

export function DashboardContent() {
  return (
    <div className="space-y-6 p-6">
      {/* Welcome Section */}
      <div className="rounded-xl bg-gradient-to-br from-primary to-primary/80 p-6 text-primary-foreground shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Welcome back! 👋</h1>
            <p className="mt-1 text-primary-foreground/80">Here's what's happening with your business today</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 rounded-lg bg-primary-foreground/10 px-4 py-2">
              <TrendingUp className="h-5 w-5" />
              <span className="text-sm font-medium">+12.5% vs last month</span>
            </div>
            <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary-foreground/10">
              <LayoutDashboard className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                  <p className="mt-1 text-3xl font-bold">{stat.value}</p>
                  <p className={cn('mt-1 text-sm', stat.changeType === 'positive' && 'text-success', stat.changeType === 'negative' && 'text-destructive', stat.changeType === 'neutral' && 'text-muted-foreground')}>
                    {stat.change}
                  </p>
                </div>
                <div className={cn('rounded-lg p-3', stat.bgColor)}>
                  <stat.icon className={cn('h-6 w-6', stat.iconColor)} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Quick Actions */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Quick Actions
              <Button variant="ghost" size="sm" asChild>
                <a href="/actions">View All</a>
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-2 gap-3">
              {quickActions.map((action) => (
                <Button
                  key={action.label}
                  variant="outline"
                  className={cn('h-auto p-4 flex-col gap-2', action.color)}
                  asChild
                >
                  <a href={action.href}>
                    <action.icon className="h-6 w-6" />
                    <span className="text-sm font-medium">{action.label}</span>
                  </a>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Top Products & Recent Orders */}
        <div className="lg:col-span-2 space-y-6">
          {/* Top Products */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Top Selling Products
                <Button variant="ghost" size="sm" asChild>
                  <a href="/reports/top-products">View All</a>
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                      <th className="pb-3 pr-4">Product</th>
                      <th className="pb-3 pr-4">SKU</th>
                      <th className="pb-3 pr-4 text-right">Units Sold</th>
                      <th className="pb-3 pr-4 text-right">Revenue</th>
                      <th className="pb-3 text-right">Trend</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topProducts.map((product) => (
                      <tr key={product.sku} className="border-b last:border-0">
                        <td className="py-3 pr-4 font-medium">{product.name}</td>
                        <td className="py-3 pr-4 text-sm text-muted-foreground">{product.sku}</td>
                        <td className="py-3 pr-4 text-right">{product.sold.toLocaleString()}</td>
                        <td className="py-3 pr-4 text-right font-medium">{formatCurrency(product.revenue)}</td>
                        <td className="py-3 text-right">
                          {product.trend === 'up' && <TrendingUp className="h-4 w-4 text-success mx-auto" />}
                          {product.trend === 'down' && <TrendingUp className="h-4 w-4 text-destructive rotate-180 mx-auto" />}
                          {product.trend === 'neutral' && <span className="text-muted-foreground">—</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Recent Orders */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Recent Orders
                <Button variant="ghost" size="sm" asChild>
                  <a href="/sales">View All</a>
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                      <th className="pb-3 pr-4">Order</th>
                      <th className="pb-3 pr-4">Customer</th>
                      <th className="pb-3 pr-4">Status</th>
                      <th className="pb-3 pr-4 text-right">Amount</th>
                      <th className="pb-3 text-right">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentOrders.map((order) => (
                      <tr key={order.id} className="border-b last:border-0 hover:bg-muted/50">
                        <td className="py-3 pr-4 font-medium">{order.id}</td>
                        <td className="py-3 pr-4">{order.customer}</td>
                        <td className="py-3 pr-4">
                          <Badge variant="outline" className={getStatusColor(order.status)}>
                            {order.status}
                          </Badge>
                        </td>
                        <td className="py-3 pr-4 text-right font-medium">{formatCurrency(order.amount)}</td>
                        <td className="py-3 text-right text-sm text-muted-foreground">{order.date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Recent Activity
            <Button variant="ghost" size="sm" asChild>
              <a href="/activity">View All</a>
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-4">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-center gap-4 p-4 hover:bg-muted/50 rounded-lg transition-colors">
                <div className={cn('rounded-lg p-2', activity.bgColor)}>
                  <activity.icon className={cn('h-5 w-5', activity.iconColor)} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{activity.title}</p>
                  <p className="text-sm text-muted-foreground truncate">{activity.description}</p>
                </div>
                <span className="text-sm text-muted-foreground whitespace-nowrap">{activity.time}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}