'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Truck, Plus, Search, Filter, MapPin, Package, AlertTriangle, CheckCircle, Clock, Fuel, Navigation } from 'lucide-react';
import { cn, formatCurrency, getStatusColor } from '@/lib/utils';

const mockTrips = [
  { id: 'DT-2024-156', vehicle: 'MH-01-AB-1234', driver: 'Ramesh Kumar', route: 'Mumbai - Pune', status: 'Completed', distance: 150, fuelCost: 3500, tollCost: 800, startTime: '2024-01-15 06:00', endTime: '2024-01-15 14:30', stops: 8 },
  { id: 'DT-2024-157', vehicle: 'MH-02-CD-5678', driver: 'Suresh Patel', route: 'Mumbai - Nashik', status: 'In Progress', distance: 180, fuelCost: 4200, tollCost: 600, startTime: '2024-01-15 07:00', endTime: '-', stops: 6 },
  { id: 'DT-2024-158', vehicle: 'MH-03-EF-9012', driver: 'Mahesh Singh', route: 'Mumbai - Surat', status: 'Planned', distance: 280, fuelCost: 6500, tollCost: 1200, startTime: '2024-01-16 05:00', endTime: '-', stops: 10 },
  { id: 'DT-2024-155', vehicle: 'MH-01-AB-1234', driver: 'Ramesh Kumar', route: 'Mumbai - Ahmedabad', status: 'Completed', distance: 530, fuelCost: 12500, tollCost: 2500, startTime: '2024-01-14 04:00', endTime: '2024-01-14 18:00', stops: 12 },
];

const mockVehicles = [
  { id: 'MH-01-AB-1234', type: 'Truck (16T)', driver: 'Ramesh Kumar', status: 'Active', lastGps: '2024-01-15 14:30', gpsEnabled: true },
  { id: 'MH-02-CD-5678', type: 'Truck (10T)', driver: 'Suresh Patel', status: 'Active', lastGps: '2024-01-15 10:15', gpsEnabled: true },
  { id: 'MH-03-EF-9012', type: 'Truck (16T)', driver: 'Mahesh Singh', status: 'Maintenance', lastGps: '2024-01-14 18:00', gpsEnabled: false },
  { id: 'MH-04-GH-3456', type: 'Van (3.5T)', driver: 'Rajesh Kumar', status: 'Active', lastGps: '2024-01-15 12:00', gpsEnabled: true },
];

const mockDrivers = [
  { id: 'DRV-001', name: 'Ramesh Kumar', license: 'MH0123456789', expiry: '2025-06-15', phone: '+91-9876543210', status: 'Active' },
  { id: 'DRV-002', name: 'Suresh Patel', license: 'MH0234567890', expiry: '2024-12-20', phone: '+91-9876543211', status: 'Active' },
  { id: 'DRV-003', name: 'Mahesh Singh', license: 'MH0345678901', expiry: '2025-03-10', phone: '+91-9876543212', status: 'On Leave' },
  { id: 'DRV-004', name: 'Rajesh Kumar', license: 'MH0456789012', expiry: '2026-01-05', phone: '+91-9876543213', status: 'Active' },
];

export default function LogisticsPage() {
  const [activeTab, setActiveTab] = useState('trips');
  const [search, setSearch] = useState('');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Logistics</h1>
          <p className="text-muted-foreground">Manage delivery trips, vehicles, and drivers</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          {activeTab === 'trips' ? 'New Trip' : activeTab === 'vehicles' ? 'Add Vehicle' : 'Add Driver'}
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-muted p-1 rounded-lg">
        {[
          { id: 'trips', label: 'Delivery Trips', icon: Truck },
          { id: 'vehicles', label: 'Vehicles', icon: Truck },
          { id: 'drivers', label: 'Drivers', icon: Package },
          { id: 'routes', label: 'Routes', icon: Navigation },
        ].map((tab) => (
          <Button
            key={tab.id}
            variant={activeTab === tab.id ? 'default' : 'ghost'}
            size="sm"
            className="gap-2"
            onClick={() => setActiveTab(tab.id)}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </Button>
        ))}
      </div>

      {/* Trip Stats */}
      {activeTab === 'trips' && (
        <>
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Active Trips</p>
                    <p className="mt-1 text-3xl font-bold">3</p>
                    <p className="mt-1 text-sm text-info">2 in progress, 1 pending</p>
                  </div>
                  <div className="rounded-lg bg-info/10 p-3">
                    <Truck className="h-6 w-6 text-info" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Completed Today</p>
                    <p className="mt-1 text-3xl font-bold">12</p>
                    <p className="mt-1 text-sm text-success">98% on-time delivery</p>
                  </div>
                  <div className="rounded-lg bg-success/10 p-3">
                    <CheckCircle className="h-6 w-6 text-success" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Distance (MTD)</p>
                    <p className="mt-1 text-3xl font-bold">45,230 km</p>
                    <p className="mt-1 text-sm text-warning">+12% vs last month</p>
                  </div>
                  <div className="rounded-lg bg-warning/10 p-3">
                    <MapPin className="h-6 w-6 text-warning" />
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Fuel Cost (MTD)</p>
                    <p className="mt-1 text-3xl font-bold">{formatCurrency(1250000)}</p>
                    <p className="mt-1 text-sm text-destructive">+8% vs last month</p>
                  </div>
                  <div className="rounded-lg bg-destructive/10 p-3">
                    <Fuel className="h-6 w-6 text-destructive" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={`Search ${activeTab === 'trips' ? 'trips' : activeTab === 'vehicles' ? 'vehicles' : 'drivers'}...`}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <select className="flex h-10 w-40 items-center rounded-md border border-input bg-background px-3 py-2 text-sm">
                <option value="all">All Status</option>
                {activeTab === 'trips' && (
                  <>
                    <option value="planned">Planned</option>
                    <option value="in-progress">In Progress</option>
                    <option value="completed">Completed</option>
                  </>
                )}
                {activeTab === 'vehicles' && (
                  <>
                    <option value="active">Active</option>
                    <option value="maintenance">Maintenance</option>
                    <option value="inactive">Inactive</option>
                  </>
                )}
                {activeTab === 'drivers' && (
                  <>
                    <option value="active">Active</option>
                    <option value="on-leave">On Leave</option>
                    <option value="inactive">Inactive</option>
                  </>
                )}
              </select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Trips Table */}
      {activeTab === 'trips' && (
        <Card>
          <CardContent className="pt-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                    <th className="p-4">Trip No.</th>
                    <th className="p-4">Vehicle</th>
                    <th className="p-4">Driver</th>
                    <th className="p-4">Route</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Distance</th>
                    <th className="p-4 text-right">Fuel Cost</th>
                    <th className="p-4 text-right">Stops</th>
                    <th className="p-4 text-right">Start Time</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockTrips
                    .filter((trip) => 
                      trip.id.toLowerCase().includes(search.toLowerCase()) ||
                      trip.driver.toLowerCase().includes(search.toLowerCase()) ||
                      trip.route.toLowerCase().includes(search.toLowerCase())
                    )
                    .map((trip) => {
                      const statusColors: Record<string, string> = {
                        Planned: 'bg-info/10 text-info border-info/20',
                        'In Progress': 'bg-warning/10 text-warning border-warning/20',
                        Completed: 'bg-success/10 text-success border-success/20',
                      };
                      return (
                        <tr key={trip.id} className="border-b last:border-0 hover:bg-muted/50">
                          <td className="p-4 font-medium">{trip.id}</td>
                          <td className="p-4">{trip.vehicle}</td>
                          <td className="p-4">{trip.driver}</td>
                          <td className="p-4">{trip.route}</td>
                          <td className="p-4">
                            <Badge variant="outline" className={statusColors[trip.status] || statusColors.Planned}>
                              {trip.status}
                            </Badge>
                          </td>
                          <td className="p-4 text-right">{trip.distance} km</td>
                          <td className="p-4 text-right">{formatCurrency(trip.fuelCost)}</td>
                          <td className="p-4 text-right">{trip.stops}</td>
                          <td className="p-4 text-right text-sm text-muted-foreground">{trip.startTime.split(' ')[1]}</td>
                          <td className="p-4 text-right">
                            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                              <MapPin className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Vehicles Table */}
      {activeTab === 'vehicles' && (
        <Card>
          <CardContent className="pt-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                    <th className="p-4">Registration</th>
                    <th className="p-4">Type</th>
                    <th className="p-4">Assigned Driver</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">GPS</th>
                    <th className="p-4">Last GPS Update</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockVehicles
                    .filter((v) => 
                      v.id.toLowerCase().includes(search.toLowerCase()) ||
                      v.driver.toLowerCase().includes(search.toLowerCase())
                    )
                    .map((v) => (
                      <tr key={v.id} className="border-b last:border-0 hover:bg-muted/50">
                        <td className="p-4 font-medium">{v.id}</td>
                        <td className="p-4">{v.type}</td>
                        <td className="p-4">{v.driver}</td>
                        <td className="p-4">
                          <Badge variant="outline" className={v.status === 'Active' ? 'bg-success/10 text-success border-success/20' : v.status === 'Maintenance' ? 'bg-warning/10 text-warning border-warning/20' : 'bg-muted text-muted-foreground'}>
                            {v.status}
                          </Badge>
                        </td>
                        <td className="p-4">
                          {v.gpsEnabled ? (
                            <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                              <span className="flex items-center gap-1">
                                <span className="h-1.5 w-1.5 rounded-full bg-success" />
                                Enabled
                              </span>
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-muted text-muted-foreground">
                              Disabled
                            </Badge>
                          )}
                        </td>
                        <td className="p-4 text-sm text-muted-foreground">{v.lastGps}</td>
                        <td className="p-4 text-right">
                          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                            <MapPin className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Drivers Table */}
      {activeTab === 'drivers' && (
        <Card>
          <CardContent className="pt-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                    <th className="p-4">Driver ID</th>
                    <th className="p-4">Name</th>
                    <th className="p-4">License Number</th>
                    <th className="p-4">License Expiry</th>
                    <th className="p-4">Phone</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockDrivers
                    .filter((d) => 
                      d.name.toLowerCase().includes(search.toLowerCase()) ||
                      d.license.toLowerCase().includes(search.toLowerCase())
                    )
                    .map((d) => {
                      const isExpiringSoon = new Date(d.expiry) < new Date(Date.now() + 60 * 24 * 60 * 60 * 1000);
                      return (
                        <tr key={d.id} className="border-b last:border-0 hover:bg-muted/50">
                          <td className="p-4 font-medium">{d.id}</td>
                          <td className="p-4">{d.name}</td>
                          <td className="p-4 font-mono text-sm">{d.license}</td>
                          <td className="p-4 {isExpiringSoon ? 'text-warning' : ''}">{d.expiry}{isExpiringSoon && ' ⚠️'}</td>
                          <td className="p-4">{d.phone}</td>
                          <td className="p-4">
                            <Badge variant="outline" className={d.status === 'Active' ? 'bg-success/10 text-success border-success/20' : 'bg-warning/10 text-warning border-warning/20'}>
                              {d.status}
                            </Badge>
                          </td>
                          <td className="p-4 text-right">
                            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                              <Package className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Routes Placeholder */}
      {activeTab === 'routes' && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-12">
              <Navigation className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium">Route Management</h3>
              <p className="text-muted-foreground mt-2">Define and manage delivery routes with multiple stops.</p>
              <Button className="mt-4 gap-2" variant="outline">
                <Plus className="h-4 w-4" />
                Create Route
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}