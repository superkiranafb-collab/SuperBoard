'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Package, Plus, Search, Filter, AlertTriangle, TrendingUp, TrendingDown } from 'lucide-react';
import { cn, formatCurrency, getStatusColor } from '@/lib/utils';

const mockProducts = [
  { sku: 'PRD-001', name: 'Orange Juice 1L', category: 'Beverages', stock: 1500, reserved: 50, unit: 'units', reorder: 100, price: 100, status: 'in-stock' },
  { sku: 'PRD-002', name: 'Atta Wheat Flour 10kg', category: 'Food Grains', stock: 25, reserved: 5, unit: 'bags', reorder: 50, price: 300, status: 'low-stock' },
  { sku: 'PRD-003', name: 'Apple Juice 1L', category: 'Beverages', stock: 0, reserved: 0, unit: 'units', reorder: 100, price: 110, status: 'out-of-stock' },
  { sku: 'PRD-004', name: 'Sugar 50kg', category: 'Raw Materials', stock: 80, reserved: 20, unit: 'bags', reorder: 100, price: 2500, status: 'low-stock' },
  { sku: 'PRD-005', name: 'Glass Bottles 1L', category: 'Packaging', stock: 5000, reserved: 1000, unit: 'units', reorder: 2000, price: 15, status: 'in-stock' },
  { sku: 'PRD-006', name: 'Mango Pulp 850g', category: 'Raw Materials', stock: 120, reserved: 30, unit: 'cans', reorder: 50, price: 85, status: 'in-stock' },
  { sku: 'PRD-007', name: 'PET Bottles 500ml', category: 'Packaging', stock: 10000, reserved: 2000, unit: 'units', reorder: 5000, price: 8, status: 'in-stock' },
  { sku: 'PRD-008', name: 'Citric Acid 25kg', category: 'Raw Materials', stock: 15, reserved: 5, unit: 'bags', reorder: 20, price: 1200, status: 'low-stock' },
];

export default function InventoryPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [activeTab, setActiveTab] = useState('products');
  
  const statuses = ['All', 'In Stock', 'Low Stock', 'Out of Stock'];

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'in-stock':
        return { label: 'In Stock', color: 'success', icon: TrendingUp };
      case 'low-stock':
        return { label: 'Low Stock', color: 'warning', icon: AlertTriangle };
      case 'out-of-stock':
        return { label: 'Out of Stock', color: 'destructive', icon: TrendingDown };
      default:
        return { label: 'Unknown', color: 'secondary', icon: Package };
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Inventory</h1>
          <p className="text-muted-foreground">Manage products, stock levels, and batches</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Plus className="h-4 w-4" />
            Import
          </Button>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Add Product
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-muted p-1 rounded-lg">
        {[
          { id: 'products', label: 'Products', icon: Package },
          { id: 'batches', label: 'Batches', icon: Package },
          { id: 'movements', label: 'Movements', icon: TrendingUp },
        ].map((tab) => (
          <Button
            key={tab.id}
            variant={activeTab === tab.id ? 'default' : 'ghost'}
            size="sm"
            className="gap-2"
            onClick={() => setActiveTab(tab.id)}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </Button>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search products..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="flex h-10 w-40 items-center rounded-md border border-input bg-background px-3 py-2 text-sm"
              >
                {statuses.map((status) => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Products Table */}
      <Card>
        <CardContent className="pt-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                  <th className="p-4">Product</th>
                  <th className="p-4">Category</th>
                  <th className="p-4">Status</th>
                  <th className="p-4 text-right">Available</th>
                  <th className="p-4 text-right">Reserved</th>
                  <th className="p-4 text-right">Reorder Level</th>
                  <th className="p-4 text-right">Unit Price</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {mockProducts
                  .filter((product) => 
                    product.name.toLowerCase().includes(search.toLowerCase()) ||
                    product.sku.toLowerCase().includes(search.toLowerCase()) ||
                    product.category.toLowerCase().includes(search.toLowerCase())
                  )
                  .filter((product) => {
                    if (statusFilter === 'All') return true;
                    if (statusFilter === 'In Stock') return product.status === 'in-stock';
                    if (statusFilter === 'Low Stock') return product.status === 'low-stock';
                    if (statusFilter === 'Out of Stock') return product.status === 'out-of-stock';
                    return true;
                  })
                  .map((product) => {
                    const statusConfig = getStatusConfig(product.status);
                    const StatusIcon = statusConfig.icon;
                    return (
                      <tr key={product.sku} className="border-b last:border-0 hover:bg-muted/50">
                        <td className="p-4">
                          <div>
                            <p className="font-medium">{product.name}</p>
                            <p className="text-sm text-muted-foreground">{product.sku}</p>
                          </div>
                        </td>
                        <td className="p-4">{product.category}</td>
                        <td className="p-4">
                          <Badge variant="outline" className={cn('gap-1', getStatusColor(statusConfig.color))}>
                            <StatusIcon className="h-3 w-3" />
                            {statusConfig.label}
                          </Badge>
                        </td>
                        <td className="p-4 text-right font-medium">
                          {product.stock.toLocaleString()} {product.unit}
                        </td>
                        <td className="p-4 text-right text-muted-foreground">
                          {product.reserved.toLocaleString()} {product.unit}
                        </td>
                        <td className="p-4 text-right">
                          {product.stock <= product.reorder ? (
                            <span className="text-destructive font-medium">{product.reorder.toLocaleString()}</span>
                          ) : (
                            <span className="text-muted-foreground">{product.reorder.toLocaleString()}</span>
                          )}
                        </td>
                        <td className="p-4 text-right">{formatCurrency(product.price)}</td>
                        <td className="p-4 text-right">
                          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                            <AlertTriangle className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}