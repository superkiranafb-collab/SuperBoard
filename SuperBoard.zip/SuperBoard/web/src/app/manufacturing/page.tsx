'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Factory, Plus, Search, Filter, AlertTriangle, CheckCircle, Clock, PauseCircle, PlayCircle } from 'lucide-react';
import { cn, getStatusColor } from '@/lib/utils';

const mockWorkOrders = [
  { id: 'WO-2024-042', product: 'Orange Juice 1L', batch: 'B-2024-089', status: 'In Progress', planned: 1000, produced: 750, startDate: '2024-01-15', dueDate: '2024-01-16', priority: 'High' },
  { id: 'WO-2024-043', product: 'Atta Wheat Flour 10kg', batch: 'B-2024-090', status: 'Planned', planned: 500, produced: 0, startDate: '2024-01-16', dueDate: '2024-01-17', priority: 'Normal' },
  { id: 'WO-2024-041', product: 'Apple Juice 1L', batch: 'B-2024-088', status: 'Completed', planned: 800, produced: 800, startDate: '2024-01-14', dueDate: '2024-01-15', priority: 'High' },
  { id: 'WO-2024-040', product: 'Mixed Fruit Juice 1L', batch: 'B-2024-087', status: 'On Hold', planned: 600, produced: 200, startDate: '2024-01-13', dueDate: '2024-01-14', priority: 'Normal' },
  { id: 'WO-2024-039', product: 'Orange Juice 1L', batch: 'B-2024-086', status: 'Completed', planned: 1000, produced: 1000, startDate: '2024-01-12', dueDate: '2024-01-13', priority: 'High' },
];

const mockBOMs = [
  { id: 'BOM-001', product: 'Orange Juice 1L', version: 'v1.2', status: 'Approved', yield: 1000, components: 5 },
  { id: 'BOM-002', product: 'Atta Wheat Flour 10kg', version: 'v1.0', status: 'Approved', yield: 500, components: 3 },
  { id: 'BOM-003', product: 'Apple Juice 1L', version: 'v1.1', status: 'Draft', yield: 800, components: 4 },
  { id: 'BOM-004', product: 'Mixed Fruit Juice 1L', version: 'v1.0', status: 'Pending Approval', yield: 600, components: 6 },
];

export default function ManufacturingPage() {
  const [activeTab, setActiveTab] = useState('work-orders');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  
  const woStatuses = ['All', 'Planned', 'In Progress', 'Completed', 'On Hold', 'Cancelled'];
  const bomStatuses = ['All', 'Draft', 'Pending Approval', 'Approved', 'Archived'];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'Normal': return 'bg-info/10 text-info border-info/20';
      case 'Low': return 'bg-success/10 text-success border-success/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Manufacturing</h1>
          <p className="text-muted-foreground">Manage work orders, BOMs, and production</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          {activeTab === 'work-orders' ? 'New Work Order' : 'New BOM'}
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-muted p-1 rounded-lg">
        {[
          { id: 'work-orders', label: 'Work Orders', icon: Factory },
          { id: 'boms', label: 'Bill of Materials', icon: Factory },
          { id: 'production', label: 'Production Entries', icon: Factory },
          { id: 'quality', label: 'Quality Checks', icon: CheckCircle },
        ].map((tab) => (
          <Button
            key={tab.id}
            variant={activeTab === tab.id ? 'default' : 'ghost'}
            size="sm"
            className="gap-2"
            onClick={() => setActiveTab(tab.id)}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </Button>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={`Search ${activeTab === 'work-orders' ? 'work orders' : 'BOMs'}...`}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="flex h-10 w-40 items-center rounded-md border border-input bg-background px-3 py-2 text-sm"
              >
                {(activeTab === 'work-orders' ? woStatuses : bomStatuses).map((status) => (
                  <option key={status} value={status}>{status}</option>
                ))}
              </select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Work Orders Table */}
      {activeTab === 'work-orders' && (
        <Card>
          <CardContent className="pt-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                    <th className="p-4">Work Order</th>
                    <th className="p-4">Product</th>
                    <th className="p-4">Batch</th>
                    <th className="p-4">Status</th>
                    <th className="p-4">Priority</th>
                    <th className="p-4 text-right">Progress</th>
                    <th className="p-4 text-right">Start Date</th>
                    <th className="p-4 text-right">Due Date</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockWorkOrders
                    .filter((wo) => 
                      wo.id.toLowerCase().includes(search.toLowerCase()) ||
                      wo.product.toLowerCase().includes(search.toLowerCase()) ||
                      wo.batch.toLowerCase().includes(search.toLowerCase())
                    )
                    .filter((wo) => statusFilter === 'All' || wo.status === statusFilter)
                    .map((wo) => {
                      const progress = wo.planned > 0 ? Math.round((wo.produced / wo.planned) * 100) : 0;
                      const getStatusIcon = () => {
                        switch (wo.status) {
                          case 'In Progress': return <PlayCircle className="h-3 w-3" />;
                          case 'Completed': return <CheckCircle className="h-3 w-3" />;
                          case 'On Hold': return <PauseCircle className="h-3 w-3" />;
                          default: return <Clock className="h-3 w-3" />;
                        }
                      };
                      return (
                        <tr key={wo.id} className="border-b last:border-0 hover:bg-muted/50">
                          <td className="p-4 font-medium">{wo.id}</td>
                          <td className="p-4">{wo.product}</td>
                          <td className="p-4 text-sm text-muted-foreground">{wo.batch}</td>
                          <td className="p-4">
                            <Badge variant="outline" className={cn('gap-1', getStatusColor(wo.status))}>
                              {getStatusIcon()}
                              {wo.status}
                            </Badge>
                          </td>
                          <td className="p-4">
                            <Badge variant="outline" className={getPriorityColor(wo.priority)}>
                              {wo.priority}
                            </Badge>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-primary rounded-full transition-all"
                                  style={{ width: `${progress}%` }}
                                />
                              </div>
                              <span className="text-sm font-medium w-12 text-right">{progress}%</span>
                            </div>
                          </td>
                          <td className="p-4 text-right text-sm text-muted-foreground">{wo.startDate}</td>
                          <td className="p-4 text-right text-sm text-muted-foreground">{wo.dueDate}</td>
                          <td className="p-4 text-right">
                            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                              <AlertTriangle className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* BOMs Table */}
      {activeTab === 'boms' && (
        <Card>
          <CardContent className="pt-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                    <th className="p-4">BOM</th>
                    <th className="p-4">Product</th>
                    <th className="p-4">Version</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Yield Qty</th>
                    <th className="p-4 text-right">Components</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {mockBOMs
                    .filter((bom) => 
                      bom.id.toLowerCase().includes(search.toLowerCase()) ||
                      bom.product.toLowerCase().includes(search.toLowerCase())
                    )
                    .filter((bom) => statusFilter === 'All' || bom.status === statusFilter)
                    .map((bom) => (
                      <tr key={bom.id} className="border-b last:border-0 hover:bg-muted/50">
                        <td className="p-4 font-medium">{bom.id}</td>
                        <td className="p-4">{bom.product}</td>
                        <td className="p-4">{bom.version}</td>
                        <td className="p-4">
                          <Badge variant="outline" className={getStatusColor(bom.status)}>
                            {bom.status}
                          </Badge>
                        </td>
                        <td className="p-4 text-right">{bom.yield.toLocaleString()}</td>
                        <td className="p-4 text-right">{bom.components}</td>
                        <td className="p-4 text-right">
                          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                            <AlertTriangle className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}