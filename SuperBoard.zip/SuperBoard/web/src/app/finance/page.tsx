'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CreditCard, Plus, Search, Filter, FileText, DollarSign, Receipt, TrendingUp, TrendingDown } from 'lucide-react';
import { cn, formatCurrency, getStatusColor } from '@/lib/utils';

const mockJournalEntries = [
  { id: 'JE-2024-001', date: '2024-01-15', ref: 'SO-2024-001', narration: 'Sales Invoice - Acme Corp', debit: 45000, credit: 0, status: 'Posted' },
  { id: 'JE-2024-002', date: '2024-01-15', ref: 'SO-2024-001', narration: 'Sales Invoice - Acme Corp', debit: 0, credit: 45000, status: 'Posted' },
  { id: 'JE-2024-003', date: '2024-01-14', ref: 'GRN-2024-015', narration: 'Purchase Receipt - Sugar', debit: 125000, credit: 0, status: 'Posted' },
  { id: 'JE-2024-004', date: '2024-01-14', ref: 'GRN-2024-015', narration: 'Purchase Receipt - Sugar', debit: 0, credit: 125000, status: 'Posted' },
  { id: 'JE-2024-005', date: '2024-01-13', ref: 'EXP-2024-008', narration: 'Office Expenses', debit: 15000, credit: 0, status: 'Draft' },
  { id: 'JE-2024-006', date: '2024-01-13', ref: 'EXP-2024-008', narration: 'Office Expenses', debit: 0, credit: 15000, status: 'Draft' },
];

const mockExpenseClaims = [
  { id: 'EXP-2024-008', employee: 'John Doe', date: '2024-01-13', amount: 15000, category: 'Office Supplies', status: 'Pending' },
  { id: 'EXP-2024-007', employee: 'Jane Smith', date: '2024-01-12', amount: 8500, category: 'Travel', status: 'Approved' },
  { id: 'EXP-2024-006', employee: 'Bob Wilson', date: '2024-01-11', amount: 22000, category: 'Client Entertainment', status: 'Rejected' },
];

export default function FinancePage() {
  const [activeTab, setActiveTab] = useState('overview');
  const [search, setSearch] = useState('');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Finance</h1>
          <p className="text-muted-foreground">Manage accounts, journal entries, and expenses</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          New Entry
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-muted p-1 rounded-lg">
        {[
          { id: 'overview', label: 'Overview', icon: CreditCard },
          { id: 'journal', label: 'Journal Entries', icon: FileText },
          { id: 'expenses', label: 'Expense Claims', icon: Receipt },
          { id: 'gst', label: 'GST Returns', icon: DollarSign },
          { id: 'chart', label: 'Chart of Accounts', icon: TrendingUp },
        ].map((tab) => (
          <Button
            key={tab.id}
            variant={activeTab === tab.id ? 'default' : 'ghost'}
            size="sm"
            className="gap-2"
            onClick={() => setActiveTab(tab.id)}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </Button>
        ))}
      </div>

      {/* Overview Stats */}
      {activeTab === 'overview' && (
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Assets</p>
                  <p className="mt-1 text-3xl font-bold">{formatCurrency(12500000)}</p>
                  <p className="mt-1 text-sm text-success">+8.5% vs last month</p>
                </div>
                <div className="rounded-lg bg-success/10 p-3">
                  <TrendingUp className="h-6 w-6 text-success" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Liabilities</p>
                  <p className="mt-1 text-3xl font-bold">{formatCurrency(4200000)}</p>
                  <p className="mt-1 text-sm text-warning">+2.1% vs last month</p>
                </div>
                <div className="rounded-lg bg-warning/10 p-3">
                  <TrendingUp className="h-6 w-6 text-warning" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Equity</p>
                  <p className="mt-1 text-3xl font-bold">{formatCurrency(8300000)}</p>
                  <p className="mt-1 text-sm text-success">+10.2% vs last month</p>
                </div>
                <div className="rounded-lg bg-success/10 p-3">
                  <TrendingUp className="h-6 w-6 text-success" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Monthly Revenue</p>
                  <p className="mt-1 text-3xl font-bold">{formatCurrency(1250000)}</p>
                  <p className="mt-1 text-sm text-success">+12.5% vs last month</p>
                </div>
                <div className="rounded-lg bg-info/10 p-3">
                  <DollarSign className="h-6 w-6 text-info" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      }

      {/* Journal Entries */}
      {activeTab === 'journal' && (
        <>
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search journal entries..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <div className="flex gap-2">
                  <select className="flex h-10 w-40 items-center rounded-md border border-input bg-background px-3 py-2 text-sm">
                    <option value="all">All Status</option>
                    <option value="posted">Posted</option>
                    <option value="draft">Draft</option>
                  </select>
                  <Button variant="outline" size="icon">
                    <Filter className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                      <th className="p-4">Entry No.</th>
                      <th className="p-4">Date</th>
                      <th className="p-4">Reference</th>
                      <th className="p-4">Narration</th>
                      <th className="p-4 text-right">Debit</th>
                      <th className="p-4 text-right">Credit</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockJournalEntries
                      .filter((je) => 
                        je.id.toLowerCase().includes(search.toLowerCase()) ||
                        je.ref.toLowerCase().includes(search.toLowerCase()) ||
                        je.narration.toLowerCase().includes(search.toLowerCase())
                      )
                      .map((je) => (
                        <tr key={je.id} className="border-b last:border-0 hover:bg-muted/50">
                          <td className="p-4 font-medium">{je.id}</td>
                          <td className="p-4">{je.date}</td>
                          <td className="p-4">{je.ref}</td>
                          <td className="p-4">{je.narration}</td>
                          <td className="p-4 text-right font-medium text-success">
                            {je.debit > 0 ? formatCurrency(je.debit) : '-'}
                          </td>
                          <td className="p-4 text-right font-medium text-destructive">
                            {je.credit > 0 ? formatCurrency(je.credit) : '-'}
                          </td>
                          <td className="p-4">
                            <Badge variant="outline" className={getStatusColor(je.status)}>
                              {je.status}
                            </Badge>
                          </td>
                          <td className="p-4 text-right">
                            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                              <FileText className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {/* Expense Claims */}
      {activeTab === 'expenses' && (
        <>
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search expense claims..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b text-left text-sm font-medium text-muted-foreground">
                      <th className="p-4">Claim No.</th>
                      <th className="p-4">Employee</th>
                      <th className="p-4">Date</th>
                      <th className="p-4">Category</th>
                      <th className="p-4 text-right">Amount</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mockExpenseClaims
                      .filter((ec) => 
                        ec.id.toLowerCase().includes(search.toLowerCase()) ||
                        ec.employee.toLowerCase().includes(search.toLowerCase()) ||
                        ec.category.toLowerCase().includes(search.toLowerCase())
                      )
                      .map((ec) => {
                        const statusColors: Record<string, string> = {
                          Pending: 'bg-warning/10 text-warning border-warning/20',
                          Approved: 'bg-success/10 text-success border-success/20',
                          Rejected: 'bg-destructive/10 text-destructive border-destructive/20',
                        };
                        return (
                          <tr key={ec.id} className="border-b last:border-0 hover:bg-muted/50">
                            <td className="p-4 font-medium">{ec.id}</td>
                            <td className="p-4">{ec.employee}</td>
                            <td className="p-4">{ec.date}</td>
                            <td className="p-4">{ec.category}</td>
                            <td className="p-4 text-right font-medium">{formatCurrency(ec.amount)}</td>
                            <td className="p-4">
                              <Badge variant="outline" className={statusColors[ec.status] || statusColors.Pending}>
                                {ec.status}
                              </Badge>
                            </td>
                            <td className="p-4 text-right">
                              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                                <FileText className="h-4 w-4" />
                              </Button>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {/* GST Returns & Chart of Accounts placeholders */}
      {(activeTab === 'gst' || activeTab === 'chart') && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium">{activeTab === 'gst' ? 'GST Returns' : 'Chart of Accounts'}</h3>
              <p className="text-muted-foreground mt-2">This feature is coming soon.</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}