"""Initial migration - create all tables"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID, JSONB

revision = '001_initial'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Organizations
    op.create_table(
        'organizations',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('code', sa.String(50), unique=True, nullable=False),
        sa.Column('type', sa.String(50), nullable=False, server_default='branch'),
        sa.Column('parent_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=True),
        sa.Column('gstin', sa.String(15), nullable=True),
        sa.Column('pan', sa.String(10), nullable=True),
        sa.Column('address_line1', sa.String(255), nullable=True),
        sa.Column('address_line2', sa.String(255), nullable=True),
        sa.Column('city', sa.String(100), nullable=True),
        sa.Column('state', sa.String(100), nullable=True),
        sa.Column('pincode', sa.String(10), nullable=True),
        sa.Column('country', sa.String(100), nullable=False, server_default='India'),
        sa.Column('phone', sa.String(20), nullable=True),
        sa.Column('email', sa.String(255), nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('settings', JSONB, nullable=False, server_default='{}'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_index('ix_organizations_parent_id', 'organizations', ['parent_id'])
    op.create_index('ix_organizations_type', 'organizations', ['type'])

    # Users
    op.create_table(
        'users',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('email', sa.String(255), unique=True, nullable=False),
        sa.Column('username', sa.String(100), unique=True, nullable=False),
        sa.Column('hashed_password', sa.String(255), nullable=False),
        sa.Column('full_name', sa.String(255), nullable=False),
        sa.Column('phone', sa.String(20), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='pending'),
        sa.Column('department', sa.String(100), nullable=True),
        sa.Column('designation', sa.String(100), nullable=True),
        sa.Column('reporting_manager_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('assigned_warehouse_ids', JSONB, nullable=False, server_default='[]'),
        sa.Column('assigned_territory_ids', JSONB, nullable=False, server_default='[]'),
        sa.Column('approval_limit', sa.Numeric(18, 2), nullable=True),
        sa.Column('mfa_enabled', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('mfa_secret', sa.String(255), nullable=True),
        sa.Column('last_login', sa.DateTime(timezone=True), nullable=True),
        sa.Column('failed_login_attempts', sa.Integer, nullable=False, server_default='0'),
        sa.Column('locked_until', sa.DateTime(timezone=True), nullable=True),
        sa.Column('avatar_url', sa.String(500), nullable=True),
        sa.Column('settings', JSONB, nullable=False, server_default='{}'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_index('ix_users_org_status', 'users', ['organization_id', 'status'])
    op.create_index('ix_users_reporting_manager', 'users', ['reporting_manager_id'])

    # User Warehouse Assignments
    op.create_table(
        'user_warehouse_assignments',
        sa.Column('user_id', UUID(as_uuid=True), sa.ForeignKey('users.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('assigned_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('assigned_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('is_default', sa.Boolean, nullable=False, server_default='false'),
    )

    # Warehouses
    op.create_table(
        'warehouses',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('type', sa.String(50), nullable=False, server_default='finished_goods'),
        sa.Column('address_line1', sa.String(255), nullable=True),
        sa.Column('address_line2', sa.String(255), nullable=True),
        sa.Column('city', sa.String(100), nullable=True),
        sa.Column('state', sa.String(100), nullable=True),
        sa.Column('pincode', sa.String(10), nullable=True),
        sa.Column('manager_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('allow_negative_stock', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('settings', JSONB, nullable=False, server_default='{}'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_warehouse_org_code', 'warehouses', ['organization_id', 'code'])
    op.create_index('ix_warehouses_org_type', 'warehouses', ['organization_id', 'type'])

    # Racks
    op.create_table(
        'racks',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id', ondelete='CASCADE'), nullable=False),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=True),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_rack_warehouse_code', 'racks', ['warehouse_id', 'code'])

    # Shelves
    op.create_table(
        'shelves',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('rack_id', UUID(as_uuid=True), sa.ForeignKey('racks.id', ondelete='CASCADE'), nullable=False),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_shelf_rack_code', 'shelves', ['rack_id', 'code'])

    # Bins
    op.create_table(
        'bins',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('shelf_id', UUID(as_uuid=True), sa.ForeignKey('shelves.id', ondelete='CASCADE'), nullable=False),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=True),
        sa.Column('max_capacity', sa.Numeric(18, 3), nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_bin_shelf_code', 'bins', ['shelf_id', 'code'])

    # Product Categories
    op.create_table(
        'product_categories',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('parent_id', UUID(as_uuid=True), sa.ForeignKey('product_categories.id'), nullable=True),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_category_org_code', 'product_categories', ['organization_id', 'code'])

    # UOMs
    op.create_table(
        'uoms',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('code', sa.String(20), nullable=False),
        sa.Column('name', sa.String(100), nullable=False),
        sa.Column('symbol', sa.String(10), nullable=False),
        sa.Column('is_base', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('decimal_places', sa.Integer, nullable=False, server_default='2'),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_uom_org_code', 'uoms', ['organization_id', 'code'])

    # UOM Conversions
    op.create_table(
        'uom_conversions',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('from_uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('to_uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('factor', sa.Numeric(18, 6), nullable=False),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_uom_conversion', 'uom_conversions', ['organization_id', 'from_uom_id', 'to_uom_id'])

    # Products
    op.create_table(
        'products',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('category_id', UUID(as_uuid=True), sa.ForeignKey('product_categories.id'), nullable=True),
        sa.Column('base_uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('type', sa.String(50), nullable=False, server_default='finished_good'),
        sa.Column('hsn_code', sa.String(20), nullable=True),
        sa.Column('gst_rate', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('is_batch_tracked', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('is_expiry_tracked', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('shelf_life_days', sa.Integer, nullable=True),
        sa.Column('min_stock_level', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('max_stock_level', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('reorder_level', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('reorder_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('standard_cost', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('standard_price', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('weight', sa.Numeric(10, 3), nullable=True),
        sa.Column('volume', sa.Numeric(10, 3), nullable=True),
        sa.Column('barcode', sa.String(100), nullable=True),
        sa.Column('qr_code', sa.String(500), nullable=True),
        sa.Column('image_url', sa.String(500), nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('is_saleable', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('is_purchasable', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('is_producible', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('attributes', JSONB, nullable=False, server_default='{}'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_product_org_code', 'products', ['organization_id', 'code'])
    op.create_index('ix_products_org_type', 'products', ['organization_id', 'type'])
    op.create_index('ix_products_barcode', 'products', ['barcode'])

    # Price Lists
    op.create_table(
        'price_lists',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('currency', sa.String(3), nullable=False, server_default='INR'),
        sa.Column('is_default', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('valid_from', sa.DateTime(timezone=True), nullable=False),
        sa.Column('valid_to', sa.DateTime(timezone=True), nullable=True),
        sa.Column('applies_to_channels', JSONB, nullable=False, server_default='[]'),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )

    op.create_table(
        'price_list_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('price_list_id', UUID(as_uuid=True), sa.ForeignKey('price_lists.id', ondelete='CASCADE'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('min_qty', sa.Numeric(18, 3), nullable=False, server_default='1'),
        sa.Column('max_qty', sa.Numeric(18, 3), nullable=True),
        sa.Column('price', sa.Numeric(18, 3), nullable=False),
        sa.Column('discount_percent', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_price_list_item', 'price_list_items', ['price_list_id', 'product_id', 'min_qty'])

    # Customers
    op.create_table(
        'customers',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('channel', sa.String(50), nullable=False, server_default='retail'),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('trade_name', sa.String(255), nullable=True),
        sa.Column('gstin', sa.String(15), nullable=True),
        sa.Column('pan', sa.String(10), nullable=True),
        sa.Column('customer_type', sa.String(50), nullable=True),
        sa.Column('credit_limit', sa.Numeric(18, 2), nullable=False, server_default='0'),
        sa.Column('credit_days', sa.Integer, nullable=False, server_default='30'),
        sa.Column('price_list_id', UUID(as_uuid=True), sa.ForeignKey('price_lists.id'), nullable=True),
        sa.Column('assigned_salesperson_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('assigned_warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=True),
        sa.Column('payment_terms', sa.String(255), nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('is_blocked', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('block_reason', sa.Text, nullable=True),
        sa.Column('metadata', JSONB, nullable=False, server_default='{}'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_customer_org_code', 'customers', ['organization_id', 'code'])
    op.create_index('ix_customers_org_channel', 'customers', ['organization_id', 'channel'])
    op.create_index('ix_customers_gstin', 'customers', ['gstin'])

    op.create_table(
        'customer_addresses',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('customer_id', UUID(as_uuid=True), sa.ForeignKey('customers.id', ondelete='CASCADE'), nullable=False),
        sa.Column('address_type', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('contact_person', sa.String(255), nullable=True),
        sa.Column('phone', sa.String(20), nullable=True),
        sa.Column('email', sa.String(255), nullable=True),
        sa.Column('address_line1', sa.String(255), nullable=False),
        sa.Column('address_line2', sa.String(255), nullable=True),
        sa.Column('city', sa.String(100), nullable=False),
        sa.Column('state', sa.String(100), nullable=False),
        sa.Column('pincode', sa.String(10), nullable=False),
        sa.Column('country', sa.String(100), nullable=False, server_default='India'),
        sa.Column('gstin', sa.String(15), nullable=True),
        sa.Column('latitude', sa.Numeric(10, 7), nullable=True),
        sa.Column('longitude', sa.Numeric(10, 7), nullable=True),
        sa.Column('is_default', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index('ix_customer_address_customer_default', 'customer_addresses', ['customer_id', 'is_default'])

    op.create_table(
        'customer_contacts',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('customer_id', UUID(as_uuid=True), sa.ForeignKey('customers.id', ondelete='CASCADE'), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('designation', sa.String(100), nullable=True),
        sa.Column('phone', sa.String(20), nullable=True),
        sa.Column('mobile', sa.String(20), nullable=True),
        sa.Column('email', sa.String(255), nullable=True),
        sa.Column('department', sa.String(100), nullable=True),
        sa.Column('is_primary', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )

    # Suppliers
    op.create_table(
        'suppliers',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('trade_name', sa.String(255), nullable=True),
        sa.Column('gstin', sa.String(15), nullable=True),
        sa.Column('pan', sa.String(10), nullable=True),
        sa.Column('supplier_type', sa.String(50), nullable=True),
        sa.Column('credit_days', sa.Integer, nullable=False, server_default='30'),
        sa.Column('payment_terms', sa.String(255), nullable=True),
        sa.Column('lead_time_days', sa.Integer, nullable=False, server_default='7'),
        sa.Column('rating', sa.Numeric(3, 2), nullable=True),
        sa.Column('price_list_id', UUID(as_uuid=True), sa.ForeignKey('price_lists.id'), nullable=True),
        sa.Column('default_warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('is_blocked', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('metadata', JSONB, nullable=False, server_default='{}'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_supplier_org_code', 'suppliers', ['organization_id', 'code'])
    op.create_index('ix_suppliers_gstin', 'suppliers', ['gstin'])

    op.create_table(
        'supplier_addresses',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('supplier_id', UUID(as_uuid=True), sa.ForeignKey('suppliers.id', ondelete='CASCADE'), nullable=False),
        sa.Column('address_type', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('contact_person', sa.String(255), nullable=True),
        sa.Column('phone', sa.String(20), nullable=True),
        sa.Column('email', sa.String(255), nullable=True),
        sa.Column('address_line1', sa.String(255), nullable=False),
        sa.Column('address_line2', sa.String(255), nullable=True),
        sa.Column('city', sa.String(100), nullable=False),
        sa.Column('state', sa.String(100), nullable=False),
        sa.Column('pincode', sa.String(10), nullable=False),
        sa.Column('country', sa.String(100), nullable=False, server_default='India'),
        sa.Column('gstin', sa.String(15), nullable=True),
        sa.Column('is_default', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )

    op.create_table(
        'supplier_contacts',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('supplier_id', UUID(as_uuid=True), sa.ForeignKey('suppliers.id', ondelete='CASCADE'), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('designation', sa.String(100), nullable=True),
        sa.Column('phone', sa.String(20), nullable=True),
        sa.Column('mobile', sa.String(20), nullable=True),
        sa.Column('email', sa.String(255), nullable=True),
        sa.Column('department', sa.String(100), nullable=True),
        sa.Column('is_primary', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )

    # Batches
    op.create_table(
        'batches',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('batch_number', sa.String(100), nullable=False),
        sa.Column('manufacture_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('expiry_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('supplier_batch_number', sa.String(100), nullable=True),
        sa.Column('supplier_id', UUID(as_uuid=True), sa.ForeignKey('suppliers.id'), nullable=True),
        sa.Column('source_type', sa.String(50), nullable=False),
        sa.Column('source_document_id', UUID(as_uuid=True), nullable=True),
        sa.Column('source_document_type', sa.String(50), nullable=True),
        sa.Column('mrp', sa.Numeric(18, 2), nullable=True),
        sa.Column('cost_price', sa.Numeric(18, 3), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='active'),
        sa.Column('quality_status', sa.String(50), nullable=False, server_default='pending'),
        sa.Column('retention_sample_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('attributes', JSONB, nullable=False, server_default='{}'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_batch_org_product_number', 'batches', ['organization_id', 'product_id', 'batch_number'])
    op.create_index('ix_batches_expiry', 'batches', ['expiry_date'])
    op.create_index('ix_batches_source', 'batches', ['source_document_id', 'source_document_type'])

    # Stock Ledger Entries
    op.create_table(
        'stock_ledger_entries',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('bin_id', UUID(as_uuid=True), sa.ForeignKey('bins.id'), nullable=True),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=True),
        sa.Column('transaction_type', sa.String(50), nullable=False),
        sa.Column('transaction_id', UUID(as_uuid=True), nullable=True),
        sa.Column('transaction_number', sa.String(100), nullable=True),
        sa.Column('transaction_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('qty_in', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('qty_out', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('balance_qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('valuation_rate', sa.Numeric(18, 3), nullable=True),
        sa.Column('valuation_amount', sa.Numeric(18, 3), nullable=True),
        sa.Column('stock_status', sa.String(50), nullable=False, server_default='available'),
        sa.Column('reference_doctype', sa.String(100), nullable=True),
        sa.Column('reference_docname', sa.String(100), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_index('ix_stock_ledger_org_product_warehouse', 'stock_ledger_entries', ['organization_id', 'product_id', 'warehouse_id'])
    op.create_index('ix_stock_ledger_org_batch', 'stock_ledger_entries', ['organization_id', 'batch_id'])
    op.create_index('ix_stock_ledger_transaction', 'stock_ledger_entries', ['transaction_id', 'transaction_type'])
    op.create_index('ix_stock_ledger_date', 'stock_ledger_entries', ['transaction_date'])

    # Stock Balances
    op.create_table(
        'stock_balances',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('bin_id', UUID(as_uuid=True), sa.ForeignKey('bins.id'), nullable=True),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=True),
        sa.Column('stock_status', sa.String(50), nullable=False, server_default='available'),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('valuation_rate', sa.Numeric(18, 3), nullable=True),
        sa.Column('last_transaction_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('last_updated', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_stock_balance', 'stock_balances', ['organization_id', 'product_id', 'warehouse_id', 'bin_id', 'batch_id', 'stock_status'])
    op.create_index('ix_stock_balance_org_product_warehouse_status', 'stock_balances', ['organization_id', 'product_id', 'warehouse_id', 'stock_status'])

    # Stock Reservations
    op.create_table(
        'stock_reservations',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=True),
        sa.Column('bin_id', UUID(as_uuid=True), sa.ForeignKey('bins.id'), nullable=True),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('reference_doctype', sa.String(100), nullable=False),
        sa.Column('reference_docname', sa.String(100), nullable=False),
        sa.Column('reference_doc_id', UUID(as_uuid=True), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='active'),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index('ix_stock_reservation_ref', 'stock_reservations', ['reference_doc_id', 'reference_doctype'])
    op.create_index('ix_stock_reservation_status', 'stock_reservations', ['status'])

    # Stock Transfers
    op.create_table(
        'stock_transfers',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('transfer_number', sa.String(100), nullable=False),
        sa.Column('from_warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('to_warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('transfer_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('expected_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('dispatched_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('received_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('vehicle_number', sa.String(50), nullable=True),
        sa.Column('driver_name', sa.String(255), nullable=True),
        sa.Column('driver_phone', sa.String(20), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('dispatched_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('received_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_stock_transfer_number', 'stock_transfers', ['organization_id', 'transfer_number'])

    op.create_table(
        'stock_transfer_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('transfer_id', UUID(as_uuid=True), sa.ForeignKey('stock_transfers.id', ondelete='CASCADE'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=True),
        sa.Column('from_bin_id', UUID(as_uuid=True), sa.ForeignKey('bins.id'), nullable=True),
        sa.Column('to_bin_id', UUID(as_uuid=True), sa.ForeignKey('bins.id'), nullable=True),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('dispatched_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('received_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('valuation_rate', sa.Numeric(18, 3), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
    )
    op.create_index('ix_stock_transfer_item_product', 'stock_transfer_items', ['product_id'])

    # Physical Stock Counts
    op.create_table(
        'physical_stock_counts',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('count_number', sa.String(100), nullable=False),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('count_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('counted_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('verified_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('approved_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_physical_count_number', 'physical_stock_counts', ['organization_id', 'count_number'])

    op.create_table(
        'physical_stock_count_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('count_id', UUID(as_uuid=True), sa.ForeignKey('physical_stock_counts.id', ondelete='CASCADE'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=True),
        sa.Column('bin_id', UUID(as_uuid=True), sa.ForeignKey('bins.id'), nullable=True),
        sa.Column('system_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('counted_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('variance_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('variance_value', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('valuation_rate', sa.Numeric(18, 3), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='pending'),
        sa.Column('notes', sa.Text, nullable=True),
    )

    # Sales Quotations
    op.create_table(
        'sales_quotations',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('quotation_number', sa.String(100), nullable=False),
        sa.Column('customer_id', UUID(as_uuid=True), sa.ForeignKey('customers.id'), nullable=False),
        sa.Column('customer_address_id', UUID(as_uuid=True), sa.ForeignKey('customer_addresses.id'), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('quotation_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('valid_till', sa.DateTime(timezone=True), nullable=False),
        sa.Column('price_list_id', UUID(as_uuid=True), sa.ForeignKey('price_lists.id'), nullable=True),
        sa.Column('currency', sa.String(3), nullable=False, server_default='INR'),
        sa.Column('exchange_rate', sa.Numeric(18, 6), nullable=False, server_default='1'),
        sa.Column('subtotal', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('discount_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('tax_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('total_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('terms_conditions', sa.Text, nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('prepared_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('approved_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_quotation_number', 'sales_quotations', ['organization_id', 'quotation_number'])

    op.create_table(
        'sales_quotation_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('quotation_id', UUID(as_uuid=True), sa.ForeignKey('sales_quotations.id', ondelete='CASCADE'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('rate', sa.Numeric(18, 3), nullable=False),
        sa.Column('discount_percent', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('discount_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('tax_rate', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('tax_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('amount', sa.Numeric(18, 3), nullable=False),
        sa.Column('sort_order', sa.Integer, nullable=False, server_default='0'),
    )

    # Sales Orders
    op.create_table(
        'sales_orders',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('order_number', sa.String(100), nullable=False),
        sa.Column('customer_id', UUID(as_uuid=True), sa.ForeignKey('customers.id'), nullable=False),
        sa.Column('customer_address_id', UUID(as_uuid=True), sa.ForeignKey('customer_addresses.id'), nullable=True),
        sa.Column('quotation_id', UUID(as_uuid=True), sa.ForeignKey('sales_quotations.id'), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('order_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('delivery_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=True),
        sa.Column('price_list_id', UUID(as_uuid=True), sa.ForeignKey('price_lists.id'), nullable=True),
        sa.Column('salesperson_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('currency', sa.String(3), nullable=False, server_default='INR'),
        sa.Column('exchange_rate', sa.Numeric(18, 6), nullable=False, server_default='1'),
        sa.Column('subtotal', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('discount_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('tax_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('total_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('advance_paid', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('terms_conditions', sa.Text, nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('credit_check_passed', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('stock_check_passed', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('approved_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('approved_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_sales_order_number', 'sales_orders', ['organization_id', 'order_number'])
    op.create_index('ix_sales_order_customer_date', 'sales_orders', ['customer_id', 'order_date'])
    op.create_index('ix_sales_order_status', 'sales_orders', ['status'])

    op.create_table(
        'sales_order_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('order_id', UUID(as_uuid=True), sa.ForeignKey('sales_orders.id', ondelete='CASCADE'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('rate', sa.Numeric(18, 3), nullable=False),
        sa.Column('discount_percent', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('discount_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('tax_rate', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('tax_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('amount', sa.Numeric(18, 3), nullable=False),
        sa.Column('delivered_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('invoiced_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('sort_order', sa.Integer, nullable=False, server_default='0'),
    )

    # Delivery Notes
    op.create_table(
        'delivery_notes',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('delivery_number', sa.String(100), nullable=False),
        sa.Column('sales_order_id', UUID(as_uuid=True), sa.ForeignKey('sales_orders.id'), nullable=True),
        sa.Column('customer_id', UUID(as_uuid=True), sa.ForeignKey('customers.id'), nullable=False),
        sa.Column('customer_address_id', UUID(as_uuid=True), sa.ForeignKey('customer_addresses.id'), nullable=True),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='pending'),
        sa.Column('delivery_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('vehicle_number', sa.String(50), nullable=True),
        sa.Column('driver_name', sa.String(255), nullable=True),
        sa.Column('driver_phone', sa.String(20), nullable=True),
        sa.Column('ewaybill_number', sa.String(50), nullable=True),
        sa.Column('ewaybill_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('delivered_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('delivered_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('received_by_name', sa.String(255), nullable=True),
        sa.Column('signature_url', sa.String(500), nullable=True),
        sa.Column('photo_url', sa.String(500), nullable=True),
        sa.Column('latitude', sa.Numeric(10, 7), nullable=True),
        sa.Column('longitude', sa.Numeric(10, 7), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_delivery_number', 'delivery_notes', ['organization_id', 'delivery_number'])

    op.create_table(
        'delivery_note_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('delivery_note_id', UUID(as_uuid=True), sa.ForeignKey('delivery_notes.id', ondelete='CASCADE'), nullable=False),
        sa.Column('sales_order_item_id', UUID(as_uuid=True), sa.ForeignKey('sales_order_items.id'), nullable=True),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=True),
        sa.Column('bin_id', UUID(as_uuid=True), sa.ForeignKey('bins.id'), nullable=True),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('rate', sa.Numeric(18, 3), nullable=False),
        sa.Column('amount', sa.Numeric(18, 3), nullable=False),
        sa.Column('serial_numbers', JSONB, nullable=False, server_default='[]'),
    )

    # Sales Invoices
    op.create_table(
        'sales_invoices',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('invoice_number', sa.String(100), nullable=False),
        sa.Column('sales_order_id', UUID(as_uuid=True), sa.ForeignKey('sales_orders.id'), nullable=True),
        sa.Column('delivery_note_id', UUID(as_uuid=True), sa.ForeignKey('delivery_notes.id'), nullable=True),
        sa.Column('customer_id', UUID(as_uuid=True), sa.ForeignKey('customers.id'), nullable=False),
        sa.Column('customer_address_id', UUID(as_uuid=True), sa.ForeignKey('customer_addresses.id'), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('invoice_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('due_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('currency', sa.String(3), nullable=False, server_default='INR'),
        sa.Column('exchange_rate', sa.Numeric(18, 6), nullable=False, server_default='1'),
        sa.Column('subtotal', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('discount_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('tax_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('total_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('paid_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('balance_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('irn', sa.String(100), nullable=True),
        sa.Column('irn_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('ack_number', sa.String(50), nullable=True),
        sa.Column('ack_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('is_e_invoice', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('gst_type', sa.String(20), nullable=False, server_default='B2B'),
        sa.Column('place_of_supply', sa.String(100), nullable=True),
        sa.Column('reverse_charge', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('terms_conditions', sa.Text, nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('issued_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('issued_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_sales_invoice_number', 'sales_invoices', ['organization_id', 'invoice_number'])
    op.create_index('ix_sales_invoice_customer_date', 'sales_invoices', ['customer_id', 'invoice_date'])
    op.create_index('ix_sales_invoice_status', 'sales_invoices', ['status'])

    op.create_table(
        'sales_invoice_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('invoice_id', UUID(as_uuid=True), sa.ForeignKey('sales_invoices.id', ondelete='CASCADE'), nullable=False),
        sa.Column('sales_order_item_id', UUID(as_uuid=True), sa.ForeignKey('sales_order_items.id'), nullable=True),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=True),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('rate', sa.Numeric(18, 3), nullable=False),
        sa.Column('discount_percent', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('discount_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('tax_rate', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('tax_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('amount', sa.Numeric(18, 3), nullable=False),
        sa.Column('hsn_code', sa.String(20), nullable=True),
    )

    # Payments
    op.create_table(
        'payments',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('payment_number', sa.String(100), nullable=False),
        sa.Column('payment_type', sa.String(50), nullable=False),
        sa.Column('mode', sa.String(50), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='pending'),
        sa.Column('party_type', sa.String(50), nullable=False),
        sa.Column('party_id', UUID(as_uuid=True), nullable=False),
        sa.Column('sales_invoice_id', UUID(as_uuid=True), sa.ForeignKey('sales_invoices.id'), nullable=True),
        sa.Column('purchase_invoice_id', UUID(as_uuid=True), nullable=True),
        sa.Column('amount', sa.Numeric(18, 3), nullable=False),
        sa.Column('currency', sa.String(3), nullable=False, server_default='INR'),
        sa.Column('exchange_rate', sa.Numeric(18, 6), nullable=False, server_default='1'),
        sa.Column('reference_number', sa.String(100), nullable=True),
        sa.Column('reference_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('bank_account_id', UUID(as_uuid=True), nullable=True),
        sa.Column('cheque_number', sa.String(50), nullable=True),
        sa.Column('cheque_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('cleared_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('posted_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('posted_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_payment_number', 'payments', ['organization_id', 'payment_number'])
    op.create_index('ix_payment_party', 'payments', ['party_type', 'party_id'])

    # Bank Accounts
    op.create_table(
        'bank_accounts',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('account_name', sa.String(255), nullable=False),
        sa.Column('bank_name', sa.String(255), nullable=False),
        sa.Column('branch', sa.String(255), nullable=True),
        sa.Column('account_number', sa.String(50), nullable=False),
        sa.Column('ifsc_code', sa.String(20), nullable=True),
        sa.Column('account_type', sa.String(50), nullable=False, server_default='current'),
        sa.Column('currency', sa.String(3), nullable=False, server_default='INR'),
        sa.Column('is_default', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('opening_balance', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('current_balance', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_bank_account', 'bank_accounts', ['organization_id', 'account_number'])

    # Purchase Requisitions
    op.create_table(
        'purchase_requisitions',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('requisition_number', sa.String(100), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('requisition_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('required_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('requested_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('approved_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('approved_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_requisition_number', 'purchase_requisitions', ['organization_id', 'requisition_number'])

    op.create_table(
        'purchase_requisition_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('requisition_id', UUID(as_uuid=True), sa.ForeignKey('purchase_requisitions.id', ondelete='CASCADE'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('estimated_rate', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('preferred_supplier_id', UUID(as_uuid=True), sa.ForeignKey('suppliers.id'), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
    )

    # Purchase Orders
    op.create_table(
        'purchase_orders',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('order_number', sa.String(100), nullable=False),
        sa.Column('supplier_id', UUID(as_uuid=True), sa.ForeignKey('suppliers.id'), nullable=False),
        sa.Column('supplier_address_id', UUID(as_uuid=True), sa.ForeignKey('supplier_addresses.id'), nullable=True),
        sa.Column('requisition_id', UUID(as_uuid=True), sa.ForeignKey('purchase_requisitions.id'), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('order_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('expected_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('currency', sa.String(3), nullable=False, server_default='INR'),
        sa.Column('exchange_rate', sa.Numeric(18, 6), nullable=False, server_default='1'),
        sa.Column('subtotal', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('discount_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('tax_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('total_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('terms_conditions', sa.Text, nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('approved_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('approved_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('sent_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('acknowledged_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_purchase_order_number', 'purchase_orders', ['organization_id', 'order_number'])
    op.create_index('ix_purchase_order_supplier_date', 'purchase_orders', ['supplier_id', 'order_date'])
    op.create_index('ix_purchase_order_status', 'purchase_orders', ['status'])

    op.create_table(
        'purchase_order_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('order_id', UUID(as_uuid=True), sa.ForeignKey('purchase_orders.id', ondelete='CASCADE'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('rate', sa.Numeric(18, 3), nullable=False),
        sa.Column('discount_percent', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('discount_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('tax_rate', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('tax_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('amount', sa.Numeric(18, 3), nullable=False),
        sa.Column('received_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('billed_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('sort_order', sa.Integer, nullable=False, server_default='0'),
    )

    # Purchase Receipts
    op.create_table(
        'purchase_receipts',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('receipt_number', sa.String(100), nullable=False),
        sa.Column('purchase_order_id', UUID(as_uuid=True), sa.ForeignKey('purchase_orders.id'), nullable=True),
        sa.Column('supplier_id', UUID(as_uuid=True), sa.ForeignKey('suppliers.id'), nullable=False),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('receipt_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('vehicle_number', sa.String(50), nullable=True),
        sa.Column('driver_name', sa.String(255), nullable=True),
        sa.Column('driver_phone', sa.String(20), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('received_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('qc_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('qc_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('qc_notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_purchase_receipt_number', 'purchase_receipts', ['organization_id', 'receipt_number'])

    op.create_table(
        'purchase_receipt_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('receipt_id', UUID(as_uuid=True), sa.ForeignKey('purchase_receipts.id', ondelete='CASCADE'), nullable=False),
        sa.Column('purchase_order_item_id', UUID(as_uuid=True), sa.ForeignKey('purchase_order_items.id'), nullable=True),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=True),
        sa.Column('bin_id', UUID(as_uuid=True), sa.ForeignKey('bins.id'), nullable=True),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('accepted_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('rejected_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('rate', sa.Numeric(18, 3), nullable=False),
        sa.Column('amount', sa.Numeric(18, 3), nullable=False),
        sa.Column('manufacture_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('expiry_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('supplier_batch_number', sa.String(100), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
    )

    # Purchase Invoices
    op.create_table(
        'purchase_invoices',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('invoice_number', sa.String(100), nullable=False),
        sa.Column('supplier_invoice_number', sa.String(100), nullable=False),
        sa.Column('supplier_id', UUID(as_uuid=True), sa.ForeignKey('suppliers.id'), nullable=False),
        sa.Column('purchase_order_id', UUID(as_uuid=True), sa.ForeignKey('purchase_orders.id'), nullable=True),
        sa.Column('receipt_id', UUID(as_uuid=True), sa.ForeignKey('purchase_receipts.id'), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('invoice_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('due_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('currency', sa.String(3), nullable=False, server_default='INR'),
        sa.Column('exchange_rate', sa.Numeric(18, 6), nullable=False, server_default='1'),
        sa.Column('subtotal', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('discount_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('tax_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('total_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('paid_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('balance_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('gst_type', sa.String(20), nullable=False, server_default='B2B'),
        sa.Column('place_of_supply', sa.String(100), nullable=True),
        sa.Column('reverse_charge', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('irn', sa.String(100), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('verified_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('verified_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('approved_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('approved_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_purchase_invoice_number', 'purchase_invoices', ['organization_id', 'invoice_number'])
    op.create_unique_constraint('uq_supplier_invoice_number', 'purchase_invoices', ['organization_id', 'supplier_id', 'supplier_invoice_number'])
    op.create_index('ix_purchase_invoice_supplier_date', 'purchase_invoices', ['supplier_id', 'invoice_date'])
    op.create_index('ix_purchase_invoice_status', 'purchase_invoices', ['status'])

    op.create_table(
        'purchase_invoice_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('invoice_id', UUID(as_uuid=True), sa.ForeignKey('purchase_invoices.id', ondelete='CASCADE'), nullable=False),
        sa.Column('purchase_order_item_id', UUID(as_uuid=True), sa.ForeignKey('purchase_order_items.id'), nullable=True),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('rate', sa.Numeric(18, 3), nullable=False),
        sa.Column('discount_percent', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('discount_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('tax_rate', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('tax_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('amount', sa.Numeric(18, 3), nullable=False),
        sa.Column('hsn_code', sa.String(20), nullable=True),
    )

    # Supplier Returns
    op.create_table(
        'supplier_returns',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('return_number', sa.String(100), nullable=False),
        sa.Column('supplier_id', UUID(as_uuid=True), sa.ForeignKey('suppliers.id'), nullable=False),
        sa.Column('purchase_receipt_id', UUID(as_uuid=True), sa.ForeignKey('purchase_receipts.id'), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('return_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('reason', sa.String(255), nullable=False),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('total_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('credit_note_number', sa.String(100), nullable=True),
        sa.Column('credit_note_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('approved_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_supplier_return_number', 'supplier_returns', ['organization_id', 'return_number'])

    op.create_table(
        'supplier_return_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('return_id', UUID(as_uuid=True), sa.ForeignKey('supplier_returns.id', ondelete='CASCADE'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=True),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('rate', sa.Numeric(18, 3), nullable=False),
        sa.Column('amount', sa.Numeric(18, 3), nullable=False),
        sa.Column('reason', sa.String(255), nullable=False),
        sa.Column('notes', sa.Text, nullable=True),
    )

    # BOM Headers
    op.create_table(
        'bom_headers',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('finished_product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('bom_number', sa.String(100), nullable=False),
        sa.Column('version', sa.String(50), nullable=False, server_default='1.0'),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('type', sa.String(50), nullable=False, server_default='manufacturing'),
        sa.Column('output_qty', sa.Numeric(18, 3), nullable=False, server_default='1'),
        sa.Column('output_uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('effective_from', sa.DateTime(timezone=True), nullable=False),
        sa.Column('effective_to', sa.DateTime(timezone=True), nullable=True),
        sa.Column('standard_yield_percent', sa.Numeric(5, 2), nullable=False, server_default='100'),
        sa.Column('standard_wastage_percent', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('labor_cost_per_unit', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('machine_cost_per_unit', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('overhead_cost_per_unit', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('approved_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('approved_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_bom_version', 'bom_headers', ['organization_id', 'finished_product_id', 'version'])
    op.create_unique_constraint('uq_bom_number', 'bom_headers', ['organization_id', 'bom_number'])

    op.create_table(
        'bom_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('bom_header_id', UUID(as_uuid=True), sa.ForeignKey('bom_headers.id', ondelete='CASCADE'), nullable=False),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('item_type', sa.String(50), nullable=False),
        sa.Column('qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('wastage_percent', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('is_mandatory', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('operation_sequence', sa.Integer, nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('sort_order', sa.Integer, nullable=False, server_default='0'),
    )
    op.create_index('ix_bom_item_product', 'bom_items', ['product_id'])

    op.create_table(
        'bom_operations',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('bom_header_id', UUID(as_uuid=True), sa.ForeignKey('bom_headers.id', ondelete='CASCADE'), nullable=False),
        sa.Column('sequence', sa.Integer, nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('work_center_id', UUID(as_uuid=True), nullable=True),
        sa.Column('estimated_duration_minutes', sa.Numeric(10, 2), nullable=False, server_default='0'),
        sa.Column('labor_hours_per_unit', sa.Numeric(10, 3), nullable=False, server_default='0'),
        sa.Column('machine_hours_per_unit', sa.Numeric(10, 3), nullable=False, server_default='0'),
        sa.Column('setup_time_minutes', sa.Numeric(10, 2), nullable=False, server_default='0'),
        sa.Column('is_quality_check', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('quality_check_template_id', UUID(as_uuid=True), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
    )
    op.create_unique_constraint('uq_bom_operation_sequence', 'bom_operations', ['bom_header_id', 'sequence'])

    # Work Centers
    op.create_table(
        'work_centers',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('type', sa.String(50), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('capacity_per_hour', sa.Numeric(10, 2), nullable=True),
        sa.Column('cost_per_hour', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('location', sa.String(255), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_work_center_code', 'work_centers', ['organization_id', 'code'])

    # Work Orders
    op.create_table(
        'work_orders',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('work_order_number', sa.String(100), nullable=False),
        sa.Column('bom_id', UUID(as_uuid=True), sa.ForeignKey('bom_headers.id'), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('priority', sa.String(50), nullable=False, server_default='normal'),
        sa.Column('planned_start_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('planned_end_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('actual_start_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('actual_end_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('planned_qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('produced_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('rejected_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('wip_warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=True),
        sa.Column('assigned_to', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('released_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('released_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('completed_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_work_order_number', 'work_orders', ['organization_id', 'work_order_number'])
    op.create_index('ix_work_order_status_date', 'work_orders', ['status', 'planned_start_date'])

    op.create_table(
        'material_issues',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('issue_number', sa.String(100), nullable=False),
        sa.Column('work_order_id', UUID(as_uuid=True), sa.ForeignKey('work_orders.id'), nullable=False),
        sa.Column('issue_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='pending'),
        sa.Column('issued_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_material_issue_number', 'material_issues', ['organization_id', 'issue_number'])

    op.create_table(
        'material_issue_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('issue_id', UUID(as_uuid=True), sa.ForeignKey('material_issues.id', ondelete='CASCADE'), nullable=False),
        sa.Column('bom_item_id', UUID(as_uuid=True), sa.ForeignKey('bom_items.id'), nullable=True),
        sa.Column('product_id', UUID(as_uuid=True), sa.ForeignKey('products.id'), nullable=False),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=True),
        sa.Column('bin_id', UUID(as_uuid=True), sa.ForeignKey('bins.id'), nullable=True),
        sa.Column('planned_qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('issued_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('uom_id', UUID(as_uuid=True), sa.ForeignKey('uoms.id'), nullable=False),
        sa.Column('valuation_rate', sa.Numeric(18, 3), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
    )

    op.create_table(
        'job_cards',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('job_card_number', sa.String(100), nullable=False),
        sa.Column('work_order_id', UUID(as_uuid=True), sa.ForeignKey('work_orders.id'), nullable=False),
        sa.Column('operation_id', UUID(as_uuid=True), sa.ForeignKey('bom_operations.id'), nullable=False),
        sa.Column('work_center_id', UUID(as_uuid=True), sa.ForeignKey('work_centers.id'), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='pending'),
        sa.Column('planned_start', sa.DateTime(timezone=True), nullable=False),
        sa.Column('planned_end', sa.DateTime(timezone=True), nullable=False),
        sa.Column('actual_start', sa.DateTime(timezone=True), nullable=True),
        sa.Column('actual_end', sa.DateTime(timezone=True), nullable=True),
        sa.Column('planned_qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('completed_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('rejected_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('assigned_operator_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('supervised_by_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('setup_time_actual', sa.Numeric(10, 2), nullable=False, server_default='0'),
        sa.Column('run_time_actual', sa.Numeric(10, 2), nullable=False, server_default='0'),
        sa.Column('downtime_minutes', sa.Numeric(10, 2), nullable=False, server_default='0'),
        sa.Column('downtime_reason', sa.Text, nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_job_card_number', 'job_cards', ['organization_id', 'job_card_number'])

    op.create_table(
        'production_entries',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('entry_number', sa.String(100), nullable=False),
        sa.Column('work_order_id', UUID(as_uuid=True), sa.ForeignKey('work_orders.id'), nullable=False),
        sa.Column('job_card_id', UUID(as_uuid=True), sa.ForeignKey('job_cards.id'), nullable=True),
        sa.Column('entry_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('entry_type', sa.String(50), nullable=False),
        sa.Column('finished_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('rejected_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('scrap_qty', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('batch_number', sa.String(100), nullable=True),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=True),
        sa.Column('recorded_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_production_entry_number', 'production_entries', ['organization_id', 'entry_number'])

    # Quality Check Templates
    op.create_table(
        'quality_check_templates',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('applies_to', sa.String(50), nullable=False),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_qc_template_code', 'quality_check_templates', ['organization_id', 'code'])

    op.create_table(
        'quality_check_parameters',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('template_id', UUID(as_uuid=True), sa.ForeignKey('quality_check_templates.id', ondelete='CASCADE'), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('parameter_type', sa.String(50), nullable=False),
        sa.Column('unit', sa.String(50), nullable=True),
        sa.Column('min_value', sa.Numeric(18, 3), nullable=True),
        sa.Column('max_value', sa.Numeric(18, 3), nullable=True),
        sa.Column('target_value', sa.Numeric(18, 3), nullable=True),
        sa.Column('options', JSONB, nullable=False, server_default='[]'),
        sa.Column('is_mandatory', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('sort_order', sa.Integer, nullable=False, server_default='0'),
    )

    # Quality Inspections
    op.create_table(
        'quality_inspections',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('inspection_number', sa.String(100), nullable=False),
        sa.Column('inspection_type', sa.String(50), nullable=False),
        sa.Column('reference_doctype', sa.String(100), nullable=False),
        sa.Column('reference_doc_id', UUID(as_uuid=True), nullable=False),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=True),
        sa.Column('template_id', UUID(as_uuid=True), sa.ForeignKey('quality_check_templates.id'), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='pending'),
        sa.Column('inspection_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('inspected_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('reviewed_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('reviewed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('overall_result', sa.String(50), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_quality_inspection_number', 'quality_inspections', ['organization_id', 'inspection_number'])
    op.create_index('ix_quality_inspection_ref', 'quality_inspections', ['reference_doctype', 'reference_doc_id'])

    op.create_table(
        'quality_inspection_results',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('inspection_id', UUID(as_uuid=True), sa.ForeignKey('quality_inspections.id', ondelete='CASCADE'), nullable=False),
        sa.Column('parameter_id', UUID(as_uuid=True), sa.ForeignKey('quality_check_parameters.id'), nullable=False),
        sa.Column('value_numeric', sa.Numeric(18, 3), nullable=True),
        sa.Column('value_text', sa.Text, nullable=True),
        sa.Column('value_boolean', sa.Boolean, nullable=True),
        sa.Column('value_select', sa.String(255), nullable=True),
        sa.Column('result', sa.String(50), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
    )

    # Batch Releases
    op.create_table(
        'batch_releases',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('batch_id', UUID(as_uuid=True), sa.ForeignKey('batches.id'), nullable=False),
        sa.Column('release_number', sa.String(100), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='pending'),
        sa.Column('release_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('released_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('released_qty', sa.Numeric(18, 3), nullable=False),
        sa.Column('quality_approval', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('cof_number', sa.String(100), nullable=True),
        sa.Column('cof_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('expiry_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_batch_release_number', 'batch_releases', ['organization_id', 'release_number'])

    # Finance - Accounts
    op.create_table(
        'accounts',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('account_type', sa.String(50), nullable=False),
        sa.Column('account_group', sa.String(50), nullable=False),
        sa.Column('parent_id', UUID(as_uuid=True), sa.ForeignKey('accounts.id'), nullable=True),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('is_control_account', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('control_account_type', sa.String(50), nullable=True),
        sa.Column('gst_applicable', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('gst_rate', sa.Numeric(5, 2), nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('opening_balance', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('opening_balance_type', sa.String(10), nullable=False, server_default='Dr'),
        sa.Column('current_balance', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_account_code', 'accounts', ['organization_id', 'code'])
    op.create_index('ix_account_type_group', 'accounts', ['account_type', 'account_group'])

    op.create_table(
        'journal_entries',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('entry_number', sa.String(100), nullable=False),
        sa.Column('entry_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('reference_doctype', sa.String(100), nullable=True),
        sa.Column('reference_doc_id', UUID(as_uuid=True), nullable=True),
        sa.Column('reference_docname', sa.String(100), nullable=True),
        sa.Column('narration', sa.Text, nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('total_debit', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('total_credit', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('is_auto_generated', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('posted_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('posted_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_journal_entry_number', 'journal_entries', ['organization_id', 'entry_number'])
    op.create_index('ix_journal_entry_ref', 'journal_entries', ['reference_doctype', 'reference_doc_id'])
    op.create_index('ix_journal_entry_date_status', 'journal_entries', ['entry_date', 'status'])

    op.create_table(
        'journal_entry_lines',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('journal_entry_id', UUID(as_uuid=True), sa.ForeignKey('journal_entries.id', ondelete='CASCADE'), nullable=False),
        sa.Column('account_id', UUID(as_uuid=True), sa.ForeignKey('accounts.id'), nullable=False),
        sa.Column('party_type', sa.String(50), nullable=True),
        sa.Column('party_id', UUID(as_uuid=True), nullable=True),
        sa.Column('debit', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('credit', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('narration', sa.Text, nullable=True),
        sa.Column('cost_center_id', UUID(as_uuid=True), nullable=True),
        sa.Column('project_id', UUID(as_uuid=True), nullable=True),
        sa.Column('sort_order', sa.Integer, nullable=False, server_default='0'),
    )

    op.create_table(
        'cost_centers',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('parent_id', UUID(as_uuid=True), sa.ForeignKey('cost_centers.id'), nullable=True),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_cost_center_code', 'cost_centers', ['organization_id', 'code'])

    op.create_table(
        'expense_claims',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('claim_number', sa.String(100), nullable=False),
        sa.Column('employee_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('claim_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('total_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('approved_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('paid_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('approved_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('approved_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('paid_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('paid_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('bank_account_id', UUID(as_uuid=True), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_expense_claim_number', 'expense_claims', ['organization_id', 'claim_number'])

    op.create_table(
        'expense_claim_items',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('claim_id', UUID(as_uuid=True), sa.ForeignKey('expense_claims.id', ondelete='CASCADE'), nullable=False),
        sa.Column('expense_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('account_id', UUID(as_uuid=True), sa.ForeignKey('accounts.id'), nullable=False),
        sa.Column('description', sa.Text, nullable=False),
        sa.Column('amount', sa.Numeric(18, 3), nullable=False),
        sa.Column('currency', sa.String(3), nullable=False, server_default='INR'),
        sa.Column('exchange_rate', sa.Numeric(18, 6), nullable=False, server_default='1'),
        sa.Column('tax_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('receipt_url', sa.String(500), nullable=True),
        sa.Column('is_billable', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('project_id', UUID(as_uuid=True), nullable=True),
        sa.Column('cost_center_id', UUID(as_uuid=True), sa.ForeignKey('cost_centers.id'), nullable=True),
        sa.Column('approved_amount', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('notes', sa.Text, nullable=True),
    )

    op.create_table(
        'gst_returns',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('return_type', sa.String(20), nullable=False),
        sa.Column('period', sa.String(20), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('filing_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('acknowledgment_number', sa.String(100), nullable=True),
        sa.Column('acknowledgment_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('total_tax_liability', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('itc_available', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('tax_paid', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('interest', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('late_fee', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('data_json', JSONB, nullable=False, server_default='{}'),
        sa.Column('error_message', sa.Text, nullable=True),
        sa.Column('filed_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_gst_return', 'gst_returns', ['organization_id', 'return_type', 'period'])

    op.create_table(
        'tds_entries',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('section', sa.String(20), nullable=False),
        sa.Column('party_type', sa.String(50), nullable=False),
        sa.Column('party_id', UUID(as_uuid=True), nullable=False),
        sa.Column('party_pan', sa.String(10), nullable=False),
        sa.Column('invoice_number', sa.String(100), nullable=False),
        sa.Column('invoice_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('invoice_amount', sa.Numeric(18, 3), nullable=False),
        sa.Column('tds_rate', sa.Numeric(5, 2), nullable=False),
        sa.Column('tds_amount', sa.Numeric(18, 3), nullable=False),
        sa.Column('payment_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('challan_number', sa.String(50), nullable=True),
        sa.Column('challan_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('quarter', sa.String(10), nullable=False),
        sa.Column('financial_year', sa.String(10), nullable=False),
        sa.Column('is_filed', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index('ix_tds_party_quarter', 'tds_entries', ['party_type', 'party_id', 'quarter', 'financial_year'])

    # HR - Attendance
    op.create_table(
        'attendance',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('employee_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('attendance_date', sa.Date, nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='absent'),
        sa.Column('shift_id', UUID(as_uuid=True), sa.ForeignKey('shifts.id'), nullable=True),
        sa.Column('check_in_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('check_out_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('check_in_latitude', sa.Numeric(10, 7), nullable=True),
        sa.Column('check_in_longitude', sa.Numeric(10, 7), nullable=True),
        sa.Column('check_out_latitude', sa.Numeric(10, 7), nullable=True),
        sa.Column('check_out_longitude', sa.Numeric(10, 7), nullable=True),
        sa.Column('work_hours', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('overtime_hours', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('late_minutes', sa.Integer, nullable=False, server_default='0'),
        sa.Column('early_departure_minutes', sa.Integer, nullable=False, server_default='0'),
        sa.Column('is_geo_fenced', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('geo_fence_passed', sa.Boolean, nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('approved_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_attendance_emp_date', 'attendance', ['organization_id', 'employee_id', 'attendance_date'])

    op.create_table(
        'shifts',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('start_time', sa.String(5), nullable=False),
        sa.Column('end_time', sa.String(5), nullable=False),
        sa.Column('grace_period_minutes', sa.Integer, nullable=False, server_default='15'),
        sa.Column('max_late_minutes', sa.Integer, nullable=False, server_default='30'),
        sa.Column('work_hours', sa.Numeric(5, 2), nullable=False, server_default='8'),
        sa.Column('is_night_shift', sa.Boolean, nullable=False, server_default='false'),
        sa.Column('applicable_days', JSONB, nullable=False, server_default='[]'),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_shift_code', 'shifts', ['organization_id', 'code'])

    op.create_table(
        'leave_applications',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('application_number', sa.String(100), nullable=False),
        sa.Column('employee_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('leave_type', sa.String(50), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('from_date', sa.Date, nullable=False),
        sa.Column('to_date', sa.Date, nullable=False),
        sa.Column('total_days', sa.Numeric(5, 2), nullable=False),
        sa.Column('reason', sa.Text, nullable=False),
        sa.Column('applied_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('approved_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('approved_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('rejection_reason', sa.Text, nullable=True),
        sa.Column('cancelled_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('cancelled_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_leave_application_number', 'leave_applications', ['organization_id', 'application_number'])

    op.create_table(
        'leave_balances',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('employee_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('leave_type', sa.String(50), nullable=False),
        sa.Column('financial_year', sa.String(10), nullable=False),
        sa.Column('opening_balance', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('accrued', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('used', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('carried_forward', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('current_balance', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_leave_balance', 'leave_balances', ['organization_id', 'employee_id', 'leave_type', 'financial_year'])

    op.create_table(
        'tasks',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('task_number', sa.String(100), nullable=False),
        sa.Column('title', sa.String(255), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='todo'),
        sa.Column('priority', sa.String(50), nullable=False, server_default='medium'),
        sa.Column('assignee_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('assigner_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('due_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('start_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('estimated_hours', sa.Numeric(5, 2), nullable=True),
        sa.Column('actual_hours', sa.Numeric(5, 2), nullable=False, server_default='0'),
        sa.Column('related_doctype', sa.String(100), nullable=True),
        sa.Column('related_doc_id', UUID(as_uuid=True), nullable=True),
        sa.Column('tags', JSONB, nullable=False, server_default='[]'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_task_number', 'tasks', ['organization_id', 'task_number'])
    op.create_index('ix_task_assignee_status', 'tasks', ['assignee_id', 'status'])

    op.create_table(
        'approvals',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('approval_number', sa.String(100), nullable=False),
        sa.Column('approval_type', sa.String(50), nullable=False),
        sa.Column('status', sa.String(50), nullable=False, server_default='pending'),
        sa.Column('title', sa.String(255), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('reference_doctype', sa.String(100), nullable=False),
        sa.Column('reference_doc_id', UUID(as_uuid=True), nullable=False),
        sa.Column('reference_docname', sa.String(100), nullable=True),
        sa.Column('requested_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('requested_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('approver_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('approver_role', sa.String(100), nullable=True),
        sa.Column('approval_limit', sa.Numeric(18, 3), nullable=True),
        sa.Column('decided_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('decided_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('decision', sa.String(50), nullable=True),
        sa.Column('decision_notes', sa.Text, nullable=True),
        sa.Column('escalated_to', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('escalated_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('escalation_level', sa.Integer, nullable=False, server_default='0'),
        sa.Column('priority', sa.String(50), nullable=False, server_default='medium'),
        sa.Column('due_date', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_approval_number', 'approvals', ['organization_id', 'approval_number'])
    op.create_index('ix_approval_ref', 'approvals', ['reference_doctype', 'reference_doc_id'])
    op.create_index('ix_approval_approver_status', 'approvals', ['approver_id', 'status'])

    # Logistics
    op.create_table(
        'vehicles',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('registration_number', sa.String(50), nullable=False),
        sa.Column('vehicle_type', sa.String(50), nullable=False),
        sa.Column('make_model', sa.String(255), nullable=True),
        sa.Column('capacity_weight_kg', sa.Numeric(10, 2), nullable=True),
        sa.Column('capacity_volume_cft', sa.Numeric(10, 2), nullable=True),
        sa.Column('owner_type', sa.String(50), nullable=False, server_default='company'),
        sa.Column('owner_name', sa.String(255), nullable=True),
        sa.Column('owner_contact', sa.String(20), nullable=True),
        sa.Column('insurance_expiry', sa.DateTime(timezone=True), nullable=True),
        sa.Column('fitness_expiry', sa.DateTime(timezone=True), nullable=True),
        sa.Column('permit_expiry', sa.DateTime(timezone=True), nullable=True),
        sa.Column('gps_device_id', sa.String(100), nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_vehicle_registration', 'vehicles', ['organization_id', 'registration_number'])

    op.create_table(
        'drivers',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('user_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True, unique=True),
        sa.Column('employee_code', sa.String(50), nullable=True),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('phone', sa.String(20), nullable=False),
        sa.Column('license_number', sa.String(50), nullable=False),
        sa.Column('license_expiry', sa.DateTime(timezone=True), nullable=False),
        sa.Column('license_type', sa.String(50), nullable=True),
        sa.Column('address', sa.Text, nullable=True),
        sa.Column('emergency_contact', sa.String(20), nullable=True),
        sa.Column('bank_account_id', UUID(as_uuid=True), nullable=True),
        sa.Column('default_vehicle_id', UUID(as_uuid=True), sa.ForeignKey('vehicles.id'), nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('rating', sa.Numeric(3, 2), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index('ix_driver_license_expiry', 'drivers', ['license_expiry'])

    op.create_table(
        'delivery_trips',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('trip_number', sa.String(100), nullable=False),
        sa.Column('trip_date', sa.DateTime(timezone=True), nullable=False),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('vehicle_id', UUID(as_uuid=True), sa.ForeignKey('vehicles.id'), nullable=True),
        sa.Column('driver_id', UUID(as_uuid=True), sa.ForeignKey('drivers.id'), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='draft'),
        sa.Column('planned_start_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('actual_start_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('actual_end_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('total_distance_km', sa.Numeric(10, 2), nullable=True),
        sa.Column('fuel_cost', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('toll_cost', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('driver_allowance', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('other_expenses', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('total_expenses', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('notes', sa.Text, nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('created_by', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
    )
    op.create_unique_constraint('uq_delivery_trip_number', 'delivery_trips', ['organization_id', 'trip_number'])

    op.create_table(
        'delivery_trip_stops',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('trip_id', UUID(as_uuid=True), sa.ForeignKey('delivery_trips.id', ondelete='CASCADE'), nullable=False),
        sa.Column('sequence', sa.Integer, nullable=False),
        sa.Column('delivery_note_id', UUID(as_uuid=True), sa.ForeignKey('delivery_notes.id'), nullable=True),
        sa.Column('customer_id', UUID(as_uuid=True), sa.ForeignKey('customers.id'), nullable=False),
        sa.Column('customer_address_id', UUID(as_uuid=True), sa.ForeignKey('customer_addresses.id'), nullable=True),
        sa.Column('status', sa.String(50), nullable=False, server_default='pending'),
        sa.Column('planned_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('actual_arrival_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('actual_departure_time', sa.DateTime(timezone=True), nullable=True),
        sa.Column('latitude', sa.Numeric(10, 7), nullable=True),
        sa.Column('longitude', sa.Numeric(10, 7), nullable=True),
        sa.Column('distance_from_previous_km', sa.Numeric(10, 2), nullable=True),
        sa.Column('cash_to_collect', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('cash_collected', sa.Numeric(18, 3), nullable=False, server_default='0'),
        sa.Column('payment_mode', sa.String(50), nullable=True),
        sa.Column('failure_reason', sa.Text, nullable=True),
        sa.Column('signature_url', sa.String(500), nullable=True),
        sa.Column('photo_url', sa.String(500), nullable=True),
        sa.Column('notes', sa.Text, nullable=True),
    )
    op.create_unique_constraint('uq_trip_stop_sequence', 'delivery_trip_stops', ['trip_id', 'sequence'])

    op.create_table(
        'gps_locations',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('trip_id', UUID(as_uuid=True), sa.ForeignKey('delivery_trips.id'), nullable=True),
        sa.Column('driver_id', UUID(as_uuid=True), sa.ForeignKey('drivers.id'), nullable=True),
        sa.Column('vehicle_id', UUID(as_uuid=True), sa.ForeignKey('vehicles.id'), nullable=True),
        sa.Column('latitude', sa.Numeric(10, 7), nullable=False),
        sa.Column('longitude', sa.Numeric(10, 7), nullable=False),
        sa.Column('speed_kmph', sa.Numeric(6, 2), nullable=True),
        sa.Column('heading', sa.Numeric(6, 2), nullable=True),
        sa.Column('accuracy_meters', sa.Numeric(6, 2), nullable=True),
        sa.Column('recorded_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('received_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_index('ix_gps_trip_time', 'gps_locations', ['trip_id', 'recorded_at'])
    op.create_index('ix_gps_driver_time', 'gps_locations', ['driver_id', 'recorded_at'])

    op.create_table(
        'routes',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('organization_id', UUID(as_uuid=True), sa.ForeignKey('organizations.id'), nullable=False),
        sa.Column('code', sa.String(50), nullable=False),
        sa.Column('name', sa.String(255), nullable=False),
        sa.Column('description', sa.Text, nullable=True),
        sa.Column('warehouse_id', UUID(as_uuid=True), sa.ForeignKey('warehouses.id'), nullable=False),
        sa.Column('salesperson_id', UUID(as_uuid=True), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('frequency', sa.String(50), nullable=False, server_default='daily'),
        sa.Column('day_of_week', sa.Integer, nullable=True),
        sa.Column('estimated_distance_km', sa.Numeric(10, 2), nullable=True),
        sa.Column('estimated_duration_minutes', sa.Integer, nullable=True),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
    )
    op.create_unique_constraint('uq_route_code', 'routes', ['organization_id', 'code'])

    op.create_table(
        'route_stops',
        sa.Column('id', UUID(as_uuid=True), primary_key=True),
        sa.Column('route_id', UUID(as_uuid=True), sa.ForeignKey('routes.id', ondelete='CASCADE'), nullable=False),
        sa.Column('sequence', sa.Integer, nullable=False),
        sa.Column('customer_id', UUID(as_uuid=True), sa.ForeignKey('customers.id'), nullable=False),
        sa.Column('customer_address_id', UUID(as_uuid=True), sa.ForeignKey('customer_addresses.id'), nullable=True),
        sa.Column('estimated_arrival', sa.String(5), nullable=True),
        sa.Column('estimated_departure', sa.String(5), nullable=True),
        sa.Column('service_time_minutes', sa.Integer, nullable=False, server_default='15'),
        sa.Column('is_active', sa.Boolean, nullable=False, server_default='true'),
    )
    op.create_unique_constraint('uq_route_stop_sequence', 'route_stops', ['route_id', 'sequence'])


def downgrade() -> None:
    # Drop all tables in reverse order
    op.drop_table('route_stops')
    op.drop_table('routes')
    op.drop_table('gps_locations')
    op.drop_table('delivery_trip_stops')
    op.drop_table('delivery_trips')
    op.drop_table('drivers')
    op.drop_table('vehicles')
    op.drop_table('approvals')
    op.drop_table('tasks')
    op.drop_table('leave_balances')
    op.drop_table('leave_applications')
    op.drop_table('shifts')
    op.drop_table('attendance')
    op.drop_table('tds_entries')
    op.drop_table('gst_returns')
    op.drop_table('expense_claim_items')
    op.drop_table('expense_claims')
    op.drop_table('cost_centers')
    op.drop_table('journal_entry_lines')
    op.drop_table('journal_entries')
    op.drop_table('accounts')
    op.drop_table('batch_releases')
    op.drop_table('quality_inspection_results')
    op.drop_table('quality_inspections')
    op.drop_table('quality_check_parameters')
    op.drop_table('quality_check_templates')
    op.drop_table('production_entries')
    op.drop_table('job_cards')
    op.drop_table('material_issue_items')
    op.drop_table('material_issues')
    op.drop_table('work_orders')
    op.drop_table('work_centers')
    op.drop_table('bom_operations')
    op.drop_table('bom_items')
    op.drop_table('bom_headers')
    op.drop_table('supplier_return_items')
    op.drop_table('supplier_returns')
    op.drop_table('purchase_invoice_items')
    op.drop_table('purchase_invoices')
    op.drop_table('purchase_receipt_items')
    op.drop_table('purchase_receipts')
    op.drop_table('purchase_order_items')
    op.drop_table('purchase_orders')
    op.drop_table('purchase_requisition_items')
    op.drop_table('purchase_requisitions')
    op.drop_table('bank_accounts')
    op.drop_table('payments')
    op.drop_table('sales_invoice_items')
    op.drop_table('sales_invoices')
    op.drop_table('delivery_note_items')
    op.drop_table('delivery_notes')
    op.drop_table('sales_order_items')
    op.drop_table('sales_orders')
    op.drop_table('sales_quotation_items')
    op.drop_table('sales_quotations')
    op.drop_table('physical_stock_count_items')
    op.drop_table('physical_stock_counts')
    op.drop_table('stock_transfer_items')
    op.drop_table('stock_transfers')
    op.drop_table('stock_reservations')
    op.drop_table('stock_balances')
    op.drop_table('stock_ledger_entries')
    op.drop_table('batches')
    op.drop_table('supplier_contacts')
    op.drop_table('supplier_addresses')
    op.drop_table('suppliers')
    op.drop_table('customer_contacts')
    op.drop_table('customer_addresses')
    op.drop_table('customers')
    op.drop_table('price_list_items')
    op.drop_table('price_lists')
    op.drop_table('products')
    op.drop_table('uom_conversions')
    op.drop_table('uoms')
    op.drop_table('product_categories')
    op.drop_table('bins')
    op.drop_table('shelves')
    op.drop_table('racks')
    op.drop_table('warehouses')
    op.drop_table('user_warehouse_assignments')
    op.drop_table('users')
    op.drop_table('organizations')