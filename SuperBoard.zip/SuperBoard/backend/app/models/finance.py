import uuid
from datetime import datetime, timezone
from typing import Optional, List
from sqlalchemy import (
    String, Text, DateTime, Boolean, ForeignKey, Enum, Index, UniqueConstraint, Numeric, Integer, CheckConstraint
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.core.database import Base
import enum


class AccountType(str, enum.Enum):
    ASSET = "asset"
    LIABILITY = "liability"
    EQUITY = "equity"
    INCOME = "income"
    EXPENSE = "expense"


class AccountGroup(str, enum.Enum):
    CURRENT_ASSET = "current_asset"
    FIXED_ASSET = "fixed_asset"
    CURRENT_LIABILITY = "current_liability"
    LONG_TERM_LIABILITY = "long_term_liability"
    SHARE_CAPITAL = "share_capital"
    RESERVES_SURPLUS = "reserves_surplus"
    DIRECT_INCOME = "direct_income"
    INDIRECT_INCOME = "indirect_income"
    DIRECT_EXPENSE = "direct_expense"
    INDIRECT_EXPENSE = "indirect_expense"


class Account(Base):
    __tablename__ = "accounts"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    account_type: Mapped[AccountType] = mapped_column(Enum(AccountType), nullable=False)
    account_group: Mapped[AccountGroup] = mapped_column(Enum(AccountGroup), nullable=False)
    parent_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("accounts.id"), nullable=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_control_account: Mapped[bool] = mapped_column(Boolean, default=False)  # For AR, AP, Stock, etc.
    control_account_type: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)  # receivable, payable, stock, cash, bank
    gst_applicable: Mapped[bool] = mapped_column(Boolean, default=False)
    gst_rate: Mapped[Optional[float]] = mapped_column(Numeric(5, 2), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    opening_balance: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    opening_balance_type: Mapped[str] = mapped_column(String(10), default="Dr")  # Dr, Cr
    current_balance: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    parent: Mapped[Optional["Account"]] = relationship("Account", remote_side=[id], backref="children")
    journal_entries: Mapped[List["JournalEntryLine"]] = relationship("JournalEntryLine", back_populates="account")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "code", name="uq_account_code"),
        Index("ix_account_type_group", "account_type", "account_group"),
    )


class JournalEntryStatus(str, enum.Enum):
    DRAFT = "draft"
    POSTED = "posted"
    CANCELLED = "cancelled"


class JournalEntry(Base):
    __tablename__ = "journal_entries"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    entry_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    entry_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    reference_doctype: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    reference_doc_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    reference_docname: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    narration: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[JournalEntryStatus] = mapped_column(Enum(JournalEntryStatus), default=JournalEntryStatus.DRAFT, nullable=False)
    total_debit: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    total_credit: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    is_auto_generated: Mapped[bool] = mapped_column(Boolean, default=False)
    posted_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    posted_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    lines: Mapped[List["JournalEntryLine"]] = relationship("JournalEntryLine", back_populates="journal_entry", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "entry_number", name="uq_journal_entry_number"),
        Index("ix_journal_entry_ref", "reference_doctype", "reference_doc_id"),
        Index("ix_journal_entry_date_status", "entry_date", "status"),
    )


class JournalEntryLine(Base):
    __tablename__ = "journal_entry_lines"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    journal_entry_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("journal_entries.id", ondelete="CASCADE"), nullable=False, index=True)
    account_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("accounts.id"), nullable=False, index=True)
    party_type: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)  # customer, supplier, employee
    party_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    debit: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    credit: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    narration: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    cost_center_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("cost_centers.id"), nullable=True)
    project_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    
    # Relationships
    journal_entry: Mapped["JournalEntry"] = relationship("JournalEntry", back_populates="lines")
    account: Mapped["Account"] = relationship("Account", back_populates="journal_entries")
    cost_center: Mapped[Optional["CostCenter"]] = relationship("CostCenter")
    
    __table_args__ = (
        CheckConstraint("(debit > 0 AND credit = 0) OR (debit = 0 AND credit > 0) OR (debit = 0 AND credit = 0)", name="ck_journal_line_debit_credit"),
    )


class CostCenter(Base):
    __tablename__ = "cost_centers"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    parent_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("cost_centers.id"), nullable=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    parent: Mapped[Optional["CostCenter"]] = relationship("CostCenter", remote_side=[id], backref="children")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "code", name="uq_cost_center_code"),
    )


class ExpenseClaimStatus(str, enum.Enum):
    DRAFT = "draft"
    SUBMITTED = "submitted"
    APPROVED = "approved"
    REJECTED = "rejected"
    PAID = "paid"
    CANCELLED = "cancelled"


class ExpenseClaim(Base):
    __tablename__ = "expense_claims"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    claim_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    employee_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    status: Mapped[ExpenseClaimStatus] = mapped_column(Enum(ExpenseClaimStatus), default=ExpenseClaimStatus.DRAFT, nullable=False)
    claim_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    total_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    approved_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    paid_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    approved_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    paid_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    paid_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    bank_account_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bank_accounts.id"), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    employee: Mapped["User"] = relationship("User", foreign_keys=[employee_id])
    items: Mapped[List["ExpenseClaimItem"]] = relationship("ExpenseClaimItem", back_populates="claim", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "claim_number", name="uq_expense_claim_number"),
    )


class ExpenseClaimItem(Base):
    __tablename__ = "expense_claim_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    claim_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("expense_claims.id", ondelete="CASCADE"), nullable=False, index=True)
    expense_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    account_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("accounts.id"), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="INR")
    exchange_rate: Mapped[float] = mapped_column(Numeric(18, 6), default=1)
    tax_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    receipt_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    is_billable: Mapped[bool] = mapped_column(Boolean, default=False)
    project_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    cost_center_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("cost_centers.id"), nullable=True)
    approved_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Relationships
    claim: Mapped["ExpenseClaim"] = relationship("ExpenseClaim", back_populates="items")
    account: Mapped["Account"] = relationship("Account")
    cost_center: Mapped[Optional["CostCenter"]] = relationship("CostCenter")


class GSTReturnPeriod(str, enum.Enum):
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"


class GSTReturn(Base):
    __tablename__ = "gst_returns"
    
    class Status(str, enum.Enum):
        DRAFT = "draft"
        COMPUTED = "computed"
        FILED = "filed"
        ERROR = "error"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    return_type: Mapped[str] = mapped_column(String(20), nullable=False)  # GSTR-1, GSTR-3B
    period: Mapped[str] = mapped_column(String(20), nullable=False)  # YYYY-MM
    status: Mapped[Status] = mapped_column(Enum(Status), default=Status.DRAFT, nullable=False)
    filing_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    acknowledgment_number: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    acknowledgment_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    total_tax_liability: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    itc_available: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    tax_paid: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    interest: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    late_fee: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    data_json: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    filed_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    __table_args__ = (
        UniqueConstraint("organization_id", "return_type", "period", name="uq_gst_return"),
    )


class TDSEntry(Base):
    __tablename__ = "tds_entries"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    section: Mapped[str] = mapped_column(String(20), nullable=False)  # 194C, 194J, etc.
    party_type: Mapped[str] = mapped_column(String(50), nullable=False)  # supplier, contractor, professional
    party_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    party_pan: Mapped[str] = mapped_column(String(10), nullable=False)
    invoice_number: Mapped[str] = mapped_column(String(100), nullable=False)
    invoice_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    invoice_amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    tds_rate: Mapped[float] = mapped_column(Numeric(5, 2), nullable=False)
    tds_amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    payment_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    challan_number: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    challan_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    quarter: Mapped[str] = mapped_column(String(10), nullable=False)  # Q1, Q2, Q3, Q4
    financial_year: Mapped[str] = mapped_column(String(10), nullable=False)  # 2026-27
    is_filed: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    __table_args__ = (
        Index("ix_tds_party_quarter", "party_type", "party_id", "quarter", "financial_year"),
    )