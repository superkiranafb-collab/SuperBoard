import uuid
from datetime import datetime, timezone
from typing import Optional, List
from sqlalchemy import (
    String, Text, DateTime, Boolean, ForeignKey, Enum, Index, UniqueConstraint, Numeric, Integer, CheckConstraint
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.core.database import Base
import enum


class VehicleType(str, enum.Enum):
    BIKE = "bike"
    AUTO = "auto"
    SMALL_TRUCK = "small_truck"
    MEDIUM_TRUCK = "medium_truck"
    LARGE_TRUCK = "large_truck"
    CONTAINER = "container"
    OTHER = "other"


class Vehicle(Base):
    __tablename__ = "vehicles"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    registration_number: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    vehicle_type: Mapped[VehicleType] = mapped_column(Enum(VehicleType), nullable=False)
    make_model: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    capacity_weight_kg: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    capacity_volume_cft: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    owner_type: Mapped[str] = mapped_column(String(50), default="company")  # company, hired, driver_owned
    owner_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    owner_contact: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    insurance_expiry: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    fitness_expiry: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    permit_expiry: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    gps_device_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    __table_args__ = (
        UniqueConstraint("organization_id", "registration_number", name="uq_vehicle_registration"),
    )


class Driver(Base):
    __tablename__ = "drivers"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    user_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True, unique=True)
    employee_code: Mapped[Optional[str]] = mapped_column(String(50), nullable=True, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    phone: Mapped[str] = mapped_column(String(20), nullable=False)
    license_number: Mapped[str] = mapped_column(String(50), nullable=False)
    license_expiry: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    license_type: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    address: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    emergency_contact: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    bank_account_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bank_accounts.id"), nullable=True)
    default_vehicle_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("vehicles.id"), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    rating: Mapped[Optional[float]] = mapped_column(Numeric(3, 2), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    user: Mapped[Optional["User"]] = relationship("User")
    bank_account: Mapped[Optional["BankAccount"]] = relationship("BankAccount")
    default_vehicle: Mapped[Optional["Vehicle"]] = relationship("Vehicle")
    
    __table_args__ = (
        Index("ix_driver_license_expiry", "license_expiry"),
    )


class DeliveryTripStatus(str, enum.Enum):
    DRAFT = "draft"
    PLANNED = "planned"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class DeliveryTrip(Base):
    __tablename__ = "delivery_trips"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    trip_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    trip_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False)
    vehicle_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("vehicles.id"), nullable=True)
    driver_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("drivers.id"), nullable=True)
    status: Mapped[DeliveryTripStatus] = mapped_column(Enum(DeliveryTripStatus), default=DeliveryTripStatus.DRAFT, nullable=False)
    planned_start_time: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    actual_start_time: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    actual_end_time: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    total_distance_km: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    fuel_cost: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    toll_cost: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    driver_allowance: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    other_expenses: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    total_expenses: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    warehouse: Mapped["Warehouse"] = relationship("Warehouse")
    vehicle: Mapped[Optional["Vehicle"]] = relationship("Vehicle")
    driver: Mapped[Optional["Driver"]] = relationship("Driver")
    stops: Mapped[List["DeliveryTripStop"]] = relationship("DeliveryTripStop", back_populates="trip", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "trip_number", name="uq_delivery_trip_number"),
    )


class DeliveryTripStop(Base):
    __tablename__ = "delivery_trip_stops"
    
    class StopStatus(str, enum.Enum):
        PENDING = "pending"
        IN_PROGRESS = "in_progress"
        DELIVERED = "delivered"
        PARTIAL = "partial"
        FAILED = "failed"
        SKIPPED = "skipped"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    trip_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("delivery_trips.id", ondelete="CASCADE"), nullable=False, index=True)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    delivery_note_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("delivery_notes.id"), nullable=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("customers.id"), nullable=False)
    customer_address_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("customer_addresses.id"), nullable=True)
    status: Mapped[StopStatus] = mapped_column(Enum(StopStatus), default=StopStatus.PENDING, nullable=False)
    planned_time: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    actual_arrival_time: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    actual_departure_time: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    distance_from_previous_km: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    cash_to_collect: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    cash_collected: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    payment_mode: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    failure_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    signature_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    photo_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Relationships
    trip: Mapped["DeliveryTrip"] = relationship("DeliveryTrip", back_populates="stops")
    delivery_note: Mapped[Optional["DeliveryNote"]] = relationship("DeliveryNote")
    customer: Mapped["Customer"] = relationship("Customer")
    customer_address: Mapped[Optional["CustomerAddress"]] = relationship("CustomerAddress")
    
    __table_args__ = (
        UniqueConstraint("trip_id", "sequence", name="uq_trip_stop_sequence"),
    )


class DeliveryNote(Base):
    __tablename__ = "delivery_notes"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    delivery_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    sales_order_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("sales_orders.id"), nullable=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("customers.id"), nullable=False)
    customer_address_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("customer_addresses.id"), nullable=True)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False)
    status: Mapped[str] = mapped_column(String(50), default="pending", nullable=False)
    delivery_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    vehicle_number: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    driver_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    driver_phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    ewaybill_number: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    ewaybill_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    delivered_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    delivered_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    received_by_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    signature_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    photo_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    sales_order: Mapped[Optional["SalesOrder"]] = relationship("SalesOrder")
    customer: Mapped["Customer"] = relationship("Customer")
    customer_address: Mapped[Optional["CustomerAddress"]] = relationship("CustomerAddress")
    warehouse: Mapped["Warehouse"] = relationship("Warehouse")
    items: Mapped[List["DeliveryNoteItem"]] = relationship("DeliveryNoteItem", back_populates="delivery_note", cascade="all, delete-orphan")
    trip: Mapped[Optional["DeliveryTrip"]] = relationship("DeliveryTrip", back_populates="delivery_note")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "delivery_number", name="uq_delivery_number"),
    )


class DeliveryNoteItem(Base):
    __tablename__ = "delivery_note_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    delivery_note_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("delivery_notes.id", ondelete="CASCADE"), nullable=False, index=True)
    sales_order_item_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("sales_order_items.id"), nullable=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True)
    bin_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bins.id"), nullable=True)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    rate: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    serial_numbers: Mapped[Optional[List[str]]] = mapped_column(JSONB, default=list, nullable=False)
    
    # Relationships
    delivery_note: Mapped["DeliveryNote"] = relationship("DeliveryNote", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    batch: Mapped[Optional["Batch"]] = relationship("Batch")
    bin: Mapped[Optional["Bin"]] = relationship("Bin")
    uom: Mapped["UOM"] = relationship("UOM")


class GPSLocation(Base):
    __tablename__ = "gps_locations"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    trip_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("delivery_trips.id"), nullable=True, index=True)
    driver_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("drivers.id"), nullable=True, index=True)
    vehicle_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("vehicles.id"), nullable=True)
    latitude: Mapped[float] = mapped_column(Numeric(10, 7), nullable=False)
    longitude: Mapped[float] = mapped_column(Numeric(10, 7), nullable=False)
    speed_kmph: Mapped[Optional[float]] = mapped_column(Numeric(6, 2), nullable=True)
    heading: Mapped[Optional[float]] = mapped_column(Numeric(6, 2), nullable=True)
    accuracy_meters: Mapped[Optional[float]] = mapped_column(Numeric(6, 2), nullable=True)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    
    __table_args__ = (
        Index("ix_gps_trip_time", "trip_id", "recorded_at"),
        Index("ix_gps_driver_time", "driver_id", "recorded_at"),
    )


class Route(Base):
    __tablename__ = "routes"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False)
    salesperson_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    frequency: Mapped[str] = mapped_column(String(50), default="daily")  # daily, weekly, biweekly, monthly
    day_of_week: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)  # 0=Mon
    estimated_distance_km: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    estimated_duration_minutes: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    warehouse: Mapped["Warehouse"] = relationship("Warehouse")
    salesperson: Mapped[Optional["User"]] = relationship("User")
    stops: Mapped[List["RouteStop"]] = relationship("RouteStop", back_populates="route", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "code", name="uq_route_code"),
    )


class RouteStop(Base):
    __tablename__ = "route_stops"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    route_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("routes.id", ondelete="CASCADE"), nullable=False, index=True)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("customers.id"), nullable=False)
    customer_address_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("customer_addresses.id"), nullable=True)
    estimated_arrival: Mapped[Optional[str]] = mapped_column(String(5), nullable=True)  # HH:MM
    estimated_departure: Mapped[Optional[str]] = mapped_column(String(5), nullable=True)  # HH:MM
    service_time_minutes: Mapped[int] = mapped_column(Integer, default=15)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Relationships
    route: Mapped["Route"] = relationship("Route", back_populates="stops")
    customer: Mapped["Customer"] = relationship("Customer")
    customer_address: Mapped[Optional["CustomerAddress"]] = relationship("CustomerAddress")
    
    __table_args__ = (
        UniqueConstraint("route_id", "sequence", name="uq_route_stop_sequence"),
    )