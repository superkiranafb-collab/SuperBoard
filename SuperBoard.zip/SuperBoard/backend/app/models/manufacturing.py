import uuid
from datetime import datetime, timezone
from typing import Optional, List
from sqlalchemy import (
    String, Text, DateTime, Boolean, ForeignKey, Enum, Index, UniqueConstraint, Numeric, Integer, CheckConstraint
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.core.database import Base
import enum


class BOMStatus(str, enum.Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    OBSOLETE = "obsolete"
    ARCHIVED = "archived"


class BOMType(str, enum.Enum):
    MANUFACTURING = "manufacturing"
    REWORK = "rework"
    DISASSEMBLY = "disassembly"


class BOMHeader(Base):
    __tablename__ = "bom_headers"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    finished_product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False, index=True)
    bom_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    version: Mapped[str] = mapped_column(String(50), nullable=False, default="1.0")
    status: Mapped[BOMStatus] = mapped_column(Enum(BOMStatus), default=BOMStatus.DRAFT, nullable=False)
    type: Mapped[BOMType] = mapped_column(Enum(BOMType), default=BOMType.MANUFACTURING, nullable=False)
    output_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=1)
    output_uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    effective_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    effective_to: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    standard_yield_percent: Mapped[float] = mapped_column(Numeric(5, 2), default=100)
    standard_wastage_percent: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    labor_cost_per_unit: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    machine_cost_per_unit: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    overhead_cost_per_unit: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    approved_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    finished_product: Mapped["Product"] = relationship("Product", back_populates="bom_headers", foreign_keys=[finished_product_id])
    output_uom: Mapped["UOM"] = relationship("UOM", foreign_keys=[output_uom_id])
    items: Mapped[List["BOMItem"]] = relationship("BOMItem", back_populates="bom_header", cascade="all, delete-orphan")
    operations: Mapped[List["BOMOperation"]] = relationship("BOMOperation", back_populates="bom_header", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "finished_product_id", "version", name="uq_bom_version"),
        UniqueConstraint("organization_id", "bom_number", name="uq_bom_number"),
    )


class BOMItem(Base):
    __tablename__ = "bom_items"
    
    class ItemType(str, enum.Enum):
        RAW_MATERIAL = "raw_material"
        PACKAGING = "packaging"
        CONSUMABLE = "consumable"
        SUB_ASSEMBLY = "sub_assembly"
        BY_PRODUCT = "by_product"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    bom_header_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("bom_headers.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    item_type: Mapped[ItemType] = mapped_column(Enum(ItemType), nullable=False)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    wastage_percent: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    is_mandatory: Mapped[bool] = mapped_column(Boolean, default=True)
    operation_sequence: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)  # Which operation this material is consumed at
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    
    # Relationships
    bom_header: Mapped["BOMHeader"] = relationship("BOMHeader", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    uom: Mapped["UOM"] = relationship("UOM")
    
    __table_args__ = (
        Index("ix_bom_item_product", "product_id"),
    )


class BOMOperation(Base):
    __tablename__ = "bom_operations"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    bom_header_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("bom_headers.id", ondelete="CASCADE"), nullable=False, index=True)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    work_center_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("work_centers.id"), nullable=True)
    estimated_duration_minutes: Mapped[float] = mapped_column(Numeric(10, 2), default=0)
    labor_hours_per_unit: Mapped[float] = mapped_column(Numeric(10, 3), default=0)
    machine_hours_per_unit: Mapped[float] = mapped_column(Numeric(10, 3), default=0)
    setup_time_minutes: Mapped[float] = mapped_column(Numeric(10, 2), default=0)
    is_quality_check: Mapped[bool] = mapped_column(Boolean, default=False)
    quality_check_template_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("quality_check_templates.id"), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Relationships
    bom_header: Mapped["BOMHeader"] = relationship("BOMHeader", back_populates="operations")
    work_center: Mapped[Optional["WorkCenter"]] = relationship("WorkCenter")
    quality_check_template: Mapped[Optional["QualityCheckTemplate"]] = relationship("QualityCheckTemplate")
    
    __table_args__ = (
        UniqueConstraint("bom_header_id", "sequence", name="uq_bom_operation_sequence"),
    )


class WorkCenterType(str, enum.Enum):
    MACHINE = "machine"
    LABOR = "labor"
    MIXED = "mixed"
    QUALITY = "quality"
    PACKAGING = "packaging"


class WorkCenter(Base):
    __tablename__ = "work_centers"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    type: Mapped[WorkCenterType] = mapped_column(Enum(WorkCenterType), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    capacity_per_hour: Mapped[Optional[float]] = mapped_column(Numeric(10, 2), nullable=True)
    cost_per_hour: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    location: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    __table_args__ = (
        UniqueConstraint("organization_id", "code", name="uq_work_center_code"),
    )


class WorkOrderStatus(str, enum.Enum):
    DRAFT = "draft"
    PLANNED = "planned"
    RELEASED = "released"
    IN_PROGRESS = "in_progress"
    ON_HOLD = "on_hold"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    CLOSED = "closed"


class WorkOrderPriority(str, enum.Enum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    URGENT = "urgent"


class WorkOrder(Base):
    __tablename__ = "work_orders"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    work_order_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    bom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("bom_headers.id"), nullable=False)
    status: Mapped[WorkOrderStatus] = mapped_column(Enum(WorkOrderStatus), default=WorkOrderStatus.DRAFT, nullable=False)
    priority: Mapped[WorkOrderPriority] = mapped_column(Enum(WorkOrderPriority), default=WorkOrderPriority.NORMAL, nullable=False)
    planned_start_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    planned_end_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    actual_start_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    actual_end_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    planned_qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    produced_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    rejected_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False)  # Output warehouse
    wip_warehouse_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=True)
    assigned_to: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    released_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    released_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    bom: Mapped["BOMHeader"] = relationship("BOMHeader")
    warehouse: Mapped["Warehouse"] = relationship("Warehouse", foreign_keys=[warehouse_id])
    wip_warehouse: Mapped[Optional["Warehouse"]] = relationship("Warehouse", foreign_keys=[wip_warehouse_id])
    assigned_user: Mapped[Optional["User"]] = relationship("User", foreign_keys=[assigned_to])
    material_issues: Mapped[List["MaterialIssue"]] = relationship("MaterialIssue", back_populates="work_order", cascade="all, delete-orphan")
    job_cards: Mapped[List["JobCard"]] = relationship("JobCard", back_populates="work_order", cascade="all, delete-orphan")
    production_entries: Mapped[List["ProductionEntry"]] = relationship("ProductionEntry", back_populates="work_order", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "work_order_number", name="uq_work_order_number"),
        Index("ix_work_order_status_date", "status", "planned_start_date"),
    )


class MaterialIssue(Base):
    __tablename__ = "material_issues"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    issue_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    work_order_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("work_orders.id"), nullable=False, index=True)
    issue_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    status: Mapped[str] = mapped_column(String(50), default="pending")  # pending, partial, completed
    issued_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    work_order: Mapped["WorkOrder"] = relationship("WorkOrder", back_populates="material_issues")
    items: Mapped[List["MaterialIssueItem"]] = relationship("MaterialIssueItem", back_populates="issue", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "issue_number", name="uq_material_issue_number"),
    )


class MaterialIssueItem(Base):
    __tablename__ = "material_issue_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    issue_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("material_issues.id", ondelete="CASCADE"), nullable=False, index=True)
    bom_item_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bom_items.id"), nullable=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True)
    bin_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bins.id"), nullable=True)
    planned_qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    issued_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    valuation_rate: Mapped[Optional[float]] = mapped_column(Numeric(18, 3), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Relationships
    issue: Mapped["MaterialIssue"] = relationship("MaterialIssue", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    batch: Mapped[Optional["Batch"]] = relationship("Batch")
    bin: Mapped[Optional["Bin"]] = relationship("Bin")
    uom: Mapped["UOM"] = relationship("UOM")


class JobCardStatus(str, enum.Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    ON_HOLD = "on_hold"
    CANCELLED = "cancelled"


class JobCard(Base):
    __tablename__ = "job_cards"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    job_card_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    work_order_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("work_orders.id"), nullable=False, index=True)
    operation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("bom_operations.id"), nullable=False)
    work_center_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("work_centers.id"), nullable=True)
    status: Mapped[JobCardStatus] = mapped_column(Enum(JobCardStatus), default=JobCardStatus.PENDING, nullable=False)
    planned_start: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    planned_end: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    actual_start: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    actual_end: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    planned_qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    completed_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    rejected_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    assigned_operator_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    supervised_by_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    setup_time_actual: Mapped[float] = mapped_column(Numeric(10, 2), default=0)
    run_time_actual: Mapped[float] = mapped_column(Numeric(10, 2), default=0)
    downtime_minutes: Mapped[float] = mapped_column(Numeric(10, 2), default=0)
    downtime_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    work_order: Mapped["WorkOrder"] = relationship("WorkOrder", back_populates="job_cards")
    operation: Mapped["BOMOperation"] = relationship("BOMOperation")
    work_center: Mapped[Optional["WorkCenter"]] = relationship("WorkCenter")
    assigned_operator: Mapped[Optional["User"]] = relationship("User", foreign_keys=[assigned_operator_id])
    
    __table_args__ = (
        UniqueConstraint("organization_id", "job_card_number", name="uq_job_card_number"),
    )


class ProductionEntry(Base):
    __tablename__ = "production_entries"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    entry_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    work_order_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("work_orders.id"), nullable=False, index=True)
    job_card_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("job_cards.id"), nullable=True)
    entry_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    entry_type: Mapped[str] = mapped_column(String(50), nullable=False)  # production, rework, scrap
    finished_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    rejected_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    scrap_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    batch_number: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)  # Auto-generated
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True)
    recorded_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    work_order: Mapped["WorkOrder"] = relationship("WorkOrder", back_populates="production_entries")
    job_card: Mapped[Optional["JobCard"]] = relationship("JobCard")
    batch: Mapped[Optional["Batch"]] = relationship("Batch")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "entry_number", name="uq_production_entry_number"),
    )


class QualityCheckTemplate(Base):
    __tablename__ = "quality_check_templates"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    applies_to: Mapped[str] = mapped_column(String(50), nullable=False)  # raw_material, in_process, finished_good
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    # Relationships
    parameters: Mapped[List["QualityCheckParameter"]] = relationship("QualityCheckParameter", back_populates="template", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "code", name="uq_qc_template_code"),
    )


class QualityCheckParameter(Base):
    __tablename__ = "quality_check_parameters"
    
    class ParameterType(str, enum.Enum):
        NUMERIC = "numeric"
        TEXT = "text"
        BOOLEAN = "boolean"
        SELECT = "select"
        PASS_FAIL = "pass_fail"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    template_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("quality_check_templates.id", ondelete="CASCADE"), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    parameter_type: Mapped[ParameterType] = mapped_column(Enum(ParameterType), nullable=False)
    unit: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    min_value: Mapped[Optional[float]] = mapped_column(Numeric(18, 3), nullable=True)
    max_value: Mapped[Optional[float]] = mapped_column(Numeric(18, 3), nullable=True)
    target_value: Mapped[Optional[float]] = mapped_column(Numeric(18, 3), nullable=True)
    options: Mapped[Optional[List[str]]] = mapped_column(JSONB, default=list, nullable=False)  # For select type
    is_mandatory: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    
    # Relationships
    template: Mapped["QualityCheckTemplate"] = relationship("QualityCheckTemplate", back_populates="parameters")


class QualityInspectionStatus(str, enum.Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    PASSED = "passed"
    FAILED = "failed"
    ON_HOLD = "on_hold"
    REWORK = "rework"


class QualityInspection(Base):
    __tablename__ = "quality_inspections"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    inspection_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    inspection_type: Mapped[str] = mapped_column(String(50), nullable=False)  # incoming, in_process, final
    reference_doctype: Mapped[str] = mapped_column(String(100), nullable=False)  # purchase_receipt, job_card, production_entry
    reference_doc_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True, index=True)
    template_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("quality_check_templates.id"), nullable=True)
    status: Mapped[QualityInspectionStatus] = mapped_column(Enum(QualityInspectionStatus), default=QualityInspectionStatus.PENDING, nullable=False)
    inspection_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    inspected_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    reviewed_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    overall_result: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)  # pass, fail
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    batch: Mapped[Optional["Batch"]] = relationship("Batch", back_populates="quality_inspections")
    template: Mapped[Optional["QualityCheckTemplate"]] = relationship("QualityCheckTemplate")
    results: Mapped[List["QualityInspectionResult"]] = relationship("QualityInspectionResult", back_populates="inspection", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "inspection_number", name="uq_quality_inspection_number"),
        Index("ix_quality_inspection_ref", "reference_doctype", "reference_doc_id"),
    )


class QualityInspectionResult(Base):
    __tablename__ = "quality_inspection_results"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    inspection_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("quality_inspections.id", ondelete="CASCADE"), nullable=False, index=True)
    parameter_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("quality_check_parameters.id"), nullable=False)
    value_numeric: Mapped[Optional[float]] = mapped_column(Numeric(18, 3), nullable=True)
    value_text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    value_boolean: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    value_select: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    result: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)  # pass, fail
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Relationships
    inspection: Mapped["QualityInspection"] = relationship("QualityInspection", back_populates="results")
    parameter: Mapped["QualityCheckParameter"] = relationship("QualityCheckParameter")


class BatchRelease(Base):
    __tablename__ = "batch_releases"
    
    class Status(str, enum.Enum):
        PENDING = "pending"
        RELEASED = "released"
        REJECTED = "rejected"
        QUARANTINED = "quarantined"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    batch_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=False, index=True)
    release_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    status: Mapped[Status] = mapped_column(Enum(Status), default=Status.PENDING, nullable=False)
    release_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    released_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    released_qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    quality_approval: Mapped[bool] = mapped_column(Boolean, default=False)
    cof_number: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)  # Certificate of Fitness
    cof_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    expiry_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    batch: Mapped["Batch"] = relationship("Batch")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "release_number", name="uq_batch_release_number"),
    )