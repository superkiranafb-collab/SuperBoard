import uuid
from datetime import datetime, timezone
from typing import Optional, List
from sqlalchemy import (
    String, Text, DateTime, Boolean, ForeignKey, Enum, Index, UniqueConstraint, Numeric, Integer, CheckConstraint
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.core.database import Base
import enum


class QuotationStatus(str, enum.Enum):
    DRAFT = "draft"
    SENT = "sent"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    EXPIRED = "expired"
    CONVERTED = "converted"


class SalesQuotation(Base):
    __tablename__ = "sales_quotations"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    quotation_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("customers.id"), nullable=False)
    customer_address_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("customer_addresses.id"), nullable=True)
    status: Mapped[QuotationStatus] = mapped_column(Enum(QuotationStatus), default=QuotationStatus.DRAFT, nullable=False)
    quotation_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    valid_till: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    price_list_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("price_lists.id"), nullable=True)
    currency: Mapped[str] = mapped_column(String(3), default="INR")
    exchange_rate: Mapped[float] = mapped_column(Numeric(18, 6), default=1)
    subtotal: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    discount_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    tax_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    total_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    terms_conditions: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    prepared_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    approved_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    customer: Mapped["Customer"] = relationship("Customer")
    customer_address: Mapped[Optional["CustomerAddress"]] = relationship("CustomerAddress")
    price_list: Mapped[Optional["PriceList"]] = relationship("PriceList")
    items: Mapped[List["SalesQuotationItem"]] = relationship("SalesQuotationItem", back_populates="quotation", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "quotation_number", name="uq_quotation_number"),
    )


class SalesQuotationItem(Base):
    __tablename__ = "sales_quotation_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    quotation_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("sales_quotations.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    rate: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    discount_percent: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    discount_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    tax_rate: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    tax_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    
    # Relationships
    quotation: Mapped["SalesQuotation"] = relationship("SalesQuotation", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    uom: Mapped["UOM"] = relationship("UOM")


class SalesOrderStatus(str, enum.Enum):
    DRAFT = "draft"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    PARTIALLY_FULFILLED = "partially_fulfilled"
    FULFILLED = "fulfilled"
    DELIVERED = "delivered"
    INVOICED = "invoiced"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    ON_HOLD = "on_hold"


class SalesOrder(Base):
    __tablename__ = "sales_orders"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    order_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("customers.id"), nullable=False)
    customer_address_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("customer_addresses.id"), nullable=True)
    quotation_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("sales_quotations.id"), nullable=True)
    status: Mapped[SalesOrderStatus] = mapped_column(Enum(SalesOrderStatus), default=SalesOrderStatus.DRAFT, nullable=False)
    order_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    delivery_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    warehouse_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=True)
    price_list_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("price_lists.id"), nullable=True)
    salesperson_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    currency: Mapped[str] = mapped_column(String(3), default="INR")
    exchange_rate: Mapped[float] = mapped_column(Numeric(18, 6), default=1)
    subtotal: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    discount_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    tax_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    total_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    advance_paid: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    terms_conditions: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    credit_check_passed: Mapped[bool] = mapped_column(Boolean, default=False)
    stock_check_passed: Mapped[bool] = mapped_column(Boolean, default=False)
    approved_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    customer: Mapped["Customer"] = relationship("Customer")
    customer_address: Mapped[Optional["CustomerAddress"]] = relationship("CustomerAddress")
    quotation: Mapped[Optional["SalesQuotation"]] = relationship("SalesQuotation")
    warehouse: Mapped[Optional["Warehouse"]] = relationship("Warehouse", foreign_keys=[warehouse_id])
    price_list: Mapped[Optional["PriceList"]] = relationship("PriceList")
    salesperson: Mapped[Optional["User"]] = relationship("User", foreign_keys=[salesperson_id])
    items: Mapped[List["SalesOrderItem"]] = relationship("SalesOrderItem", back_populates="order", cascade="all, delete-orphan")
    deliveries: Mapped[List["DeliveryNote"]] = relationship("DeliveryNote", back_populates="sales_order")
    invoices: Mapped[List["SalesInvoice"]] = relationship("SalesInvoice", back_populates="sales_order")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "order_number", name="uq_sales_order_number"),
        Index("ix_sales_order_customer_date", "customer_id", "order_date"),
        Index("ix_sales_order_status", "status"),
    )


class SalesOrderItem(Base):
    __tablename__ = "sales_order_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    order_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("sales_orders.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    rate: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    discount_percent: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    discount_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    tax_rate: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    tax_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    delivered_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    invoiced_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    
    # Relationships
    order: Mapped["SalesOrder"] = relationship("SalesOrder", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    uom: Mapped["UOM"] = relationship("UOM")


class DeliveryNoteStatus(str, enum.Enum):
    DRAFT = "draft"
    PENDING = "pending"
    IN_TRANSIT = "in_transit"
    DELIVERED = "delivered"
    PARTIAL = "partial"
    RETURNED = "returned"
    CANCELLED = "cancelled"


class DeliveryNote(Base):
    __tablename__ = "delivery_notes"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    delivery_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    sales_order_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("sales_orders.id"), nullable=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("customers.id"), nullable=False)
    customer_address_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("customer_addresses.id"), nullable=True)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False)
    status: Mapped[DeliveryNoteStatus] = mapped_column(Enum(DeliveryNoteStatus), default=DeliveryNoteStatus.DRAFT, nullable=False)
    delivery_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    vehicle_number: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    driver_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    driver_phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    ewaybill_number: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    ewaybill_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    delivered_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    delivered_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    received_by_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    signature_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    photo_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 7), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    sales_order: Mapped[Optional["SalesOrder"]] = relationship("SalesOrder", back_populates="deliveries")
    customer: Mapped["Customer"] = relationship("Customer")
    customer_address: Mapped[Optional["CustomerAddress"]] = relationship("CustomerAddress")
    warehouse: Mapped["Warehouse"] = relationship("Warehouse")
    items: Mapped[List["DeliveryNoteItem"]] = relationship("DeliveryNoteItem", back_populates="delivery_note", cascade="all, delete-orphan")
    trip: Mapped[Optional["DeliveryTrip"]] = relationship("DeliveryTrip", back_populates="delivery_note")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "delivery_number", name="uq_delivery_number"),
    )


class DeliveryNoteItem(Base):
    __tablename__ = "delivery_note_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    delivery_note_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("delivery_notes.id", ondelete="CASCADE"), nullable=False, index=True)
    sales_order_item_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("sales_order_items.id"), nullable=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True)
    bin_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bins.id"), nullable=True)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    rate: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    serial_numbers: Mapped[Optional[List[str]]] = mapped_column(JSONB, default=list, nullable=False)
    
    # Relationships
    delivery_note: Mapped["DeliveryNote"] = relationship("DeliveryNote", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    batch: Mapped[Optional["Batch"]] = relationship("Batch")
    bin: Mapped[Optional["Bin"]] = relationship("Bin")
    uom: Mapped["UOM"] = relationship("UOM")


class SalesInvoiceStatus(str, enum.Enum):
    DRAFT = "draft"
    PENDING = "pending"
    ISSUED = "issued"
    PAID = "paid"
    PARTIAL = "partial"
    OVERDUE = "overdue"
    CANCELLED = "cancelled"
    CREDIT_NOTE = "credit_note"


class SalesInvoice(Base):
    __tablename__ = "sales_invoices"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    invoice_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    sales_order_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("sales_orders.id"), nullable=True)
    delivery_note_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("delivery_notes.id"), nullable=True)
    customer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("customers.id"), nullable=False)
    customer_address_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("customer_addresses.id"), nullable=True)
    status: Mapped[SalesInvoiceStatus] = mapped_column(Enum(SalesInvoiceStatus), default=SalesInvoiceStatus.DRAFT, nullable=False)
    invoice_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    due_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="INR")
    exchange_rate: Mapped[float] = mapped_column(Numeric(18, 6), default=1)
    subtotal: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    discount_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    tax_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    total_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    paid_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    balance_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    irn: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)  # Invoice Reference Number for e-invoice
    irn_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    ack_number: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    ack_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    is_e_invoice: Mapped[bool] = mapped_column(Boolean, default=False)
    gst_type: Mapped[str] = mapped_column(String(20), default="B2B")  # B2B, B2C, Export
    place_of_supply: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    reverse_charge: Mapped[bool] = mapped_column(Boolean, default=False)
    terms_conditions: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    issued_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    issued_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    sales_order: Mapped[Optional["SalesOrder"]] = relationship("SalesOrder", back_populates="invoices")
    delivery_note: Mapped[Optional["DeliveryNote"]] = relationship("DeliveryNote")
    customer: Mapped["Customer"] = relationship("Customer")
    customer_address: Mapped[Optional["CustomerAddress"]] = relationship("CustomerAddress")
    items: Mapped[List["SalesInvoiceItem"]] = relationship("SalesInvoiceItem", back_populates="invoice", cascade="all, delete-orphan")
    payments: Mapped[List["Payment"]] = relationship("Payment", back_populates="sales_invoice")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "invoice_number", name="uq_sales_invoice_number"),
        Index("ix_sales_invoice_customer_date", "customer_id", "invoice_date"),
        Index("ix_sales_invoice_status", "status"),
    )


class SalesInvoiceItem(Base):
    __tablename__ = "sales_invoice_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    invoice_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("sales_invoices.id", ondelete="CASCADE"), nullable=False, index=True)
    sales_order_item_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("sales_order_items.id"), nullable=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    rate: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    discount_percent: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    discount_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    tax_rate: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    tax_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    hsn_code: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    
    # Relationships
    invoice: Mapped["SalesInvoice"] = relationship("SalesInvoice", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    batch: Mapped[Optional["Batch"]] = relationship("Batch")
    uom: Mapped["UOM"] = relationship("UOM")


class PaymentMode(str, enum.Enum):
    CASH = "cash"
    BANK_TRANSFER = "bank_transfer"
    CHEQUE = "cheque"
    UPI = "upi"
    CARD = "card"
    ONLINE = "online"
    PDC = "pdc"
    OTHER = "other"


class PaymentStatus(str, enum.Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    REFUNDED = "refunded"
    CANCELLED = "cancelled"


class Payment(Base):
    __tablename__ = "payments"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    payment_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    payment_type: Mapped[str] = mapped_column(String(50), nullable=False)  # receipt, payment
    mode: Mapped[PaymentMode] = mapped_column(Enum(PaymentMode), nullable=False)
    status: Mapped[PaymentStatus] = mapped_column(Enum(PaymentStatus), default=PaymentStatus.PENDING, nullable=False)
    party_type: Mapped[str] = mapped_column(String(50), nullable=False)  # customer, supplier
    party_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    sales_invoice_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("sales_invoices.id"), nullable=True)
    purchase_invoice_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("purchase_invoices.id"), nullable=True)
    amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="INR")
    exchange_rate: Mapped[float] = mapped_column(Numeric(18, 6), default=1)
    reference_number: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    reference_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    bank_account_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bank_accounts.id"), nullable=True)
    cheque_number: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    cheque_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    cleared_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    posted_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    posted_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    sales_invoice: Mapped[Optional["SalesInvoice"]] = relationship("SalesInvoice", back_populates="payments")
    purchase_invoice: Mapped[Optional["PurchaseInvoice"]] = relationship("PurchaseInvoice", back_populates="payments")
    bank_account: Mapped[Optional["BankAccount"]] = relationship("BankAccount")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "payment_number", name="uq_payment_number"),
        Index("ix_payment_party", "party_type", "party_id"),
    )


class BankAccount(Base):
    __tablename__ = "bank_accounts"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    account_name: Mapped[str] = mapped_column(String(255), nullable=False)
    bank_name: Mapped[str] = mapped_column(String(255), nullable=False)
    branch: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    account_number: Mapped[str] = mapped_column(String(50), nullable=False)
    ifsc_code: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    account_type: Mapped[str] = mapped_column(String(50), default="current")  # current, savings, cc, od
    currency: Mapped[str] = mapped_column(String(3), default="INR")
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    opening_balance: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    current_balance: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    __table_args__ = (
        UniqueConstraint("organization_id", "account_number", name="uq_bank_account"),
    )