import uuid
from datetime import datetime, timezone
from typing import Optional, List
from sqlalchemy import (
    String, Text, DateTime, Boolean, ForeignKey, Enum, Index, UniqueConstraint, CheckConstraint
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.core.database import Base
import enum


class OrganizationType(str, enum.Enum):
    HEAD_OFFICE = "head_office"
    BRANCH = "branch"
    WAREHOUSE = "warehouse"
    FACTORY = "factory"


class UserStatus(str, enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    PENDING = "pending"


class WarehouseType(str, enum.Enum):
    FINISHED_GOODS = "finished_goods"
    RAW_MATERIAL = "raw_material"
    PACKAGING = "packaging"
    WORK_IN_PROGRESS = "work_in_progress"
    QUARANTINE = "quarantine"
    DAMAGED = "damaged"


class StockStatus(str, enum.Enum):
    AVAILABLE = "available"
    RESERVED = "reserved"
    IN_TRANSIT = "in_transit"
    QUARANTINED = "quarantined"
    DAMAGED = "damaged"
    EXPIRED = "expired"


class TransactionType(str, enum.Enum):
    SALES_INVOICE = "sales_invoice"
    SALES_RETURN = "sales_return"
    PURCHASE_RECEIPT = "purchase_receipt"
    PURCHASE_RETURN = "purchase_return"
    STOCK_TRANSFER_OUT = "stock_transfer_out"
    STOCK_TRANSFER_IN = "stock_transfer_in"
    PRODUCTION_ISSUE = "production_issue"
    PRODUCTION_RECEIPT = "production_receipt"
    STOCK_ADJUSTMENT = "stock_adjustment"
    STOCK_COUNT = "stock_count"
    DAMAGE_WRITE_OFF = "damage_write_off"
    EXPIRY_WRITE_OFF = "expiry_write_off"


class Organization(Base):
    __tablename__ = "organizations"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    code: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, index=True)
    type: Mapped[OrganizationType] = mapped_column(Enum(OrganizationType), nullable=False, default=OrganizationType.BRANCH)
    parent_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=True)
    gstin: Mapped[Optional[str]] = mapped_column(String(15), nullable=True, index=True)
    pan: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    address_line1: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    address_line2: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    city: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    state: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    pincode: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    country: Mapped[str] = mapped_column(String(100), default="India")
    phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    settings: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    parent: Mapped[Optional["Organization"]] = relationship("Organization", remote_side=[id], backref="children")
    users: Mapped[List["User"]] = relationship("User", back_populates="organization")
    warehouses: Mapped[List["Warehouse"]] = relationship("Warehouse", back_populates="organization")
    
    __table_args__ = (
        Index("ix_organizations_parent_id", "parent_id"),
        Index("ix_organizations_type", "type"),
    )


class User(Base):
    __tablename__ = "users"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    username: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    status: Mapped[UserStatus] = mapped_column(Enum(UserStatus), default=UserStatus.PENDING, nullable=False)
    department: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    designation: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    reporting_manager_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    assigned_warehouse_ids: Mapped[List[uuid.UUID]] = mapped_column(JSONB, default=list, nullable=False)
    assigned_territory_ids: Mapped[List[uuid.UUID]] = mapped_column(JSONB, default=list, nullable=False)
    approval_limit: Mapped[Optional[float]] = mapped_column(nullable=True)
    mfa_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    mfa_secret: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    last_login: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    failed_login_attempts: Mapped[int] = mapped_column(default=0)
    locked_until: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    avatar_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    settings: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization", back_populates="users")
    reporting_manager: Mapped[Optional["User"]] = relationship("User", remote_side=[id], backref="subordinates")
    assigned_warehouses: Mapped[List["Warehouse"]] = relationship("Warehouse", secondary="user_warehouse_assignments", back_populates="assigned_users")
    
    __table_args__ = (
        Index("ix_users_org_status", "organization_id", "status"),
        Index("ix_users_reporting_manager", "reporting_manager_id"),
    )


class UserWarehouseAssignment(Base):
    __tablename__ = "user_warehouse_assignments"
    
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id", ondelete="CASCADE"), primary_key=True)
    assigned_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    assigned_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)


class Warehouse(Base):
    __tablename__ = "warehouses"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    type: Mapped[WarehouseType] = mapped_column(Enum(WarehouseType), nullable=False, default=WarehouseType.FINISHED_GOODS)
    address_line1: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    address_line2: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    city: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    state: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    pincode: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    manager_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    allow_negative_stock: Mapped[bool] = mapped_column(Boolean, default=False)
    settings: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization", back_populates="warehouses")
    manager: Mapped[Optional["User"]] = relationship("User", foreign_keys=[manager_id])
    assigned_users: Mapped[List["User"]] = relationship("User", secondary="user_warehouse_assignments", back_populates="assigned_warehouses")
    racks: Mapped[List["Rack"]] = relationship("Rack", back_populates="warehouse", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "code", name="uq_warehouse_org_code"),
        Index("ix_warehouses_org_type", "organization_id", "type"),
    )


class Rack(Base):
    __tablename__ = "racks"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id", ondelete="CASCADE"), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(50), nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    
    # Relationships
    warehouse: Mapped["Warehouse"] = relationship("Warehouse", back_populates="racks")
    shelves: Mapped[List["Shelf"]] = relationship("Shelf", back_populates="rack", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("warehouse_id", "code", name="uq_rack_warehouse_code"),
    )


class Shelf(Base):
    __tablename__ = "shelves"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rack_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("racks.id", ondelete="CASCADE"), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(50), nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    
    # Relationships
    rack: Mapped["Rack"] = relationship("Rack", back_populates="shelves")
    bins: Mapped[List["Bin"]] = relationship("Bin", back_populates="shelf", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("rack_id", "code", name="uq_shelf_rack_code"),
    )


class Bin(Base):
    __tablename__ = "bins"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    shelf_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("shelves.id", ondelete="CASCADE"), nullable=False, index=True)
    code: Mapped[str] = mapped_column(String(50), nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    max_capacity: Mapped[Optional[float]] = mapped_column(nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    
    # Relationships
    shelf: Mapped["Shelf"] = relationship("Shelf", back_populates="bins")
    stock_ledger_entries: Mapped[List["StockLedgerEntry"]] = relationship("StockLedgerEntry", back_populates="bin")
    
    __table_args__ = (
        UniqueConstraint("shelf_id", "code", name="uq_bin_shelf_code"),
    )