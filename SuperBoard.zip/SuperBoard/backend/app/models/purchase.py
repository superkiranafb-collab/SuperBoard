import uuid
from datetime import datetime, timezone
from typing import Optional, List
from sqlalchemy import (
    String, Text, DateTime, Boolean, ForeignKey, Enum, Index, UniqueConstraint, Numeric, Integer, CheckConstraint
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.core.database import Base
import enum


class PurchaseRequisitionStatus(str, enum.Enum):
    DRAFT = "draft"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    ORDERED = "ordered"
    CANCELLED = "cancelled"


class PurchaseRequisition(Base):
    __tablename__ = "purchase_requisitions"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    requisition_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    status: Mapped[PurchaseRequisitionStatus] = mapped_column(Enum(PurchaseRequisitionStatus), default=PurchaseRequisitionStatus.DRAFT, nullable=False)
    requisition_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    required_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False)
    requested_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    approved_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    warehouse: Mapped["Warehouse"] = relationship("Warehouse")
    items: Mapped[List["PurchaseRequisitionItem"]] = relationship("PurchaseRequisitionItem", back_populates="requisition", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "requisition_number", name="uq_requisition_number"),
    )


class PurchaseRequisitionItem(Base):
    __tablename__ = "purchase_requisition_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    requisition_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("purchase_requisitions.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    estimated_rate: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    preferred_supplier_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("suppliers.id"), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Relationships
    requisition: Mapped["PurchaseRequisition"] = relationship("PurchaseRequisition", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    uom: Mapped["UOM"] = relationship("UOM")
    preferred_supplier: Mapped[Optional["Supplier"]] = relationship("Supplier")


class PurchaseOrderStatus(str, enum.Enum):
    DRAFT = "draft"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    SENT = "sent"
    ACKNOWLEDGED = "acknowledged"
    PARTIALLY_RECEIVED = "partially_received"
    RECEIVED = "received"
    BILLED = "billed"
    CLOSED = "closed"
    CANCELLED = "cancelled"


class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    order_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    supplier_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("suppliers.id"), nullable=False)
    supplier_address_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("supplier_addresses.id"), nullable=True)
    requisition_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("purchase_requisitions.id"), nullable=True)
    status: Mapped[PurchaseOrderStatus] = mapped_column(Enum(PurchaseOrderStatus), default=PurchaseOrderStatus.DRAFT, nullable=False)
    order_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    expected_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="INR")
    exchange_rate: Mapped[float] = mapped_column(Numeric(18, 6), default=1)
    subtotal: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    discount_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    tax_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    total_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    terms_conditions: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    approved_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    acknowledged_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    supplier: Mapped["Supplier"] = relationship("Supplier")
    supplier_address: Mapped[Optional["SupplierAddress"]] = relationship("SupplierAddress")
    requisition: Mapped[Optional["PurchaseRequisition"]] = relationship("PurchaseRequisition")
    warehouse: Mapped["Warehouse"] = relationship("Warehouse")
    items: Mapped[List["PurchaseOrderItem"]] = relationship("PurchaseOrderItem", back_populates="order", cascade="all, delete-orphan")
    receipts: Mapped[List["PurchaseReceipt"]] = relationship("PurchaseReceipt", back_populates="purchase_order")
    invoices: Mapped[List["PurchaseInvoice"]] = relationship("PurchaseInvoice", back_populates="purchase_order")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "order_number", name="uq_purchase_order_number"),
        Index("ix_purchase_order_supplier_date", "supplier_id", "order_date"),
        Index("ix_purchase_order_status", "status"),
    )


class PurchaseOrderItem(Base):
    __tablename__ = "purchase_order_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    order_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("purchase_orders.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    rate: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    discount_percent: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    discount_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    tax_rate: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    tax_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    received_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    billed_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    
    # Relationships
    order: Mapped["PurchaseOrder"] = relationship("PurchaseOrder", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    uom: Mapped["UOM"] = relationship("UOM")


class PurchaseReceiptStatus(str, enum.Enum):
    DRAFT = "draft"
    PENDING_QC = "pending_qc"
    QC_PASSED = "qc_passed"
    QC_FAILED = "qc_failed"
    ACCEPTED = "accepted"
    PARTIAL = "partial"
    REJECTED = "rejected"


class PurchaseReceipt(Base):
    __tablename__ = "purchase_receipts"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    receipt_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    purchase_order_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("purchase_orders.id"), nullable=True)
    supplier_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("suppliers.id"), nullable=False)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False)
    status: Mapped[PurchaseReceiptStatus] = mapped_column(Enum(PurchaseReceiptStatus), default=PurchaseReceiptStatus.DRAFT, nullable=False)
    receipt_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    vehicle_number: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    driver_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    driver_phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    received_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    qc_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    qc_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    qc_notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    purchase_order: Mapped[Optional["PurchaseOrder"]] = relationship("PurchaseOrder", back_populates="receipts")
    supplier: Mapped["Supplier"] = relationship("Supplier")
    warehouse: Mapped["Warehouse"] = relationship("Warehouse")
    items: Mapped[List["PurchaseReceiptItem"]] = relationship("PurchaseReceiptItem", back_populates="receipt", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "receipt_number", name="uq_purchase_receipt_number"),
    )


class PurchaseReceiptItem(Base):
    __tablename__ = "purchase_receipt_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    receipt_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("purchase_receipts.id", ondelete="CASCADE"), nullable=False, index=True)
    purchase_order_item_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("purchase_order_items.id"), nullable=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True)
    bin_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bins.id"), nullable=True)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    accepted_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    rejected_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    rate: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    manufacture_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    expiry_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    supplier_batch_number: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Relationships
    receipt: Mapped["PurchaseReceipt"] = relationship("PurchaseReceipt", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    batch: Mapped[Optional["Batch"]] = relationship("Batch")
    bin: Mapped[Optional["Bin"]] = relationship("Bin")
    uom: Mapped["UOM"] = relationship("UOM")


class PurchaseInvoiceStatus(str, enum.Enum):
    DRAFT = "draft"
    PENDING = "pending"
    VERIFIED = "verified"
    APPROVED = "approved"
    PAID = "paid"
    PARTIAL = "partial"
    OVERDUE = "overdue"
    CANCELLED = "cancelled"


class PurchaseInvoice(Base):
    __tablename__ = "purchase_invoices"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    invoice_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    supplier_invoice_number: Mapped[str] = mapped_column(String(100), nullable=False)
    supplier_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("suppliers.id"), nullable=False)
    purchase_order_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("purchase_orders.id"), nullable=True)
    receipt_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("purchase_receipts.id"), nullable=True)
    status: Mapped[PurchaseInvoiceStatus] = mapped_column(Enum(PurchaseInvoiceStatus), default=PurchaseInvoiceStatus.DRAFT, nullable=False)
    invoice_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    due_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="INR")
    exchange_rate: Mapped[float] = mapped_column(Numeric(18, 6), default=1)
    subtotal: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    discount_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    tax_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    total_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    paid_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    balance_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    gst_type: Mapped[str] = mapped_column(String(20), default="B2B")
    place_of_supply: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    reverse_charge: Mapped[bool] = mapped_column(Boolean, default=False)
    irn: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    verified_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    verified_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    approved_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    supplier: Mapped["Supplier"] = relationship("Supplier")
    purchase_order: Mapped[Optional["PurchaseOrder"]] = relationship("PurchaseOrder", back_populates="invoices")
    receipt: Mapped[Optional["PurchaseReceipt"]] = relationship("PurchaseReceipt")
    items: Mapped[List["PurchaseInvoiceItem"]] = relationship("PurchaseInvoiceItem", back_populates="invoice", cascade="all, delete-orphan")
    payments: Mapped[List["Payment"]] = relationship("Payment", back_populates="purchase_invoice")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "invoice_number", name="uq_purchase_invoice_number"),
        UniqueConstraint("organization_id", "supplier_id", "supplier_invoice_number", name="uq_supplier_invoice_number"),
        Index("ix_purchase_invoice_supplier_date", "supplier_id", "invoice_date"),
        Index("ix_purchase_invoice_status", "status"),
    )


class PurchaseInvoiceItem(Base):
    __tablename__ = "purchase_invoice_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    invoice_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("purchase_invoices.id", ondelete="CASCADE"), nullable=False, index=True)
    purchase_order_item_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("purchase_order_items.id"), nullable=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    rate: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    discount_percent: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    discount_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    tax_rate: Mapped[float] = mapped_column(Numeric(5, 2), default=0)
    tax_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    hsn_code: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    
    # Relationships
    invoice: Mapped["PurchaseInvoice"] = relationship("PurchaseInvoice", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    uom: Mapped["UOM"] = relationship("UOM")


class SupplierReturnStatus(str, enum.Enum):
    DRAFT = "draft"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    SENT = "sent"
    RECEIVED_BY_SUPPLIER = "received_by_supplier"
    CREDIT_NOTE_RECEIVED = "credit_note_received"
    CLOSED = "closed"
    CANCELLED = "cancelled"


class SupplierReturn(Base):
    __tablename__ = "supplier_returns"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    return_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    supplier_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("suppliers.id"), nullable=False)
    purchase_receipt_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("purchase_receipts.id"), nullable=True)
    status: Mapped[SupplierReturnStatus] = mapped_column(Enum(SupplierReturnStatus), default=SupplierReturnStatus.DRAFT, nullable=False)
    return_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    reason: Mapped[str] = mapped_column(String(255), nullable=False)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False)
    total_amount: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    credit_note_number: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    credit_note_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    approved_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    supplier: Mapped["Supplier"] = relationship("Supplier")
    purchase_receipt: Mapped[Optional["PurchaseReceipt"]] = relationship("PurchaseReceipt")
    warehouse: Mapped["Warehouse"] = relationship("Warehouse")
    items: Mapped[List["SupplierReturnItem"]] = relationship("SupplierReturnItem", back_populates="return_doc", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "return_number", name="uq_supplier_return_number"),
    )


class SupplierReturnItem(Base):
    __tablename__ = "supplier_return_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    return_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("supplier_returns.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    uom_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("uoms.id"), nullable=False)
    rate: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    amount: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    reason: Mapped[str] = mapped_column(String(255), nullable=False)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Relationships
    return_doc: Mapped["SupplierReturn"] = relationship("SupplierReturn", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    batch: Mapped[Optional["Batch"]] = relationship("Batch")
    uom: Mapped["UOM"] = relationship("UOM")