import uuid
from datetime import datetime, timezone
from typing import Optional, List
from sqlalchemy import (
    String, Text, DateTime, Boolean, ForeignKey, Enum, Index, UniqueConstraint, Numeric, Integer, CheckConstraint
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.core.database import Base
import enum


class Batch(Base):
    __tablename__ = "batches"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False, index=True)
    batch_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    manufacture_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    expiry_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    supplier_batch_number: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    supplier_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("suppliers.id"), nullable=True)
    source_type: Mapped[str] = mapped_column(String(50), nullable=False)  # purchase, production, opening
    source_document_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    source_document_type: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    mrp: Mapped[Optional[float]] = mapped_column(Numeric(18, 2), nullable=True)
    cost_price: Mapped[Optional[float]] = mapped_column(Numeric(18, 3), nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="active")  # active, expired, recalled, quarantined
    quality_status: Mapped[str] = mapped_column(String(50), default="pending")  # pending, passed, failed, on_hold
    retention_sample_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    attributes: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    product: Mapped["Product"] = relationship("Product")
    supplier: Mapped[Optional["Supplier"]] = relationship("Supplier")
    stock_ledger_entries: Mapped[List["StockLedgerEntry"]] = relationship("StockLedgerEntry", back_populates="batch")
    quality_inspections: Mapped[List["QualityInspection"]] = relationship("QualityInspection", back_populates="batch")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "product_id", "batch_number", name="uq_batch_org_product_number"),
        Index("ix_batches_expiry", "expiry_date"),
        Index("ix_batches_source", "source_document_id", "source_document_type"),
    )


class StockLedgerEntry(Base):
    __tablename__ = "stock_ledger_entries"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False, index=True)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False, index=True)
    bin_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bins.id"), nullable=True, index=True)
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True, index=True)
    transaction_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    transaction_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True, index=True)
    transaction_number: Mapped[Optional[str]] = mapped_column(String(100), nullable=True, index=True)
    transaction_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    qty_in: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    qty_out: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    balance_qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    valuation_rate: Mapped[Optional[float]] = mapped_column(Numeric(18, 3), nullable=True)
    valuation_amount: Mapped[Optional[float]] = mapped_column(Numeric(18, 3), nullable=True)
    stock_status: Mapped[str] = mapped_column(String(50), default="available")
    reference_doctype: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    reference_docname: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    product: Mapped["Product"] = relationship("Product", back_populates="stock_ledger_entries")
    warehouse: Mapped["Warehouse"] = relationship("Warehouse")
    bin: Mapped[Optional["Bin"]] = relationship("Bin", back_populates="stock_ledger_entries")
    batch: Mapped[Optional["Batch"]] = relationship("Batch", back_populates="stock_ledger_entries")
    
    __table_args__ = (
        Index("ix_stock_ledger_org_product_warehouse", "organization_id", "product_id", "warehouse_id"),
        Index("ix_stock_ledger_org_batch", "organization_id", "batch_id"),
        Index("ix_stock_ledger_transaction", "transaction_id", "transaction_type"),
        Index("ix_stock_ledger_date", "transaction_date"),
        CheckConstraint("qty_in >= 0 AND qty_out >= 0", name="ck_stock_ledger_positive_qty"),
        CheckConstraint("NOT (qty_in > 0 AND qty_out > 0)", name="ck_stock_ledger_one_direction"),
    )


class StockBalance(Base):
    """Materialized view / cached current stock balances"""
    __tablename__ = "stock_balances"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False, index=True)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False, index=True)
    bin_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bins.id"), nullable=True, index=True)
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True, index=True)
    stock_status: Mapped[str] = mapped_column(String(50), default="available", index=True)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    valuation_rate: Mapped[Optional[float]] = mapped_column(Numeric(18, 3), nullable=True)
    last_transaction_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    last_updated: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    __table_args__ = (
        UniqueConstraint(
            "organization_id", "product_id", "warehouse_id", "bin_id", "batch_id", "stock_status",
            name="uq_stock_balance"
        ),
        Index("ix_stock_balance_org_product_warehouse_status", "organization_id", "product_id", "warehouse_id", "stock_status"),
        Index("ix_stock_balance_expiry", "batch_id"),
    )


class StockReservation(Base):
    __tablename__ = "stock_reservations"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False, index=True)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False, index=True)
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True)
    bin_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bins.id"), nullable=True)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    reference_doctype: Mapped[str] = mapped_column(String(100), nullable=False)  # sales_order, work_order, transfer
    reference_docname: Mapped[str] = mapped_column(String(100), nullable=False)
    reference_doc_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(50), default="active")  # active, fulfilled, cancelled, expired
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    __table_args__ = (
        Index("ix_stock_reservation_ref", "reference_doc_id", "reference_doctype"),
        Index("ix_stock_reservation_status", "status"),
    )


class StockTransfer(Base):
    __tablename__ = "stock_transfers"
    
    class Status(str, enum.Enum):
        DRAFT = "draft"
        PENDING_APPROVAL = "pending_approval"
        APPROVED = "approved"
        IN_TRANSIT = "in_transit"
        PARTIAL_RECEIVED = "partial_received"
        RECEIVED = "received"
        CANCELLED = "cancelled"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    transfer_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    from_warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False)
    to_warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False)
    status: Mapped[Status] = mapped_column(Enum(Status), default=Status.DRAFT, nullable=False)
    transfer_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    expected_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    dispatched_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    received_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    vehicle_number: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    driver_name: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    driver_phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    dispatched_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    received_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    from_warehouse: Mapped["Warehouse"] = relationship("Warehouse", foreign_keys=[from_warehouse_id])
    to_warehouse: Mapped["Warehouse"] = relationship("Warehouse", foreign_keys=[to_warehouse_id])
    items: Mapped[List["StockTransferItem"]] = relationship("StockTransferItem", back_populates="transfer", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "transfer_number", name="uq_stock_transfer_number"),
        CheckConstraint("from_warehouse_id != to_warehouse_id", name="ck_transfer_different_warehouses"),
    )


class StockTransferItem(Base):
    __tablename__ = "stock_transfer_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    transfer_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("stock_transfers.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True)
    from_bin_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bins.id"), nullable=True)
    to_bin_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bins.id"), nullable=True)
    qty: Mapped[float] = mapped_column(Numeric(18, 3), nullable=False)
    dispatched_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    received_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    valuation_rate: Mapped[Optional[float]] = mapped_column(Numeric(18, 3), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Relationships
    transfer: Mapped["StockTransfer"] = relationship("StockTransfer", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    batch: Mapped[Optional["Batch"]] = relationship("Batch")
    
    __table_args__ = (
        Index("ix_stock_transfer_item_product", "product_id"),
    )


class PhysicalStockCount(Base):
    __tablename__ = "physical_stock_counts"
    
    class Status(str, enum.Enum):
        DRAFT = "draft"
        IN_PROGRESS = "in_progress"
        COMPLETED = "completed"
        APPROVED = "approved"
        REJECTED = "rejected"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    count_number: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    warehouse_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("warehouses.id"), nullable=False)
    status: Mapped[Status] = mapped_column(Enum(Status), default=Status.DRAFT, nullable=False)
    count_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    counted_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    verified_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    approved_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Relationships
    organization: Mapped["Organization"] = relationship("Organization")
    warehouse: Mapped["Warehouse"] = relationship("Warehouse")
    items: Mapped[List["PhysicalStockCountItem"]] = relationship("PhysicalStockCountItem", back_populates="count", cascade="all, delete-orphan")
    
    __table_args__ = (
        UniqueConstraint("organization_id", "count_number", name="uq_physical_count_number"),
    )


class PhysicalStockCountItem(Base):
    __tablename__ = "physical_stock_count_items"
    
    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    count_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("physical_stock_counts.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=False)
    batch_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("batches.id"), nullable=True)
    bin_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bins.id"), nullable=True)
    system_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    counted_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    variance_qty: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    variance_value: Mapped[float] = mapped_column(Numeric(18, 3), default=0)
    valuation_rate: Mapped[Optional[float]] = mapped_column(Numeric(18, 3), nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="pending")  # pending, matched, variance
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    
    # Relationships
    count: Mapped["PhysicalStockCount"] = relationship("PhysicalStockCount", back_populates="items")
    product: Mapped["Product"] = relationship("Product")
    batch: Mapped[Optional["Batch"]] = relationship("Batch")