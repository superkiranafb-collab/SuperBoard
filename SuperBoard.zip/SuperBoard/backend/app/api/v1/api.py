from fastapi import APIRouter
from app.api.v1.endpoints import (
    auth,
    organizations,
    users,
    warehouses,
    products,
    customers,
    suppliers,
    inventory,
    sales,
    purchase,
    manufacturing,
    finance,
    hr,
    logistics,
    approvals,
    ai,
)

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["Authentication"])
api_router.include_router(organizations.router, prefix="/organizations", tags=["Organizations"])
api_router.include_router(users.router, prefix="/users", tags=["Users"])
api_router.include_router(warehouses.router, prefix="/warehouses", tags=["Warehouses"])
api_router.include_router(products.router, prefix="/products", tags=["Products"])
api_router.include_router(customers.router, prefix="/customers", tags=["Customers"])
api_router.include_router(suppliers.router, prefix="/suppliers", tags=["Suppliers"])
api_router.include_router(inventory.router, prefix="/inventory", tags=["Inventory"])
api_router.include_router(sales.router, prefix="/sales", tags=["Sales"])
api_router.include_router(purchase.router, prefix="/purchase", tags=["Purchase"])
api_router.include_router(manufacturing.router, prefix="/manufacturing", tags=["Manufacturing"])
api_router.include_router(finance.router, prefix="/finance", tags=["Finance"])
api_router.include_router(hr.router, prefix="/hr", tags=["HR"])
api_router.include_router(logistics.router, prefix="/logistics", tags=["Logistics"])
api_router.include_router(approvals.router, prefix="/approvals", tags=["Approvals"])
api_router.include_router(ai.router, prefix="/ai", tags=["AI"])