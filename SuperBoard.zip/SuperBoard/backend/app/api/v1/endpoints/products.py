from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from uuid import UUID
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.models import (
    Product, ProductType, ProductCategory, UOM, UOMConversion,
    PriceList, PriceListItem, Organization
)
import structlog

logger = structlog.get_logger()

router = APIRouter()


class UOMBase(BaseModel):
    code: str
    name: str
    symbol: str
    is_base: bool = False
    decimal_places: int = 2


class UOMCreate(UOMBase):
    pass


class UOMResponse(UOMBase):
    id: UUID
    organization_id: UUID
    is_active: bool
    created_at: str
    
    class Config:
        from_attributes = True


@router.post("/uoms", response_model=UOMResponse, status_code=status.HTTP_201_CREATED)
async def create_uom(
    uom_data: UOMCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:create")),
):
    existing = await db.execute(
        select(UOM).where(
            UOM.organization_id == current_user.organization_id,
            UOM.code == uom_data.code
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="UOM code already exists")
    
    uom = UOM(
        **uom_data.model_dump(),
        organization_id=current_user.organization_id,
    )
    db.add(uom)
    await db.commit()
    await db.refresh(uom)
    return uom


@router.get("/uoms", response_model=List[UOMResponse])
async def list_uoms(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:view")),
):
    result = await db.execute(
        select(UOM).where(
            UOM.organization_id == current_user.organization_id,
            UOM.is_active == True
        ).order_by(UOM.code)
    )
    return result.scalars().all()


class ProductCategoryBase(BaseModel):
    code: str
    name: str
    parent_id: Optional[UUID] = None
    description: Optional[str] = None


class ProductCategoryCreate(ProductCategoryBase):
    pass


class ProductCategoryResponse(ProductCategoryBase):
    id: UUID
    organization_id: UUID
    is_active: bool
    created_at: str
    
    class Config:
        from_attributes = True


@router.post("/categories", response_model=ProductCategoryResponse, status_code=status.HTTP_201_CREATED)
async def create_category(
    cat_data: ProductCategoryCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:create")),
):
    existing = await db.execute(
        select(ProductCategory).where(
            ProductCategory.organization_id == current_user.organization_id,
            ProductCategory.code == cat_data.code
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Category code already exists")
    
    category = ProductCategory(
        **cat_data.model_dump(),
        organization_id=current_user.organization_id,
    )
    db.add(category)
    await db.commit()
    await db.refresh(category)
    return category


@router.get("/categories", response_model=List[ProductCategoryResponse])
async def list_categories(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:view")),
):
    result = await db.execute(
        select(ProductCategory).where(
            ProductCategory.organization_id == current_user.organization_id,
            ProductCategory.is_active == True
        ).order_by(ProductCategory.code)
    )
    return result.scalars().all()


class ProductBase(BaseModel):
    code: str
    name: str
    category_id: Optional[UUID] = None
    base_uom_id: UUID
    description: Optional[str] = None
    type: ProductType = ProductType.FINISHED_GOOD
    hsn_code: Optional[str] = None
    gst_rate: float = 0
    is_batch_tracked: bool = False
    is_expiry_tracked: bool = False
    shelf_life_days: Optional[int] = None
    min_stock_level: float = 0
    max_stock_level: float = 0
    reorder_level: float = 0
    reorder_qty: float = 0
    standard_cost: float = 0
    standard_price: float = 0
    weight: Optional[float] = None
    volume: Optional[float] = None
    barcode: Optional[str] = None
    is_saleable: bool = True
    is_purchasable: bool = True
    is_producible: bool = False
    attributes: dict = {}


class ProductCreate(ProductBase):
    pass


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    category_id: Optional[UUID] = None
    description: Optional[str] = None
    type: Optional[ProductType] = None
    hsn_code: Optional[str] = None
    gst_rate: Optional[float] = None
    is_batch_tracked: Optional[bool] = None
    is_expiry_tracked: Optional[bool] = None
    shelf_life_days: Optional[int] = None
    min_stock_level: Optional[float] = None
    max_stock_level: Optional[float] = None
    reorder_level: Optional[float] = None
    reorder_qty: Optional[float] = None
    standard_cost: Optional[float] = None
    standard_price: Optional[float] = None
    weight: Optional[float] = None
    volume: Optional[float] = None
    barcode: Optional[str] = None
    is_saleable: Optional[bool] = None
    is_purchasable: Optional[bool] = None
    is_producible: Optional[bool] = None
    is_active: Optional[bool] = None
    attributes: Optional[dict] = None


class ProductResponse(ProductBase):
    id: UUID
    organization_id: UUID
    is_active: bool
    created_at: str
    updated_at: str
    
    class Config:
        from_attributes = True


class ProductListResponse(BaseModel):
    items: List[ProductResponse]
    total: int
    page: int
    page_size: int
    total_pages: int


@router.post("", response_model=ProductResponse, status_code=status.HTTP_201_CREATED)
async def create_product(
    product_data: ProductCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:create")),
):
    existing = await db.execute(
        select(Product).where(
            Product.organization_id == current_user.organization_id,
            Product.code == product_data.code
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Product code already exists")
    
    if product_data.barcode:
        existing_barcode = await db.execute(
            select(Product).where(
                Product.organization_id == current_user.organization_id,
                Product.barcode == product_data.barcode
            )
        )
        if existing_barcode.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="Barcode already exists")
    
    product = Product(
        **product_data.model_dump(),
        organization_id=current_user.organization_id,
        created_by=current_user.id,
    )
    db.add(product)
    await db.commit()
    await db.refresh(product)
    
    logger.info("product_created", product_id=str(product.id), code=product.code)
    return product


@router.get("", response_model=ProductListResponse)
async def list_products(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    type: Optional[ProductType] = None,
    category_id: Optional[UUID] = None,
    is_active: Optional[bool] = None,
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:view")),
):
    query = select(Product).where(Product.organization_id == current_user.organization_id)
    
    if type:
        query = query.where(Product.type == type)
    if category_id:
        query = query.where(Product.category_id == category_id)
    if is_active is not None:
        query = query.where(Product.is_active == is_active)
    if search:
        query = query.where(
            or_(
                Product.name.ilike(f"%{search}%"),
                Product.code.ilike(f"%{search}%"),
                Product.barcode.ilike(f"%{search}%"),
            )
        )
    
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(Product.created_at.desc())
    result = await db.execute(query)
    items = result.scalars().all()
    
    return ProductListResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=(total + page_size - 1) // page_size,
    )


@router.get("/{product_id}", response_model=ProductResponse)
async def get_product(
    product_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:view")),
):
    result = await db.execute(
        select(Product).where(
            Product.id == product_id,
            Product.organization_id == current_user.organization_id
        )
    )
    product = result.scalar_one_or_none()
    
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    return product


@router.put("/{product_id}", response_model=ProductResponse)
async def update_product(
    product_id: UUID,
    product_data: ProductUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:update")),
):
    result = await db.execute(
        select(Product).where(
            Product.id == product_id,
            Product.organization_id == current_user.organization_id
        )
    )
    product = result.scalar_one_or_none()
    
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    update_data = product_data.model_dump(exclude_unset=True)
    
    if "code" in update_data:
        existing = await db.execute(
            select(Product).where(
                Product.organization_id == current_user.organization_id,
                Product.code == update_data["code"],
                Product.id != product_id
            )
        )
        if existing.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="Product code already exists")
    
    if "barcode" in update_data and update_data["barcode"]:
        existing = await db.execute(
            select(Product).where(
                Product.organization_id == current_user.organization_id,
                Product.barcode == update_data["barcode"],
                Product.id != product_id
            )
        )
        if existing.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="Barcode already exists")
    
    for field, value in update_data.items():
        setattr(product, field, value)
    
    await db.commit()
    await db.refresh(product)
    
    logger.info("product_updated", product_id=str(product.id))
    return product


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_product(
    product_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:delete")),
):
    result = await db.execute(
        select(Product).where(
            Product.id == product_id,
            Product.organization_id == current_user.organization_id
        )
    )
    product = result.scalar_one_or_none()
    
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    product.is_active = False
    await db.commit()
    
    logger.info("product_deleted", product_id=str(product_id))


# Price List endpoints
class PriceListBase(BaseModel):
    name: str
    description: Optional[str] = None
    currency: str = "INR"
    is_default: bool = False
    valid_from: str
    valid_to: Optional[str] = None
    applies_to_channels: List[str] = []


class PriceListCreate(PriceListBase):
    pass


class PriceListResponse(PriceListBase):
    id: UUID
    organization_id: UUID
    is_active: bool
    created_at: str
    
    class Config:
        from_attributes = True


@router.post("/price-lists", response_model=PriceListResponse, status_code=status.HTTP_201_CREATED)
async def create_price_list(
    pl_data: PriceListCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:create")),
):
    if pl_data.is_default:
        # Unset other defaults
        await db.execute(
            select(PriceList).where(
                PriceList.organization_id == current_user.organization_id,
                PriceList.is_default == True
            )
        )
        # This would need an update statement
    
    price_list = PriceList(
        **pl_data.model_dump(),
        organization_id=current_user.organization_id,
    )
    db.add(price_list)
    await db.commit()
    await db.refresh(price_list)
    return price_list


@router.get("/price-lists", response_model=List[PriceListResponse])
async def list_price_lists(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:view")),
):
    result = await db.execute(
        select(PriceList).where(
            PriceList.organization_id == current_user.organization_id,
            PriceList.is_active == True
        ).order_by(PriceList.created_at.desc())
    )
    return result.scalars().all()


class PriceListItemBase(BaseModel):
    product_id: UUID
    min_qty: float = 1
    max_qty: Optional[float] = None
    price: float
    discount_percent: float = 0


class PriceListItemCreate(PriceListItemBase):
    pass


class PriceListItemResponse(PriceListItemBase):
    id: UUID
    price_list_id: UUID
    is_active: bool
    
    class Config:
        from_attributes = True


@router.post("/price-lists/{price_list_id}/items", response_model=PriceListItemResponse, status_code=status.HTTP_201_CREATED)
async def create_price_list_item(
    price_list_id: UUID,
    item_data: PriceListItemCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:create")),
):
    # Verify price list exists
    pl = await db.execute(
        select(PriceList).where(
            PriceList.id == price_list_id,
            PriceList.organization_id == current_user.organization_id
        )
    )
    if not pl.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Price list not found")
    
    item = PriceListItem(
        **item_data.model_dump(),
        price_list_id=price_list_id,
    )
    db.add(item)
    await db.commit()
    await db.refresh(item)
    return item


@router.get("/price-lists/{price_list_id}/items", response_model=List[PriceListItemResponse])
async def list_price_list_items(
    price_list_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("product:view")),
):
    result = await db.execute(
        select(PriceListItem).where(
            PriceListItem.price_list_id == price_list_id,
            PriceListItem.is_active == True
        ).order_by(PriceListItem.min_qty)
    )
    return result.scalars().all()