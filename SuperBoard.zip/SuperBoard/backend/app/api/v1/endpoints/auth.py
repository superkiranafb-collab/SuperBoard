from datetime import datetime, timezone, timedelta
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel, EmailStr
from app.core.database import get_db
from app.core.security import (
    verify_password,
    get_password_hash,
    create_token_pair,
    decode_token,
    create_access_token,
)
from app.core.config import settings
from app.models import User, UserStatus
from app.models.organization import Organization
import structlog

logger = structlog.get_logger()

router = APIRouter()


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshTokenRequest(BaseModel):
    refresh_token: str


class UserResponse(BaseModel):
    id: str
    email: str
    username: str
    full_name: str
    phone: Optional[str]
    status: str
    department: Optional[str]
    designation: Optional[str]
    organization_id: str
    organization_name: str
    assigned_warehouse_ids: list
    permissions: list
    roles: list
    mfa_enabled: bool
    last_login: Optional[datetime]
    created_at: datetime


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str


async def get_current_user(
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> User:
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    token = auth_header.split(" ")[1]
    payload = decode_token(token)
    
    if not payload or payload.get("type") != "access":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload",
        )
    
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
        )
    
    if user.status != UserStatus.ACTIVE:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is not active",
        )
    
    return user


async def get_current_active_user(
    current_user: User = Depends(get_current_user),
) -> User:
    return current_user


def require_permission(permission: str):
    async def permission_checker(
        current_user: User = Depends(get_current_user),
    ) -> User:
        # Check if user has permission via roles
        user_permissions = set(current_user.permissions or [])
        if permission not in user_permissions:
            # Also check role-based permissions (would integrate with Casbin)
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission denied: {permission}",
            )
        return current_user
    return permission_checker


@router.post("/login", response_model=TokenResponse)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.email == form_data.username))
    user = result.scalar_one_or_none()
    
    if not user or not verify_password(form_data.password, user.hashed_password):
        logger.warning("login_failed", email=form_data.username)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if user.status != UserStatus.ACTIVE:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is not active",
        )
    
    # Get organization
    org_result = await db.execute(select(Organization).where(Organization.id == user.organization_id))
    org = org_result.scalar_one_or_none()
    
    # Build permissions from roles (simplified - would use Casbin in production)
    role_permissions = {
        "owner": ["*"],
        "department_head": ["*"],
        "regional_manager": ["view", "create", "update"],
        "warehouse_manager": ["inventory:*", "warehouse:*"],
        "sales_supervisor": ["sales:*", "customer:*"],
        "accountant": ["finance:*", "sales:view", "purchase:view"],
        "production_manager": ["manufacturing:*", "inventory:view"],
        "quality_supervisor": ["quality:*"],
        "hr_manager": ["hr:*"],
        "salesperson": ["sales:create", "customer:create", "inventory:view"],
        "warehouse_staff": ["inventory:*"],
        "driver": ["delivery:*"],
        "factory_operator": ["production:record", "quality:create"],
        "helper": ["production:record"],
    }
    
    user_roles = ["salesperson"]  # Would come from user_roles table
    permissions = []
    for role in user_roles:
        permissions.extend(role_permissions.get(role, []))
    
    token_data = {
        "sub": str(user.id),
        "email": user.email,
        "roles": user_roles,
        "permissions": permissions,
        "warehouse_ids": [str(w) for w in user.assigned_warehouse_ids],
    }
    
    tokens = create_token_pair(**token_data)
    
    # Update last login
    user.last_login = datetime.now(timezone.utc)
    user.failed_login_attempts = 0
    user.locked_until = None
    await db.commit()
    
    logger.info("login_success", user_id=str(user.id), email=user.email)
    
    return tokens


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    request: RefreshTokenRequest,
    db: AsyncSession = Depends(get_db),
):
    payload = decode_token(request.refresh_token)
    
    if not payload or payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token",
        )
    
    user_id = payload.get("sub")
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    
    if not user or user.status != UserStatus.ACTIVE:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive",
        )
    
    # Recreate token with same data
    token_data = {
        "sub": str(user.id),
        "email": user.email,
        "roles": payload.get("roles", []),
        "permissions": payload.get("permissions", []),
        "warehouse_ids": payload.get("warehouse_ids", []),
    }
    
    tokens = create_token_pair(**token_data)
    return tokens


@router.post("/logout")
async def logout(
    current_user: User = Depends(get_current_active_user),
):
    # In a real implementation, you'd blacklist the token
    logger.info("logout", user_id=str(current_user.id))
    return {"message": "Successfully logged out"}


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    org_result = await db.execute(select(Organization).where(Organization.id == current_user.organization_id))
    org = org_result.scalar_one_or_none()
    
    return UserResponse(
        id=str(current_user.id),
        email=current_user.email,
        username=current_user.username,
        full_name=current_user.full_name,
        phone=current_user.phone,
        status=current_user.status.value,
        department=current_user.department,
        designation=current_user.designation,
        organization_id=str(current_user.organization_id),
        organization_name=org.name if org else "",
        assigned_warehouse_ids=[str(w) for w in current_user.assigned_warehouse_ids],
        permissions=current_user.permissions or [],
        roles=["salesperson"],  # Would come from user_roles
        mfa_enabled=current_user.mfa_enabled,
        last_login=current_user.last_login,
        created_at=current_user.created_at,
    )


@router.post("/forgot-password")
async def forgot_password(
    request: ForgotPasswordRequest,
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.email == request.email))
    user = result.scalar_one_or_none()
    
    if not user:
        # Don't reveal if email exists
        return {"message": "If the email exists, a reset link has been sent"}
    
    # Generate reset token (in production, send via email)
    reset_token = create_access_token(
        {"sub": str(user.id), "type": "password_reset"},
        expires_delta=timedelta(hours=settings.PASSWORD_RESET_EXPIRE_HOURS),
    )
    
    logger.info("password_reset_requested", user_id=str(user.id))
    
    # In production: send email with reset_token
    return {"message": "If the email exists, a reset link has been sent", "reset_token": reset_token}


@router.post("/reset-password")
async def reset_password(
    request: ResetPasswordRequest,
    db: AsyncSession = Depends(get_db),
):
    payload = decode_token(request.token)
    
    if not payload or payload.get("type") != "password_reset":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid or expired reset token",
        )
    
    user_id = payload.get("sub")
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )
    
    user.hashed_password = get_password_hash(request.new_password)
    await db.commit()
    
    logger.info("password_reset_completed", user_id=str(user.id))
    
    return {"message": "Password has been reset successfully"}


@router.post("/change-password")
async def change_password(
    current_password: str,
    new_password: str,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    if not verify_password(current_password, current_user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect",
        )
    
    current_user.hashed_password = get_password_hash(new_password)
    await db.commit()
    
    logger.info("password_changed", user_id=str(current_user.id))
    
    return {"message": "Password changed successfully"}