from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
from uuid import UUID
from datetime import datetime, date, timezone
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.models import (
    PurchaseRequisition, PurchaseRequisitionStatus, PurchaseRequisitionItem,
    PurchaseOrder, PurchaseOrderStatus, PurchaseOrderItem,
    PurchaseReceipt, PurchaseReceiptStatus, PurchaseReceiptItem,
    PurchaseInvoice, PurchaseInvoiceStatus, PurchaseInvoiceItem,
    Supplier, SupplierAddress, Product, Warehouse, UOM, User, Organization,
    StockBalance, StockStatus, StockLedgerEntry, TransactionType, Batch, Bin
)
import structlog

logger = structlog.get_logger()

router = APIRouter()


class PurchaseOrderItemCreate(BaseModel):
    product_id: UUID
    description: Optional[str] = None
    qty: float
    uom_id: UUID
    rate: float
    discount_percent: float = 0
    tax_rate: float = 0


class PurchaseOrderCreate(BaseModel):
    supplier_id: UUID
    supplier_address_id: Optional[UUID] = None
    requisition_id: Optional[UUID] = None
    expected_date: Optional[date] = None
    warehouse_id: UUID
    currency: str = "INR"
    terms_conditions: Optional[str] = None
    notes: Optional[str] = None
    items: List[PurchaseOrderItemCreate]


class PurchaseOrderResponse(BaseModel):
    id: UUID
    order_number: str
    supplier_id: UUID
    supplier_name: str
    status: PurchaseOrderStatus
    order_date: datetime
    expected_date: Optional[datetime]
    total_amount: float
    created_at: datetime
    
    class Config:
        from_attributes = True


@router.post("/orders", response_model=PurchaseOrderResponse, status_code=status.HTTP_201_CREATED)
async def create_purchase_order(
    order_data: PurchaseOrderCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("purchase_order:create")),
):
    # Validate supplier
    supplier = await db.execute(
        select(Supplier).where(
            Supplier.id == order_data.supplier_id,
            Supplier.organization_id == current_user.organization_id
        )
    )
    supplier_obj = supplier.scalar_one_or_none()
    if not supplier_obj:
        raise HTTPException(status_code=404, detail="Supplier not found")
    
    # Validate warehouse
    warehouse = await db.execute(
        select(Warehouse).where(
            Warehouse.id == order_data.warehouse_id,
            Warehouse.organization_id == current_user.organization_id
        )
    )
    if not warehouse.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Warehouse not found")
    
    # Generate order number
    today = date.today()
    prefix = f"PO-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(PurchaseOrder.id)).where(
            PurchaseOrder.organization_id == current_user.organization_id,
            PurchaseOrder.order_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    order_number = f"{prefix}{seq:04d}"
    
    # Calculate totals
    subtotal = 0
    discount_amount = 0
    tax_amount = 0
    
    for item in order_data.items:
        item_subtotal = item.qty * item.rate
        item_discount = item_subtotal * (item.discount_percent / 100)
        item_taxable = item_subtotal - item_discount
        item_tax = item_taxable * (item.tax_rate / 100)
        
        subtotal += item_subtotal
        discount_amount += item_discount
        tax_amount += item_tax
    
    total_amount = subtotal - discount_amount + tax_amount
    
    order = PurchaseOrder(
        organization_id=current_user.organization_id,
        order_number=order_number,
        supplier_id=order_data.supplier_id,
        supplier_address_id=order_data.supplier_address_id,
        requisition_id=order_data.requisition_id,
        status=PurchaseOrderStatus.DRAFT,
        order_date=datetime.now(timezone.utc),
        expected_date=datetime.combine(order_data.expected_date, datetime.max.time()).replace(tzinfo=timezone.utc) if order_data.expected_date else None,
        warehouse_id=order_data.warehouse_id,
        currency=order_data.currency,
        subtotal=subtotal,
        discount_amount=discount_amount,
        tax_amount=tax_amount,
        total_amount=total_amount,
        terms_conditions=order_data.terms_conditions,
        notes=order_data.notes,
        created_by=current_user.id,
    )
    db.add(order)
    await db.flush()
    
    for idx, item_data in enumerate(order_data.items):
        item_subtotal = item_data.qty * item_data.rate
        item_discount = item_subtotal * (item_data.discount_percent / 100)
        item_taxable = item_subtotal - item_discount
        item_tax = item_taxable * (item_data.tax_rate / 100)
        item_amount = item_taxable + item_tax
        
        item = PurchaseOrderItem(
            order_id=order.id,
            product_id=item_data.product_id,
            description=item_data.description,
            qty=item_data.qty,
            uom_id=item_data.uom_id,
            rate=item_data.rate,
            discount_percent=item_data.discount_percent,
            discount_amount=item_discount,
            tax_rate=item_data.tax_rate,
            tax_amount=item_tax,
            amount=item_amount,
            sort_order=idx,
        )
        db.add(item)
    
    # Update requisition status
    if order_data.requisition_id:
        req = await db.execute(
            select(PurchaseRequisition).where(PurchaseRequisition.id == order_data.requisition_id)
        )
        req_obj = req.scalar_one_or_none()
        if req_obj:
            req_obj.status = PurchaseRequisitionStatus.ORDERED
    
    await db.commit()
    await db.refresh(order)
    
    logger.info("purchase_order_created", order_id=str(order.id), number=order_number)
    
    return PurchaseOrderResponse(
        id=order.id,
        order_number=order.order_number,
        supplier_id=order.supplier_id,
        supplier_name=supplier_obj.name,
        status=order.status,
        order_date=order.order_date,
        expected_date=order.expected_date,
        total_amount=float(order.total_amount),
        created_at=order.created_at,
    )


@router.get("/orders", response_model=List[PurchaseOrderResponse])
async def list_purchase_orders(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[PurchaseOrderStatus] = None,
    supplier_id: Optional[UUID] = None,
    warehouse_id: Optional[UUID] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("purchase_order:view")),
):
    query = select(PurchaseOrder).where(PurchaseOrder.organization_id == current_user.organization_id)
    
    if status:
        query = query.where(PurchaseOrder.status == status)
    if supplier_id:
        query = query.where(PurchaseOrder.supplier_id == supplier_id)
    if warehouse_id:
        query = query.where(PurchaseOrder.warehouse_id == warehouse_id)
    
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(PurchaseOrder.created_at.desc())
    result = await db.execute(query)
    orders = result.scalars().all()
    
    response = []
    for o in orders:
        supplier = await db.execute(select(Supplier).where(Supplier.id == o.supplier_id))
        sup = supplier.scalar_one_or_none()
        response.append(PurchaseOrderResponse(
            id=o.id,
            order_number=o.order_number,
            supplier_id=o.supplier_id,
            supplier_name=sup.name if sup else "",
            status=o.status,
            order_date=o.order_date,
            expected_date=o.expected_date,
            total_amount=float(o.total_amount),
            created_at=o.created_at,
        ))
    
    return response


class PurchaseReceiptItemCreate(BaseModel):
    purchase_order_item_id: Optional[UUID] = None
    product_id: UUID
    batch_id: Optional[UUID] = None
    bin_id: Optional[UUID] = None
    qty: float
    accepted_qty: float = 0
    rejected_qty: float = 0
    uom_id: UUID
    rate: float
    manufacture_date: Optional[date] = None
    expiry_date: Optional[date] = None
    supplier_batch_number: Optional[str] = None


class PurchaseReceiptCreate(BaseModel):
    purchase_order_id: Optional[UUID] = None
    supplier_id: UUID
    warehouse_id: UUID
    receipt_date: date
    vehicle_number: Optional[str] = None
    driver_name: Optional[str] = None
    driver_phone: Optional[str] = None
    notes: Optional[str] = None
    items: List[PurchaseReceiptItemCreate]


@router.post("/receipts", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_purchase_receipt(
    receipt_data: PurchaseReceiptCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("purchase_receive:create")),
):
    # Validate supplier
    supplier = await db.execute(
        select(Supplier).where(
            Supplier.id == receipt_data.supplier_id,
            Supplier.organization_id == current_user.organization_id
        )
    )
    if not supplier.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Supplier not found")
    
    # Validate warehouse
    warehouse = await db.execute(
        select(Warehouse).where(
            Warehouse.id == receipt_data.warehouse_id,
            Warehouse.organization_id == current_user.organization_id
        )
    )
    if not warehouse.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Warehouse not found")
    
    # Generate receipt number
    today = date.today()
    prefix = f"PR-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(PurchaseReceipt.id)).where(
            PurchaseReceipt.organization_id == current_user.organization_id,
            PurchaseReceipt.receipt_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    receipt_number = f"{prefix}{seq:04d}"
    
    # Determine initial status
    initial_status = PurchaseReceiptStatus.DRAFT
    # If any item requires QC, set to pending QC
    for item in receipt_data.items:
        product = await db.execute(
            select(Product).where(Product.id == item.product_id)
        )
        prod = product.scalar_one_or_none()
        if prod and (prod.is_batch_tracked or prod.is_expiry_tracked):
            initial_status = PurchaseReceiptStatus.PENDING_QC
            break
    
    receipt = PurchaseReceipt(
        organization_id=current_user.organization_id,
        receipt_number=receipt_number,
        purchase_order_id=receipt_data.purchase_order_id,
        supplier_id=receipt_data.supplier_id,
        warehouse_id=receipt_data.warehouse_id,
        status=initial_status,
        receipt_date=datetime.combine(receipt_data.receipt_date, datetime.max.time()).replace(tzinfo=timezone.utc),
        vehicle_number=receipt_data.vehicle_number,
        driver_name=receipt_data.driver_name,
        driver_phone=receipt_data.driver_phone,
        notes=receipt_data.notes,
        received_by=current_user.id,
        created_by=current_user.id,
    )
    db.add(receipt)
    await db.flush()
    
    for item_data in receipt_data.items:
        # Validate product
        product = await db.execute(
            select(Product).where(Product.id == item_data.product_id)
        )
        prod = product.scalar_one_or_none()
        if not prod:
            raise HTTPException(status_code=404, detail=f"Product {item_data.product_id} not found")
        
        # Create or get batch
        batch_id = item_data.batch_id
        if prod.is_batch_tracked and not batch_id:
            # Generate batch number
            batch_prefix = f"B-{prod.code}-{date.today().strftime('%Y%m%d')}-"
            batch_count = await db.execute(
                select(func.count(Batch.id)).where(
                    Batch.organization_id == current_user.organization_id,
                    Batch.product_id == item_data.product_id,
                    Batch.batch_number.like(f"{batch_prefix}%")
                )
            )
            batch_seq = (batch_count.scalar() or 0) + 1
            batch_number = f"{batch_prefix}{batch_seq:04d}"
            
            batch = Batch(
                organization_id=current_user.organization_id,
                product_id=item_data.product_id,
                batch_number=batch_number,
                manufacture_date=datetime.combine(item_data.manufacture_date, datetime.min.time()).replace(tzinfo=timezone.utc) if item_data.manufacture_date else None,
                expiry_date=datetime.combine(item_data.expiry_date, datetime.min.time()).replace(tzinfo=timezone.utc) if item_data.expiry_date else None,
                supplier_batch_number=item_data.supplier_batch_number,
                supplier_id=receipt_data.supplier_id,
                source_type="purchase",
                source_document_id=receipt.id,
                source_document_type="purchase_receipt",
                cost_price=item_data.rate,
                status="active",
                quality_status="pending" if initial_status == PurchaseReceiptStatus.PENDING_QC else "passed",
                created_by=current_user.id,
            )
            db.add(batch)
            await db.flush()
            batch_id = batch.id
        
        item = PurchaseReceiptItem(
            receipt_id=receipt.id,
            purchase_order_item_id=item_data.purchase_order_item_id,
            product_id=item_data.product_id,
            batch_id=batch_id,
            bin_id=item_data.bin_id,
            qty=item_data.qty,
            accepted_qty=item_data.accepted_qty,
            rejected_qty=item_data.rejected_qty,
            uom_id=item_data.uom_id,
            rate=item_data.rate,
            amount=item_data.qty * item_data.rate,
            manufacture_date=datetime.combine(item_data.manufacture_date, datetime.min.time()).replace(tzinfo=timezone.utc) if item_data.manufacture_date else None,
            expiry_date=datetime.combine(item_data.expiry_date, datetime.min.time()).replace(tzinfo=timezone.utc) if item_data.expiry_date else None,
            supplier_batch_number=item_data.supplier_batch_number,
        )
        db.add(item)
        
        # Update purchase order received qty
        if item_data.purchase_order_item_id:
            po_item = await db.execute(
                select(PurchaseOrderItem).where(PurchaseOrderItem.id == item_data.purchase_order_item_id)
            )
            po_item_obj = po_item.scalar_one_or_none()
            if po_item_obj:
                po_item_obj.received_qty = float(po_item_obj.received_qty) + item_data.accepted_qty
    
    await db.commit()
    
    logger.info("purchase_receipt_created", receipt_id=str(receipt.id), number=receipt_number)
    
    return {"id": str(receipt.id), "receipt_number": receipt_number, "status": receipt.status.value}


@router.post("/receipts/{receipt_id}/qc-complete")
async def complete_purchase_receipt_qc(
    receipt_id: UUID,
    qc_data: dict,  # {qc_by, items: [{item_id, accepted_qty, rejected_qty, quality_status, notes}]}
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("purchase_receive:create")),
):
    result = await db.execute(
        select(PurchaseReceipt).where(
            PurchaseReceipt.id == receipt_id,
            PurchaseReceipt.organization_id == current_user.organization_id
        )
    )
    receipt = result.scalar_one_or_none()
    
    if not receipt:
        raise HTTPException(status_code=404, detail="Receipt not found")
    
    if receipt.status != PurchaseReceiptStatus.PENDING_QC:
        raise HTTPException(status_code=400, detail="Receipt is not pending QC")
    
    receipt.status = PurchaseReceiptStatus.QC_PASSED
    receipt.qc_by = qc_data.get("qc_by", current_user.id)
    receipt.qc_date = datetime.now(timezone.utc)
    receipt.qc_notes = qc_data.get("notes")
    
    all_accepted = True
    for item_qc in qc_data.get("items", []):
        item = await db.execute(
            select(PurchaseReceiptItem).where(
                PurchaseReceiptItem.id == item_qc["item_id"],
                PurchaseReceiptItem.receipt_id == receipt_id
            )
        )
        receipt_item = item.scalar_one_or_none()
        
        if not receipt_item:
            continue
        
        receipt_item.accepted_qty = item_qc.get("accepted_qty", 0)
        receipt_item.rejected_qty = item_qc.get("rejected_qty", 0)
        
        if receipt_item.rejected_qty > 0:
            all_accepted = False
        
        # Update batch quality status
        if receipt_item.batch_id:
            batch = await db.execute(
                select(Batch).where(Batch.id == receipt_item.batch_id)
            )
            batch_obj = batch.scalar_one_or_none()
            if batch_obj:
                batch_obj.quality_status = item_qc.get("quality_status", "passed")
    
    if all_accepted:
        receipt.status = PurchaseReceiptStatus.ACCEPTED
    else:
        receipt.status = PurchaseReceiptStatus.QC_FAILED
    
    # If accepted, update stock balances
    if receipt.status in [PurchaseReceiptStatus.ACCEPTED, PurchaseReceiptStatus.QC_PASSED]:
        items_result = await db.execute(
            select(PurchaseReceiptItem).where(PurchaseReceiptItem.receipt_id == receipt_id)
        )
        for item in items_result.scalars().all():
            if item.accepted_qty > 0:
                # Create stock balance
                balance = await db.execute(
                    select(StockBalance).where(
                        StockBalance.organization_id == current_user.organization_id,
                        StockBalance.product_id == item.product_id,
                        StockBalance.warehouse_id == receipt.warehouse_id,
                        StockBalance.bin_id == item.bin_id,
                        StockBalance.batch_id == item.batch_id,
                        StockBalance.stock_status == StockStatus.AVAILABLE.value
                    )
                )
                balance_obj = balance.scalar_one_or_none()
                
                new_qty = item.accepted_qty
                if balance_obj:
                    new_qty = float(balance_obj.qty) + item.accepted_qty
                    balance_obj.qty = new_qty
                    balance_obj.valuation_rate = item.rate
                    balance_obj.last_transaction_date = datetime.now(timezone.utc)
                    balance_obj.last_updated = datetime.now(timezone.utc)
                else:
                    balance_obj = StockBalance(
                        organization_id=current_user.organization_id,
                        product_id=item.product_id,
                        warehouse_id=receipt.warehouse_id,
                        bin_id=item.bin_id,
                        batch_id=item.batch_id,
                        stock_status=StockStatus.AVAILABLE.value,
                        qty=item.accepted_qty,
                        valuation_rate=item.rate,
                        last_transaction_date=datetime.now(timezone.utc),
                    )
                    db.add(balance_obj)
                
                # Create ledger entry
                ledger_entry = StockLedgerEntry(
                    organization_id=current_user.organization_id,
                    product_id=item.product_id,
                    warehouse_id=receipt.warehouse_id,
                    bin_id=item.bin_id,
                    batch_id=item.batch_id,
                    transaction_type=TransactionType.PURCHASE_RECEIPT.value,
                    transaction_id=receipt.id,
                    transaction_number=receipt.receipt_number,
                    transaction_date=datetime.now(timezone.utc),
                    qty_in=item.accepted_qty,
                    balance_qty=new_qty,
                    valuation_rate=item.rate,
                    stock_status=StockStatus.AVAILABLE.value,
                    reference_doctype="purchase_receipt",
                    reference_docname=receipt.receipt_number,
                    created_by=current_user.id,
                )
                db.add(ledger_entry)
        
        # Update purchase order status
        if receipt.purchase_order_id:
            po = await db.execute(
                select(PurchaseOrder).where(PurchaseOrder.id == receipt.purchase_order_id)
            )
            po_obj = po.scalar_one_or_none()
            if po_obj:
                # Check if all items received
                po_items = await db.execute(
                    select(PurchaseOrderItem).where(PurchaseOrderItem.order_id == po_obj.id)
                )
                all_received = all(
                    float(item.received_qty) >= float(item.qty)
                    for item in po_items.scalars().all()
                )
                if all_received:
                    po_obj.status = PurchaseOrderStatus.RECEIVED
                else:
                    po_obj.status = PurchaseOrderStatus.PARTIALLY_RECEIVED
    
    await db.commit()
    
    logger.info("purchase_receipt_qc_completed", receipt_id=str(receipt_id), status=receipt.status.value)
    
    return {"message": "QC completed", "status": receipt.status.value}


class PurchaseInvoiceCreate(BaseModel):
    supplier_id: UUID
    supplier_invoice_number: str
    purchase_order_id: Optional[UUID] = None
    receipt_id: Optional[UUID] = None
    invoice_date: date
    due_date: date
    currency: str = "INR"
    gst_type: str = "B2B"
    place_of_supply: Optional[str] = None
    reverse_charge: bool = False


@router.post("/invoices", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_purchase_invoice(
    invoice_data: PurchaseInvoiceCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("invoice:create")),
):
    # Validate supplier
    supplier = await db.execute(
        select(Supplier).where(
            Supplier.id == invoice_data.supplier_id,
            Supplier.organization_id == current_user.organization_id
        )
    )
    supplier_obj = supplier.scalar_one_or_none()
    if not supplier_obj:
        raise HTTPException(status_code=404, detail="Supplier not found")
    
    # Check duplicate supplier invoice number
    existing = await db.execute(
        select(PurchaseInvoice).where(
            PurchaseInvoice.organization_id == current_user.organization_id,
            PurchaseInvoice.supplier_id == invoice_data.supplier_id,
            PurchaseInvoice.supplier_invoice_number == invoice_data.supplier_invoice_number
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Supplier invoice number already exists")
    
    # Generate invoice number
    today = date.today()
    prefix = f"PI-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(PurchaseInvoice.id)).where(
            PurchaseInvoice.organization_id == current_user.organization_id,
            PurchaseInvoice.invoice_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    invoice_number = f"{prefix}{seq:04d}"
    
    # Calculate from receipt or PO
    subtotal = 0
    discount_amount = 0
    tax_amount = 0
    source_items = []
    
    if invoice_data.receipt_id:
        receipt = await db.execute(
            select(PurchaseReceipt).where(PurchaseReceipt.id == invoice_data.receipt_id)
        )
        receipt_obj = receipt.scalar_one_or_none()
        if receipt_obj:
            items_result = await db.execute(
                select(PurchaseReceiptItem).where(PurchaseReceiptItem.receipt_id == receipt_obj.id)
            )
            for item in items_result.scalars().all():
                if item.accepted_qty > 0:
                    source_items.append({
                        "product_id": str(item.product_id),
                        "qty": item.accepted_qty,
                        "uom_id": str(item.uom_id),
                        "rate": float(item.rate),
                        "discount_percent": 0,
                        "tax_rate": float(item.tax_rate) if hasattr(item, 'tax_rate') else 0,
                    })
    
    elif invoice_data.purchase_order_id:
        po = await db.execute(
            select(PurchaseOrder).where(PurchaseOrder.id == invoice_data.purchase_order_id)
        )
        po_obj = po.scalar_one_or_none()
        if po_obj:
            items_result = await db.execute(
                select(PurchaseOrderItem).where(PurchaseOrderItem.order_id == po_obj.id)
            )
            for item in items_result.scalars().all():
                pending_qty = float(item.received_qty) - float(item.billed_qty)
                if pending_qty > 0:
                    source_items.append({
                        "purchase_order_item_id": str(item.id),
                        "product_id": str(item.product_id),
                        "qty": pending_qty,
                        "uom_id": str(item.uom_id),
                        "rate": float(item.rate),
                        "discount_percent": float(item.discount_percent),
                        "tax_rate": float(item.tax_rate),
                    })
    
    for item in source_items:
        item_subtotal = item["qty"] * item["rate"]
        item_discount = item_subtotal * (item.get("discount_percent", 0) / 100)
        item_taxable = item_subtotal - item_discount
        item_tax = item_taxable * (item.get("tax_rate", 0) / 100)
        
        subtotal += item_subtotal
        discount_amount += item_discount
        tax_amount += item_tax
    
    total_amount = subtotal - discount_amount + tax_amount
    
    invoice = PurchaseInvoice(
        organization_id=current_user.organization_id,
        invoice_number=invoice_number,
        supplier_invoice_number=invoice_data.supplier_invoice_number,
        supplier_id=invoice_data.supplier_id,
        purchase_order_id=invoice_data.purchase_order_id,
        receipt_id=invoice_data.receipt_id,
        status=PurchaseInvoiceStatus.DRAFT,
        invoice_date=datetime.combine(invoice_data.invoice_date, datetime.max.time()).replace(tzinfo=timezone.utc),
        due_date=datetime.combine(invoice_data.due_date, datetime.max.time()).replace(tzinfo=timezone.utc),
        currency=invoice_data.currency,
        subtotal=subtotal,
        discount_amount=discount_amount,
        tax_amount=tax_amount,
        total_amount=total_amount,
        balance_amount=total_amount,
        gst_type=invoice_data.gst_type,
        place_of_supply=invoice_data.place_of_supply,
        reverse_charge=invoice_data.reverse_charge,
        created_by=current_user.id,
    )
    db.add(invoice)
    await db.flush()
    
    for item in source_items:
        item_subtotal = item["qty"] * item["rate"]
        item_discount = item_subtotal * (item.get("discount_percent", 0) / 100)
        item_taxable = item_subtotal - item_discount
        item_tax = item_taxable * (item.get("tax_rate", 0) / 100)
        item_amount = item_taxable + item_tax
        
        inv_item = PurchaseInvoiceItem(
            invoice_id=invoice.id,
            purchase_order_item_id=UUID(item["purchase_order_item_id"]) if item.get("purchase_order_item_id") else None,
            product_id=UUID(item["product_id"]),
            qty=item["qty"],
            uom_id=UUID(item["uom_id"]),
            rate=item["rate"],
            discount_percent=item.get("discount_percent", 0),
            discount_amount=item_discount,
            tax_rate=item.get("tax_rate", 0),
            tax_amount=item_tax,
            amount=item_amount,
        )
        db.add(inv_item)
        
        # Update PO billed qty
        if item.get("purchase_order_item_id"):
            po_item = await db.execute(
                select(PurchaseOrderItem).where(PurchaseOrderItem.id == item["purchase_order_item_id"])
            )
            po_item_obj = po_item.scalar_one_or_none()
            if po_item_obj:
                po_item_obj.billed_qty = float(po_item_obj.billed_qty) + item["qty"]
    
    await db.commit()
    
    logger.info("purchase_invoice_created", invoice_id=str(invoice.id), number=invoice_number)
    
    return {"id": str(invoice.id), "invoice_number": invoice_number, "total_amount": float(total_amount)}


@router.post("/invoices/{invoice_id}/approve")
async def approve_purchase_invoice(
    invoice_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("invoice:approve")),
):
    result = await db.execute(
        select(PurchaseInvoice).where(
            PurchaseInvoice.id == invoice_id,
            PurchaseInvoice.organization_id == current_user.organization_id
        )
    )
    invoice = result.scalar_one_or_none()
    
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    
    if invoice.status != PurchaseInvoiceStatus.DRAFT:
        raise HTTPException(status_code=400, detail="Invoice already processed")
    
    invoice.status = PurchaseInvoiceStatus.APPROVED
    invoice.approved_by = current_user.id
    invoice.approved_at = datetime.now(timezone.utc)
    
    await db.commit()
    
    logger.info("purchase_invoice_approved", invoice_id=str(invoice_id))
    
    return {"message": "Invoice approved", "status": invoice.status.value}