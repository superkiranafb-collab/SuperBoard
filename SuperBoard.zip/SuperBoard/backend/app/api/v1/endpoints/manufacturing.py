from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
from uuid import UUID
from datetime import datetime, date, timezone
from decimal import Decimal
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.models import (
    BOMHeader, BOMStatus, BOMType, BOMItem, BOMItemType, BOMOperation,
    WorkCenter, WorkCenterType,
    WorkOrder, WorkOrderStatus, WorkOrderPriority,
    MaterialIssue, MaterialIssueItem,
    JobCard, JobCardStatus,
    ProductionEntry,
    QualityCheckTemplate, QualityCheckParameter, QualityCheckParameterType,
    QualityInspection, QualityInspectionStatus, QualityInspectionResult,
    BatchRelease, BatchReleaseStatus,
    Product, UOM, Warehouse, Batch, User, Organization, Bin, StockBalance, StockStatus, StockLedgerEntry, TransactionType
)
import structlog

logger = structlog.get_logger()

router = APIRouter()


# BOM Endpoints
class BOMItemCreate(BaseModel):
    product_id: UUID
    item_type: BOMItemType
    qty: float
    uom_id: UUID
    wastage_percent: float = 0
    is_mandatory: bool = True
    operation_sequence: Optional[int] = None


class BOMOperationCreate(BaseModel):
    sequence: int
    name: str
    description: Optional[str] = None
    work_center_id: Optional[UUID] = None
    estimated_duration_minutes: float = 0
    labor_hours_per_unit: float = 0
    machine_hours_per_unit: float = 0
    setup_time_minutes: float = 0
    is_quality_check: bool = False
    quality_check_template_id: Optional[UUID] = None


class BOMCreate(BaseModel):
    finished_product_id: UUID
    version: str = "1.0"
    type: BOMType = BOMType.MANUFACTURING
    output_qty: float = 1
    output_uom_id: UUID
    effective_from: date
    effective_to: Optional[date] = None
    standard_yield_percent: float = 100
    standard_wastage_percent: float = 0
    labor_cost_per_unit: float = 0
    machine_cost_per_unit: float = 0
    overhead_cost_per_unit: float = 0
    items: List[BOMItemCreate]
    operations: List[BOMOperationCreate]


@router.post("/boms", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_bom(
    bom_data: BOMCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("bom:create")),
):
    # Validate finished product
    product = await db.execute(
        select(Product).where(
            Product.id == bom_data.finished_product_id,
            Product.organization_id == current_user.organization_id,
            Product.is_producible == True
        )
    )
    prod = product.scalar_one_or_none()
    if not prod:
        raise HTTPException(status_code=404, detail="Finished product not found or not producible")
    
    # Validate output UOM
    uom = await db.execute(select(UOM).where(UOM.id == bom_data.output_uom_id))
    if not uom.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Output UOM not found")
    
    # Generate BOM number
    today = date.today()
    prefix = f"BOM-{prod.code}-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(BOMHeader.id)).where(
            BOMHeader.organization_id == current_user.organization_id,
            BOMHeader.bom_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    bom_number = f"{prefix}{seq:04d}"
    
    bom = BOMHeader(
        organization_id=current_user.organization_id,
        finished_product_id=bom_data.finished_product_id,
        bom_number=bom_number,
        version=bom_data.version,
        status=BOMStatus.DRAFT,
        type=bom_data.type,
        output_qty=bom_data.output_qty,
        output_uom_id=bom_data.output_uom_id,
        effective_from=datetime.combine(bom_data.effective_from, datetime.min.time()).replace(tzinfo=timezone.utc),
        effective_to=datetime.combine(bom_data.effective_to, datetime.min.time()).replace(tzinfo=timezone.utc) if bom_data.effective_to else None,
        standard_yield_percent=bom_data.standard_yield_percent,
        standard_wastage_percent=bom_data.standard_wastage_percent,
        labor_cost_per_unit=bom_data.labor_cost_per_unit,
        machine_cost_per_unit=bom_data.machine_cost_per_unit,
        overhead_cost_per_unit=bom_data.overhead_cost_per_unit,
        created_by=current_user.id,
    )
    db.add(bom)
    await db.flush()
    
    for item_data in bom_data.items:
        # Validate item product
        item_product = await db.execute(
            select(Product).where(Product.id == item_data.product_id)
        )
        if not item_product.scalar_one_or_none():
            raise HTTPException(status_code=404, detail=f"Item product {item_data.product_id} not found")
        
        item = BOMItem(
            bom_header_id=bom.id,
            product_id=item_data.product_id,
            item_type=item_data.item_type,
            qty=item_data.qty,
            uom_id=item_data.uom_id,
            wastage_percent=item_data.wastage_percent,
            is_mandatory=item_data.is_mandatory,
            operation_sequence=item_data.operation_sequence,
        )
        db.add(item)
    
    for op_data in bom_data.operations:
        if op_data.work_center_id:
            wc = await db.execute(select(WorkCenter).where(WorkCenter.id == op_data.work_center_id))
            if not wc.scalar_one_or_none():
                raise HTTPException(status_code=404, detail=f"Work center {op_data.work_center_id} not found")
        
        operation = BOMOperation(
            bom_header_id=bom.id,
            sequence=op_data.sequence,
            name=op_data.name,
            description=op_data.description,
            work_center_id=op_data.work_center_id,
            estimated_duration_minutes=op_data.estimated_duration_minutes,
            labor_hours_per_unit=op_data.labor_hours_per_unit,
            machine_hours_per_unit=op_data.machine_hours_per_unit,
            setup_time_minutes=op_data.setup_time_minutes,
            is_quality_check=op_data.is_quality_check,
            quality_check_template_id=op_data.quality_check_template_id,
        )
        db.add(operation)
    
    await db.commit()
    
    logger.info("bom_created", bom_id=str(bom.id), number=bom_number)
    
    return {"id": str(bom.id), "bom_number": bom_number, "status": bom.status.value}


@router.get("/boms", response_model=List[dict])
async def list_boms(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[BOMStatus] = None,
    finished_product_id: Optional[UUID] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("bom:view")),
):
    query = select(BOMHeader).where(BOMHeader.organization_id == current_user.organization_id)
    
    if status:
        query = query.where(BOMHeader.status == status)
    if finished_product_id:
        query = query.where(BOMHeader.finished_product_id == finished_product_id)
    
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(BOMHeader.created_at.desc())
    result = await db.execute(query)
    boms = result.scalars().all()
    
    response = []
    for b in boms:
        product = await db.execute(select(Product).where(Product.id == b.finished_product_id))
        prod = product.scalar_one_or_none()
        response.append({
            "id": str(b.id),
            "bom_number": b.bom_number,
            "version": b.version,
            "finished_product_id": str(b.finished_product_id),
            "finished_product_code": prod.code if prod else "",
            "finished_product_name": prod.name if prod else "",
            "status": b.status.value,
            "type": b.type.value,
            "output_qty": float(b.output_qty),
            "effective_from": b.effective_from.isoformat(),
            "effective_to": b.effective_to.isoformat() if b.effective_to else None,
        })
    
    return response


@router.post("/boms/{bom_id}/approve")
async def approve_bom(
    bom_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("bom:update")),
):
    result = await db.execute(
        select(BOMHeader).where(
            BOMHeader.id == bom_id,
            BOMHeader.organization_id == current_user.organization_id
        )
    )
    bom = result.scalar_one_or_none()
    
    if not bom:
        raise HTTPException(status_code=404, detail="BOM not found")
    
    if bom.status != BOMStatus.DRAFT:
        raise HTTPException(status_code=400, detail="BOM is not in draft status")
    
    bom.status = BOMStatus.ACTIVE
    bom.approved_by = current_user.id
    bom.approved_at = datetime.now(timezone.utc)
    
    # Deactivate other versions of same product
    await db.execute(
        select(BOMHeader).where(
            BOMHeader.finished_product_id == bom.finished_product_id,
            BOMHeader.id != bom_id,
            BOMHeader.status == BOMStatus.ACTIVE
        )
    )
    # Would need update to set status to OBSOLETE
    
    await db.commit()
    
    logger.info("bom_approved", bom_id=str(bom_id))
    
    return {"message": "BOM approved", "status": bom.status.value}


# Work Center Endpoints
class WorkCenterCreate(BaseModel):
    code: str
    name: str
    type: WorkCenterType
    description: Optional[str] = None
    capacity_per_hour: Optional[float] = None
    cost_per_hour: float = 0
    location: Optional[str] = None


@router.post("/work-centers", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_work_center(
    wc_data: WorkCenterCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("bom:create")),
):
    existing = await db.execute(
        select(WorkCenter).where(
            WorkCenter.organization_id == current_user.organization_id,
            WorkCenter.code == wc_data.code
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Work center code already exists")
    
    wc = WorkCenter(
        organization_id=current_user.organization_id,
        **wc_data.model_dump(),
    )
    db.add(wc)
    await db.commit()
    await db.refresh(wc)
    
    return {"id": str(wc.id), "code": wc.code, "name": wc.name}


@router.get("/work-centers", response_model=List[dict])
async def list_work_centers(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("bom:view")),
):
    result = await db.execute(
        select(WorkCenter).where(
            WorkCenter.organization_id == current_user.organization_id,
            WorkCenter.is_active == True
        ).order_by(WorkCenter.code)
    )
    return [
        {
            "id": str(wc.id),
            "code": wc.code,
            "name": wc.name,
            "type": wc.type.value,
            "capacity_per_hour": float(wc.capacity_per_hour) if wc.capacity_per_hour else None,
            "cost_per_hour": float(wc.cost_per_hour),
        }
        for wc in result.scalars().all()
    ]


# Work Order Endpoints
class WorkOrderCreate(BaseModel):
    bom_id: UUID
    priority: WorkOrderPriority = WorkOrderPriority.NORMAL
    planned_start_date: datetime
    planned_end_date: datetime
    planned_qty: float
    warehouse_id: UUID
    wip_warehouse_id: Optional[UUID] = None
    assigned_to: Optional[UUID] = None


@router.post("/work-orders", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_work_order(
    wo_data: WorkOrderCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("work_order:create")),
):
    # Validate BOM
    bom = await db.execute(
        select(BOMHeader).where(
            BOMHeader.id == wo_data.bom_id,
            BOMHeader.organization_id == current_user.organization_id,
            BOMHeader.status == BOMStatus.ACTIVE
        )
    )
    bom_obj = bom.scalar_one_or_none()
    if not bom_obj:
        raise HTTPException(status_code=404, detail="Active BOM not found")
    
    # Validate warehouses
    fg_warehouse = await db.execute(
        select(Warehouse).where(
            Warehouse.id == wo_data.warehouse_id,
            Warehouse.organization_id == current_user.organization_id
        )
    )
    if not fg_warehouse.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Finished goods warehouse not found")
    
    if wo_data.wip_warehouse_id:
        wip_warehouse = await db.execute(
            select(Warehouse).where(
                Warehouse.id == wo_data.wip_warehouse_id,
                Warehouse.organization_id == current_user.organization_id
            )
        )
        if not wip_warehouse.scalar_one_or_none():
            raise HTTPException(status_code=404, detail="WIP warehouse not found")
    
    # Generate work order number
    today = date.today()
    prefix = f"WO-{bom_obj.finished_product_id}-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(WorkOrder.id)).where(
            WorkOrder.organization_id == current_user.organization_id,
            WorkOrder.work_order_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    work_order_number = f"{prefix}{seq:04d}"
    
    wo = WorkOrder(
        organization_id=current_user.organization_id,
        work_order_number=work_order_number,
        bom_id=wo_data.bom_id,
        status=WorkOrderStatus.DRAFT,
        priority=wo_data.priority,
        planned_start_date=wo_data.planned_start_date,
        planned_end_date=wo_data.planned_end_date,
        planned_qty=wo_data.planned_qty,
        warehouse_id=wo_data.warehouse_id,
        wip_warehouse_id=wo_data.wip_warehouse_id,
        assigned_to=wo_data.assigned_to,
        created_by=current_user.id,
    )
    db.add(wo)
    await db.commit()
    await db.refresh(wo)
    
    logger.info("work_order_created", wo_id=str(wo.id), number=work_order_number)
    
    return {"id": str(wo.id), "work_order_number": work_order_number, "status": wo.status.value}


@router.get("/work-orders", response_model=List[dict])
async def list_work_orders(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[WorkOrderStatus] = None,
    assigned_to: Optional[UUID] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("work_order:view")),
):
    query = select(WorkOrder).where(WorkOrder.organization_id == current_user.organization_id)
    
    if status:
        query = query.where(WorkOrder.status == status)
    if assigned_to:
        query = query.where(WorkOrder.assigned_to == assigned_to)
    
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(WorkOrder.created_at.desc())
    result = await db.execute(query)
    orders = result.scalars().all()
    
    response = []
    for wo in orders:
        bom = await db.execute(select(BOMHeader).where(BOMHeader.id == wo.bom_id))
        bom_obj = bom.scalar_one_or_none()
        
        product = None
        if bom_obj:
            prod = await db.execute(select(Product).where(Product.id == bom_obj.finished_product_id))
            product = prod.scalar_one_or_none()
        
        response.append({
            "id": str(wo.id),
            "work_order_number": wo.work_order_number,
            "bom_id": str(wo.bom_id),
            "finished_product_code": product.code if product else "",
            "finished_product_name": product.name if product else "",
            "status": wo.status.value,
            "priority": wo.priority.value,
            "planned_qty": float(wo.planned_qty),
            "produced_qty": float(wo.produced_qty),
            "planned_start_date": wo.planned_start_date.isoformat(),
            "planned_end_date": wo.planned_end_date.isoformat(),
        })
    
    return response


@router.post("/work-orders/{wo_id}/release")
async def release_work_order(
    wo_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("work_order:update")),
):
    result = await db.execute(
        select(WorkOrder).where(
            WorkOrder.id == wo_id,
            WorkOrder.organization_id == current_user.organization_id
        )
    )
    wo = result.scalar_one_or_none()
    
    if not wo:
        raise HTTPException(status_code=404, detail="Work order not found")
    
    if wo.status != WorkOrderStatus.DRAFT and wo.status != WorkOrderStatus.PLANNED:
        raise HTTPException(status_code=400, detail="Work order cannot be released")
    
    wo.status = WorkOrderStatus.RELEASED
    wo.released_by = current_user.id
    wo.released_at = datetime.now(timezone.utc)
    
    # Create job cards for each operation
    operations = await db.execute(
        select(BOMOperation).where(BOMOperation.bom_header_id == wo.bom_id).order_by(BOMOperation.sequence)
    )
    for op in operations.scalars().all():
        job_card = JobCard(
            organization_id=current_user.organization_id,
            job_card_number=f"JC-{wo.work_order_number}-{op.sequence:02d}",
            work_order_id=wo.id,
            operation_id=op.id,
            work_center_id=op.work_center_id,
            status=JobCardStatus.PENDING,
            planned_start=wo.planned_start_date,
            planned_end=wo.planned_end_date,
            planned_qty=wo.planned_qty,
        )
        db.add(job_card)
    
    await db.commit()
    
    logger.info("work_order_released", wo_id=str(wo_id))
    
    return {"message": "Work order released", "status": wo.status.value}


# Material Issue Endpoints
class MaterialIssueCreate(BaseModel):
    work_order_id: UUID
    issue_date: date
    items: List[dict]  # [{bom_item_id, product_id, batch_id, bin_id, qty, uom_id, valuation_rate}]


@router.post("/material-issues", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_material_issue(
    issue_data: MaterialIssueCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("production:record")),
):
    # Validate work order
    wo = await db.execute(
        select(WorkOrder).where(
            WorkOrder.id == issue_data.work_order_id,
            WorkOrder.organization_id == current_user.organization_id,
            WorkOrder.status.in_([WorkOrderStatus.RELEASED, WorkOrderStatus.IN_PROGRESS])
        )
    )
    wo_obj = wo.scalar_one_or_none()
    if not wo_obj:
        raise HTTPException(status_code=404, detail="Work order not found or not in releasable status")
    
    # Generate issue number
    today = date.today()
    prefix = f"MI-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(MaterialIssue.id)).where(
            MaterialIssue.organization_id == current_user.organization_id,
            MaterialIssue.issue_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    issue_number = f"{prefix}{seq:04d}"
    
    issue = MaterialIssue(
        organization_id=current_user.organization_id,
        issue_number=issue_number,
        work_order_id=issue_data.work_order_id,
        issue_date=datetime.combine(issue_data.issue_date, datetime.max.time()).replace(tzinfo=timezone.utc),
        status="pending",
        issued_by=current_user.id,
        created_by=current_user.id,
    )
    db.add(issue)
    await db.flush()
    
    all_issued = True
    for item_data in issue_data.items:
        # Validate stock availability
        balance = await db.execute(
            select(StockBalance).where(
                StockBalance.organization_id == current_user.organization_id,
                StockBalance.product_id == item_data["product_id"],
                StockBalance.warehouse_id == wo_obj.warehouse_id,  # Source from FG warehouse or RM warehouse
                StockBalance.bin_id == item_data.get("bin_id"),
                StockBalance.batch_id == item_data.get("batch_id"),
                StockBalance.stock_status == StockStatus.AVAILABLE.value
            )
        )
        balance_obj = balance.scalar_one_or_none()
        
        if not balance_obj or float(balance_obj.qty) < item_data["qty"]:
            all_issued = False
            # Still create the item but mark as pending
        
        item = MaterialIssueItem(
            issue_id=issue.id,
            bom_item_id=item_data.get("bom_item_id"),
            product_id=item_data["product_id"],
            batch_id=item_data.get("batch_id"),
            bin_id=item_data.get("bin_id"),
            planned_qty=item_data["qty"],
            issued_qty=item_data["qty"] if all_issued else 0,
            uom_id=item_data["uom_id"],
            valuation_rate=item_data.get("valuation_rate"),
        )
        db.add(item)
        
        if all_issued:
            # Create ledger entry for material issue
            new_qty = float(balance_obj.qty) - item_data["qty"]
            ledger_entry = StockLedgerEntry(
                organization_id=current_user.organization_id,
                product_id=item_data["product_id"],
                warehouse_id=wo_obj.warehouse_id,
                bin_id=item_data.get("bin_id"),
                batch_id=item_data.get("batch_id"),
                transaction_type=TransactionType.PRODUCTION_ISSUE.value,
                transaction_id=issue.id,
                transaction_number=issue_number,
                transaction_date=datetime.now(timezone.utc),
                qty_out=item_data["qty"],
                balance_qty=new_qty,
                valuation_rate=item_data.get("valuation_rate"),
                stock_status=StockStatus.AVAILABLE.value,
                reference_doctype="material_issue",
                reference_docname=issue_number,
                created_by=current_user.id,
            )
            db.add(ledger_entry)
            
            balance_obj.qty = new_qty
            balance_obj.last_transaction_date = datetime.now(timezone.utc)
            balance_obj.last_updated = datetime.now(timezone.utc)
    
    issue.status = "completed" if all_issued else "partial"
    
    await db.commit()
    
    logger.info("material_issue_created", issue_id=str(issue.id), number=issue_number)
    
    return {"id": str(issue.id), "issue_number": issue_number, "status": issue.status}


# Production Entry Endpoints
class ProductionEntryCreate(BaseModel):
    work_order_id: UUID
    job_card_id: Optional[UUID] = None
    entry_date: date
    entry_type: str = "production"
    finished_qty: float
    rejected_qty: float = 0
    scrap_qty: float = 0
    batch_number: Optional[str] = None


@router.post("/production-entries", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_production_entry(
    entry_data: ProductionEntryCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("production:record")),
):
    # Validate work order
    wo = await db.execute(
        select(WorkOrder).where(
            WorkOrder.id == entry_data.work_order_id,
            WorkOrder.organization_id == current_user.organization_id,
            WorkOrder.status.in_([WorkOrderStatus.RELEASED, WorkOrderStatus.IN_PROGRESS])
        )
    )
    wo_obj = wo.scalar_one_or_none()
    if not wo_obj:
        raise HTTPException(status_code=404, detail="Work order not found or not in progress")
    
    # Validate job card if provided
    if entry_data.job_card_id:
        jc = await db.execute(
            select(JobCard).where(
                JobCard.id == entry_data.job_card_id,
                JobCard.work_order_id == wo_obj.id
            )
        )
        if not jc.scalar_one_or_none():
            raise HTTPException(status_code=404, detail="Job card not found for this work order")
    
    # Generate entry number
    today = date.today()
    prefix = f"PE-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(ProductionEntry.id)).where(
            ProductionEntry.organization_id == current_user.organization_id,
            ProductionEntry.entry_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    entry_number = f"{prefix}{seq:04d}"
    
    # Generate batch number if not provided
    batch_number = entry_data.batch_number
    batch_id = None
    
    if entry_data.finished_qty > 0:
        bom = await db.execute(select(BOMHeader).where(BOMHeader.id == wo_obj.bom_id))
        bom_obj = bom.scalar_one_or_none()
        
        if not batch_number:
            prod = await db.execute(select(Product).where(Product.id == bom_obj.finished_product_id))
            prod_obj = prod.scalar_one_or_none()
            batch_prefix = f"{prod_obj.code}-{date.today().strftime('%Y%m%d')}-"
            batch_count = await db.execute(
                select(func.count(Batch.id)).where(
                    Batch.organization_id == current_user.organization_id,
                    Batch.product_id == bom_obj.finished_product_id,
                    Batch.batch_number.like(f"{batch_prefix}%")
                )
            )
            batch_seq = (batch_count.scalar() or 0) + 1
            batch_number = f"{batch_prefix}{batch_seq:04d}"
        
        # Create batch
        batch = Batch(
            organization_id=current_user.organization_id,
            product_id=bom_obj.finished_product_id,
            batch_number=batch_number,
            manufacture_date=datetime.now(timezone.utc),
            expiry_date=datetime.now(timezone.utc) + timedelta(days=prod_obj.shelf_life_days) if prod_obj and prod_obj.shelf_life_days else None,
            source_type="production",
            source_document_id=wo_obj.id,
            source_document_type="work_order",
            cost_price=0,  # Would calculate from actual costs
            status="active",
            quality_status="pending",
            created_by=current_user.id,
        )
        db.add(batch)
        await db.flush()
        batch_id = batch.id
    
    entry = ProductionEntry(
        organization_id=current_user.organization_id,
        entry_number=entry_number,
        work_order_id=entry_data.work_order_id,
        job_card_id=entry_data.job_card_id,
        entry_date=datetime.combine(entry_data.entry_date, datetime.max.time()).replace(tzinfo=timezone.utc),
        entry_type=entry_data.entry_type,
        finished_qty=entry_data.finished_qty,
        rejected_qty=entry_data.rejected_qty,
        scrap_qty=entry_data.scrap_qty,
        batch_number=batch_number,
        batch_id=batch_id,
        recorded_by=current_user.id,
        created_by=current_user.id,
    )
    db.add(entry)
    
    # Update work order produced qty
    wo_obj.produced_qty = float(wo_obj.produced_qty) + entry_data.finished_qty
    wo_obj.rejected_qty = float(wo_obj.rejected_qty) + entry_data.rejected_qty
    
    if float(wo_obj.produced_qty) >= float(wo_obj.planned_qty):
        wo_obj.status = WorkOrderStatus.COMPLETED
        wo_obj.completed_by = current_user.id
        wo_obj.completed_at = datetime.now(timezone.utc)
    else:
        wo_obj.status = WorkOrderStatus.IN_PROGRESS
    
    # If finished goods produced, add to stock
    if entry_data.finished_qty > 0 and batch_id:
        # Create stock balance in FG warehouse
        balance = await db.execute(
            select(StockBalance).where(
                StockBalance.organization_id == current_user.organization_id,
                StockBalance.product_id == bom_obj.finished_product_id,
                StockBalance.warehouse_id == wo_obj.warehouse_id,
                StockBalance.batch_id == batch_id,
                StockBalance.stock_status == StockStatus.AVAILABLE.value
            )
        )
        balance_obj = balance.scalar_one_or_none()
        
        new_qty = entry_data.finished_qty
        if balance_obj:
            new_qty = float(balance_obj.qty) + entry_data.finished_qty
            balance_obj.qty = new_qty
            balance_obj.last_transaction_date = datetime.now(timezone.utc)
            balance_obj.last_updated = datetime.now(timezone.utc)
        else:
            balance_obj = StockBalance(
                organization_id=current_user.organization_id,
                product_id=bom_obj.finished_product_id,
                warehouse_id=wo_obj.warehouse_id,
                batch_id=batch_id,
                stock_status=StockStatus.QUARANTINED.value,  # Initially quarantined until QC
                qty=entry_data.finished_qty,
                last_transaction_date=datetime.now(timezone.utc),
            )
            db.add(balance_obj)
        
        # Create ledger entry
        ledger_entry = StockLedgerEntry(
            organization_id=current_user.organization_id,
            product_id=bom_obj.finished_product_id,
            warehouse_id=wo_obj.warehouse_id,
            batch_id=batch_id,
            transaction_type=TransactionType.PRODUCTION_RECEIPT.value,
            transaction_id=entry.id,
            transaction_number=entry_number,
            transaction_date=datetime.now(timezone.utc),
            qty_in=entry_data.finished_qty,
            balance_qty=new_qty,
            stock_status=StockStatus.QUARANTINED.value,
            reference_doctype="production_entry",
            reference_docname=entry_number,
            created_by=current_user.id,
        )
        db.add(ledger_entry)
    
    await db.commit()
    
    logger.info("production_entry_created", entry_id=str(entry.id), number=entry_number)
    
    return {"id": str(entry.id), "entry_number": entry_number, "batch_id": str(batch_id) if batch_id else None}


# Quality Check Template Endpoints
class QualityCheckParameterCreate(BaseModel):
    name: str
    parameter_type: QualityCheckParameterType
    unit: Optional[str] = None
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    target_value: Optional[float] = None
    options: Optional[List[str]] = None
    is_mandatory: bool = True


class QualityCheckTemplateCreate(BaseModel):
    code: str
    name: str
    description: Optional[str] = None
    applies_to: str  # raw_material, in_process, finished_good
    parameters: List[QualityCheckParameterCreate]


@router.post("/quality-templates", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_quality_template(
    template_data: QualityCheckTemplateCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("qc:create")),
):
    existing = await db.execute(
        select(QualityCheckTemplate).where(
            QualityCheckTemplate.organization_id == current_user.organization_id,
            QualityCheckTemplate.code == template_data.code
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Template code already exists")
    
    template = QualityCheckTemplate(
        organization_id=current_user.organization_id,
        code=template_data.code,
        name=template_data.name,
        description=template_data.description,
        applies_to=template_data.applies_to,
    )
    db.add(template)
    await db.flush()
    
    for idx, param_data in enumerate(template_data.parameters):
        param = QualityCheckParameter(
            template_id=template.id,
            name=param_data.name,
            parameter_type=param_data.parameter_type,
            unit=param_data.unit,
            min_value=param_data.min_value,
            max_value=param_data.max_value,
            target_value=param_data.target_value,
            options=param_data.options or [],
            is_mandatory=param_data.is_mandatory,
            sort_order=idx,
        )
        db.add(param)
    
    await db.commit()
    
    return {"id": str(template.id), "code": template.code, "name": template.name}


@router.get("/quality-templates", response_model=List[dict])
async def list_quality_templates(
    applies_to: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("qc:view")),
):
    query = select(QualityCheckTemplate).where(
        QualityCheckTemplate.organization_id == current_user.organization_id,
        QualityCheckTemplate.is_active == True
    )
    
    if applies_to:
        query = query.where(QualityCheckTemplate.applies_to == applies_to)
    
    result = await db.execute(query.order_by(QualityCheckTemplate.name))
    templates = result.scalars().all()
    
    return [
        {
            "id": str(t.id),
            "code": t.code,
            "name": t.name,
            "applies_to": t.applies_to,
        }
        for t in templates
    ]


# Quality Inspection Endpoints
class QualityInspectionCreate(BaseModel):
    inspection_type: str  # incoming, in_process, final
    reference_doctype: str
    reference_doc_id: UUID
    batch_id: Optional[UUID] = None
    template_id: Optional[UUID] = None


@router.post("/quality-inspections", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_quality_inspection(
    inspection_data: QualityInspectionCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("qc:create")),
):
    # Generate inspection number
    today = date.today()
    prefix = f"QI-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(QualityInspection.id)).where(
            QualityInspection.organization_id == current_user.organization_id,
            QualityInspection.inspection_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    inspection_number = f"{prefix}{seq:04d}"
    
    # Get template parameters if template provided
    template = None
    if inspection_data.template_id:
        template = await db.execute(
            select(QualityCheckTemplate).where(QualityCheckTemplate.id == inspection_data.template_id)
        )
        template = template.scalar_one_or_none()
    
    inspection = QualityInspection(
        organization_id=current_user.organization_id,
        inspection_number=inspection_number,
        inspection_type=inspection_data.inspection_type,
        reference_doctype=inspection_data.reference_doctype,
        reference_doc_id=inspection_data.reference_doc_id,
        batch_id=inspection_data.batch_id,
        template_id=inspection_data.template_id,
        status=QualityInspectionStatus.PENDING,
        inspection_date=datetime.now(timezone.utc),
        inspected_by=current_user.id,
        created_by=current_user.id,
    )
    db.add(inspection)
    await db.flush()
    
    # Create result rows for each parameter
    if template:
        params = await db.execute(
            select(QualityCheckParameter).where(QualityCheckParameter.template_id == template.id)
        )
        for param in params.scalars().all():
            result = QualityInspectionResult(
                inspection_id=inspection.id,
                parameter_id=param.id,
            )
            db.add(result)
    
    await db.commit()
    
    return {"id": str(inspection.id), "inspection_number": inspection_number, "status": inspection.status.value}


@router.post("/quality-inspections/{inspection_id}/record-result")
async def record_inspection_result(
    inspection_id: UUID,
    results: List[dict],  # [{parameter_id, value_numeric, value_text, value_boolean, value_select, notes}]
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("qc:create")),
):
    result = await db.execute(
        select(QualityInspection).where(
            QualityInspection.id == inspection_id,
            QualityInspection.organization_id == current_user.organization_id
        )
    )
    inspection = result.scalar_one_or_none()
    
    if not inspection:
        raise HTTPException(status_code=404, detail="Inspection not found")
    
    all_passed = True
    for res_data in results:
        param = await db.execute(
            select(QualityCheckParameter).where(QualityCheckParameter.id == res_data["parameter_id"])
        )
        param_obj = param.scalar_one_or_none()
        
        if not param_obj:
            continue
        
        # Determine pass/fail based on parameter type
        passed = True
        if param_obj.parameter_type == QualityCheckParameterType.NUMERIC:
            val = res_data.get("value_numeric")
            if val is not None:
                if param_obj.min_value is not None and val < float(param_obj.min_value):
                    passed = False
                if param_obj.max_value is not None and val > float(param_obj.max_value):
                    passed = False
        elif param_obj.parameter_type == QualityCheckParameterType.PASS_FAIL:
            passed = res_data.get("value_boolean", False)
        
        if not passed:
            all_passed = False
        
        # Update result
        await db.execute(
            select(QualityInspectionResult).where(
                QualityInspectionResult.inspection_id == inspection_id,
                QualityInspectionResult.parameter_id == res_data["parameter_id"]
            )
        )
        # Would update with the values
    
    inspection.status = QualityInspectionStatus.PASSED if all_passed else QualityInspectionStatus.FAILED
    inspection.overall_result = "pass" if all_passed else "fail"
    inspection.reviewed_by = current_user.id
    inspection.reviewed_at = datetime.now(timezone.utc)
    
    # Update batch quality status
    if inspection.batch_id:
        batch = await db.execute(select(Batch).where(Batch.id == inspection.batch_id))
        batch_obj = batch.scalar_one_or_none()
        if batch_obj:
            batch_obj.quality_status = "passed" if all_passed else "failed"
    
    await db.commit()
    
    return {"message": "Results recorded", "overall_result": inspection.overall_result}


# Batch Release Endpoints
class BatchReleaseCreate(BaseModel):
    batch_id: UUID
    released_qty: float
    quality_approval: bool = True
    cof_number: Optional[str] = None
    expiry_date: Optional[date] = None


@router.post("/batch-releases", response_model=dict, status_code=status.HTTP_201_CREATED)
async def release_batch(
    release_data: BatchReleaseCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("batch:release")),
):
    # Validate batch
    batch = await db.execute(
        select(Batch).where(
            Batch.id == release_data.batch_id,
            Batch.organization_id == current_user.organization_id,
            Batch.quality_status == "passed"
        )
    )
    batch_obj = batch.scalar_one_or_none()
    if not batch_obj:
        raise HTTPException(status_code=404, detail="Batch not found or not quality approved")
    
    # Generate release number
    today = date.today()
    prefix = f"BR-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(BatchRelease.id)).where(
            BatchRelease.organization_id == current_user.organization_id,
            BatchRelease.release_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    release_number = f"{prefix}{seq:04d}"
    
    release = BatchRelease(
        organization_id=current_user.organization_id,
        batch_id=release_data.batch_id,
        release_number=release_number,
        status=BatchReleaseStatus.RELEASED if release_data.quality_approval else BatchReleaseStatus.QUARANTINED,
        release_date=datetime.now(timezone.utc),
        released_by=current_user.id,
        released_qty=release_data.released_qty,
        quality_approval=release_data.quality_approval,
        cof_number=release_data.cof_number,
        expiry_date=datetime.combine(release_data.expiry_date, datetime.min.time()).replace(tzinfo=timezone.utc) if release_data.expiry_date else None,
    )
    db.add(release)
    
    # Update batch status
    batch_obj.status = "released" if release_data.quality_approval else "quarantined"
    
    # Update stock balance from quarantined to available
    if release_data.quality_approval:
        # Find quarantined balance
        quar_balance = await db.execute(
            select(StockBalance).where(
                StockBalance.organization_id == current_user.organization_id,
                StockBalance.batch_id == release_data.batch_id,
                StockBalance.stock_status == StockStatus.QUARANTINED.value
            )
        )
        quar_obj = quar_balance.scalar_one_or_none()
        
        if quar_obj:
            # Move to available
            avail_balance = await db.execute(
                select(StockBalance).where(
                    StockBalance.organization_id == current_user.organization_id,
                    StockBalance.product_id == quar_obj.product_id,
                    StockBalance.warehouse_id == quar_obj.warehouse_id,
                    StockBalance.bin_id == quar_obj.bin_id,
                    StockBalance.batch_id == release_data.batch_id,
                    StockBalance.stock_status == StockStatus.AVAILABLE.value
                )
            )
            avail_obj = avail_balance.scalar_one_or_none()
            
            new_qty = release_data.released_qty
            if avail_obj:
                new_qty = float(avail_obj.qty) + release_data.released_qty
                avail_obj.qty = new_qty
                avail_obj.last_transaction_date = datetime.now(timezone.utc)
                avail_obj.last_updated = datetime.now(timezone.utc)
            else:
                avail_obj = StockBalance(
                    organization_id=current_user.organization_id,
                    product_id=quar_obj.product_id,
                    warehouse_id=quar_obj.warehouse_id,
                    bin_id=quar_obj.bin_id,
                    batch_id=release_data.batch_id,
                    stock_status=StockStatus.AVAILABLE.value,
                    qty=release_data.released_qty,
                    valuation_rate=quar_obj.valuation_rate,
                    last_transaction_date=datetime.now(timezone.utc),
                )
                db.add(avail_obj)
            
            # Reduce quarantined
            quar_obj.qty = float(quar_obj.qty) - release_data.released_qty
            if quar_obj.qty <= 0:
                await db.delete(quar_obj)
            
            # Create ledger entry
            ledger_entry = StockLedgerEntry(
                organization_id=current_user.organization_id,
                product_id=quar_obj.product_id,
                warehouse_id=quar_obj.warehouse_id,
                bin_id=quar_obj.bin_id,
                batch_id=release_data.batch_id,
                transaction_type=TransactionType.PRODUCTION_RECEIPT.value,
                transaction_id=release.id,
                transaction_number=release_number,
                transaction_date=datetime.now(timezone.utc),
                qty_in=release_data.released_qty,
                balance_qty=new_qty,
                stock_status=StockStatus.AVAILABLE.value,
                reference_doctype="batch_release",
                reference_docname=release_number,
                created_by=current_user.id,
            )
            db.add(ledger_entry)
    
    await db.commit()
    
    logger.info("batch_released", batch_id=str(release_data.batch_id), release_number=release_number)
    
    return {"id": str(release.id), "release_number": release_number, "status": release.status.value}