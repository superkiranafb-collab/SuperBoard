from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
from uuid import UUID
from datetime import datetime, date, timezone
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.models import (
    Attendance, AttendanceStatus, Shift,
    LeaveApplication, LeaveType, LeaveStatus, LeaveBalance,
    Task, TaskStatus, TaskPriority,
    Approval, ApprovalStatus, ApprovalType,
    User, Organization
)
import structlog

logger = structlog.get_logger()

router = APIRouter()


# Attendance Endpoints
class AttendanceCreate(BaseModel):
    employee_id: UUID
    attendance_date: date
    status: AttendanceStatus = AttendanceStatus.PRESENT
    shift_id: Optional[UUID] = None
    check_in_time: Optional[datetime] = None
    check_out_time: Optional[datetime] = None
    check_in_latitude: Optional[float] = None
    check_in_longitude: Optional[float] = None
    check_out_latitude: Optional[float] = None
    check_out_longitude: Optional[float] = None
    is_geo_fenced: bool = False
    geo_fence_passed: Optional[bool] = None
    notes: Optional[str] = None


@router.post("/attendance", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_attendance(
    attendance_data: AttendanceCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("attendance:create")),
):
    # Check if already exists
    existing = await db.execute(
        select(Attendance).where(
            Attendance.organization_id == current_user.organization_id,
            Attendance.employee_id == attendance_data.employee_id,
            Attendance.attendance_date == attendance_data.attendance_date
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Attendance already recorded for this date")
    
    # Validate employee
    employee = await db.execute(
        select(User).where(
            User.id == attendance_data.employee_id,
            User.organization_id == current_user.organization_id
        )
    )
    if not employee.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Employee not found")
    
    attendance = Attendance(
        organization_id=current_user.organization_id,
        **attendance_data.model_dump(),
        created_by=current_user.id,
    )
    db.add(attendance)
    await db.commit()
    
    return {"id": str(attendance.id), "message": "Attendance recorded"}


@router.post("/attendance/check-in")
async def check_in(
    employee_id: UUID,
    latitude: Optional[float] = None,
    longitude: Optional[float] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("attendance:create")),
):
    today = date.today()
    
    # Get or create attendance record
    attendance = await db.execute(
        select(Attendance).where(
            Attendance.organization_id == current_user.organization_id,
            Attendance.employee_id == employee_id,
            Attendance.attendance_date == today
        )
    )
    attendance_obj = attendance.scalar_one_or_none()
    
    if not attendance_obj:
        attendance_obj = Attendance(
            organization_id=current_user.organization_id,
            employee_id=employee_id,
            attendance_date=today,
            status=AttendanceStatus.PRESENT,
            check_in_time=datetime.now(timezone.utc),
            check_in_latitude=latitude,
            check_in_longitude=longitude,
            is_geo_fenced=latitude is not None and longitude is not None,
            created_by=current_user.id,
        )
        db.add(attendance_obj)
    else:
        if attendance_obj.check_in_time:
            raise HTTPException(status_code=400, detail="Already checked in")
        
        attendance_obj.check_in_time = datetime.now(timezone.utc)
        attendance_obj.check_in_latitude = latitude
        attendance_obj.check_in_longitude = longitude
        attendance_obj.is_geo_fenced = latitude is not None and longitude is not None
        attendance_obj.status = AttendanceStatus.PRESENT
    
    await db.commit()
    
    return {"message": "Checked in successfully", "check_in_time": attendance_obj.check_in_time.isoformat()}


@router.post("/attendance/check-out")
async def check_out(
    employee_id: UUID,
    latitude: Optional[float] = None,
    longitude: Optional[float] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("attendance:create")),
):
    today = date.today()
    
    attendance = await db.execute(
        select(Attendance).where(
            Attendance.organization_id == current_user.organization_id,
            Attendance.employee_id == employee_id,
            Attendance.attendance_date == today
        )
    )
    attendance_obj = attendance.scalar_one_or_none()
    
    if not attendance_obj:
        raise HTTPException(status_code=404, detail="No check-in found for today")
    
    if not attendance_obj.check_in_time:
        raise HTTPException(status_code=400, detail="Not checked in yet")
    
    if attendance_obj.check_out_time:
        raise HTTPException(status_code=400, detail="Already checked out")
    
    attendance_obj.check_out_time = datetime.now(timezone.utc)
    attendance_obj.check_out_latitude = latitude
    attendance_obj.check_out_longitude = longitude
    
    # Calculate work hours
    if attendance_obj.check_in_time:
        diff = attendance_obj.check_out_time - attendance_obj.check_in_time
        attendance_obj.work_hours = round(diff.total_seconds() / 3600, 2)
    
    await db.commit()
    
    return {"message": "Checked out successfully", "work_hours": attendance_obj.work_hours}


@router.get("/attendance", response_model=List[dict])
async def list_attendance(
    employee_id: Optional[UUID] = None,
    from_date: Optional[date] = None,
    to_date: Optional[date] = None,
    status: Optional[AttendanceStatus] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("attendance:view")),
):
    query = select(Attendance).where(Attendance.organization_id == current_user.organization_id)
    
    # If not manager, only show own attendance
    if "hr_manager" not in current_user.roles and "department_head" not in current_user.roles:
        query = query.where(Attendance.employee_id == current_user.id)
    elif employee_id:
        query = query.where(Attendance.employee_id == employee_id)
    
    if from_date:
        query = query.where(Attendance.attendance_date >= from_date)
    if to_date:
        query = query.where(Attendance.attendance_date <= to_date)
    if status:
        query = query.where(Attendance.status == status)
    
    query = query.order_by(Attendance.attendance_date.desc()).limit(100)
    result = await db.execute(query)
    records = result.scalars().all()
    
    return [
        {
            "id": str(r.id),
            "employee_id": str(r.employee_id),
            "attendance_date": r.attendance_date.isoformat(),
            "status": r.status.value,
            "check_in_time": r.check_in_time.isoformat() if r.check_in_time else None,
            "check_out_time": r.check_out_time.isoformat() if r.check_out_time else None,
            "work_hours": float(r.work_hours) if r.work_hours else 0,
        }
        for r in records
    ]


# Shift Endpoints
class ShiftCreate(BaseModel):
    code: str
    name: str
    start_time: str  # HH:MM
    end_time: str  # HH:MM
    grace_period_minutes: int = 15
    max_late_minutes: int = 30
    work_hours: float = 8
    is_night_shift: bool = False
    applicable_days: List[int] = [0, 1, 2, 3, 4]  # Mon-Fri


@router.post("/shifts", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_shift(
    shift_data: ShiftCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("hr:view")),
):
    existing = await db.execute(
        select(Shift).where(
            Shift.organization_id == current_user.organization_id,
            Shift.code == shift_data.code
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Shift code already exists")
    
    shift = Shift(
        organization_id=current_user.organization_id,
        **shift_data.model_dump(),
    )
    db.add(shift)
    await db.commit()
    await db.refresh(shift)
    
    return {"id": str(shift.id), "code": shift.code, "name": shift.name}


@router.get("/shifts", response_model=List[dict])
async def list_shifts(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("hr:view")),
):
    result = await db.execute(
        select(Shift).where(
            Shift.organization_id == current_user.organization_id,
            Shift.is_active == True
        ).order_by(Shift.code)
    )
    return [
        {
            "id": str(s.id),
            "code": s.code,
            "name": s.name,
            "start_time": s.start_time,
            "end_time": s.end_time,
            "work_hours": float(s.work_hours),
        }
        for s in result.scalars().all()
    ]


# Leave Endpoints
class LeaveApplicationCreate(BaseModel):
    employee_id: UUID
    leave_type: LeaveType
    from_date: date
    to_date: date
    reason: str


@router.post("/leave-applications", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_leave_application(
    leave_data: LeaveApplicationCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("leave:create")),
):
    # Validate employee
    employee = await db.execute(
        select(User).where(
            User.id == leave_data.employee_id,
            User.organization_id == current_user.organization_id
        )
    )
    emp = employee.scalar_one_or_none()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    
    # Calculate days
    delta = leave_data.to_date - leave_data.from_date
    total_days = delta.days + 1
    
    # Check leave balance
    fy_start = date(leave_data.from_date.year, 4, 1)
    if leave_data.from_date < fy_start:
        fy_start = date(leave_data.from_date.year - 1, 4, 1)
    financial_year = f"{fy_start.year}-{fy_start.year + 1}"
    
    balance = await db.execute(
        select(LeaveBalance).where(
            LeaveBalance.organization_id == current_user.organization_id,
            LeaveBalance.employee_id == leave_data.employee_id,
            LeaveBalance.leave_type == leave_data.leave_type,
            LeaveBalance.financial_year == financial_year
        )
    )
    balance_obj = balance.scalar_one_or_none()
    
    if balance_obj and float(balance_obj.current_balance) < total_days:
        raise HTTPException(status_code=400, detail="Insufficient leave balance")
    
    # Generate application number
    today = date.today()
    prefix = f"LA-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(LeaveApplication.id)).where(
            LeaveApplication.organization_id == current_user.organization_id,
            LeaveApplication.application_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    application_number = f"{prefix}{seq:04d}"
    
    leave = LeaveApplication(
        organization_id=current_user.organization_id,
        application_number=application_number,
        employee_id=leave_data.employee_id,
        leave_type=leave_data.leave_type,
        status=LeaveStatus.PENDING,
        from_date=leave_data.from_date,
        to_date=leave_data.to_date,
        total_days=total_days,
        reason=leave_data.reason,
        created_by=current_user.id,
    )
    db.add(leave)
    await db.commit()
    
    return {"id": str(leave.id), "application_number": application_number, "status": leave.status.value}


@router.get("/leave-applications", response_model=List[dict])
async def list_leave_applications(
    employee_id: Optional[UUID] = None,
    status: Optional[LeaveStatus] = None,
    leave_type: Optional[LeaveType] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("leave:view")),
):
    query = select(LeaveApplication).where(LeaveApplication.organization_id == current_user.organization_id)
    
    if "hr_manager" not in current_user.roles and "department_head" not in current_user.roles:
        query = query.where(LeaveApplication.employee_id == current_user.id)
    elif employee_id:
        query = query.where(LeaveApplication.employee_id == employee_id)
    
    if status:
        query = query.where(LeaveApplication.status == status)
    if leave_type:
        query = query.where(LeaveApplication.leave_type == leave_type)
    
    query = query.order_by(LeaveApplication.created_at.desc()).limit(100)
    result = await db.execute(query)
    leaves = result.scalars().all()
    
    return [
        {
            "id": str(l.id),
            "application_number": l.application_number,
            "employee_id": str(l.employee_id),
            "leave_type": l.leave_type.value,
            "status": l.status.value,
            "from_date": l.from_date.isoformat(),
            "to_date": l.to_date.isoformat(),
            "total_days": float(l.total_days),
        }
        for l in leaves
    ]


@router.post("/leave-applications/{leave_id}/approve")
async def approve_leave(
    leave_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("leave:approve")),
):
    result = await db.execute(
        select(LeaveApplication).where(
            LeaveApplication.id == leave_id,
            LeaveApplication.organization_id == current_user.organization_id
        )
    )
    leave = result.scalar_one_or_none()
    
    if not leave:
        raise HTTPException(status_code=404, detail="Leave application not found")
    
    if leave.status != LeaveStatus.PENDING:
        raise HTTPException(status_code=400, detail="Leave not in pending status")
    
    leave.status = LeaveStatus.APPROVED
    leave.approved_by = current_user.id
    leave.approved_at = datetime.now(timezone.utc)
    
    # Deduct from balance
    fy_start = date(leave.from_date.year, 4, 1)
    if leave.from_date < fy_start:
        fy_start = date(leave.from_date.year - 1, 4, 1)
    financial_year = f"{fy_start.year}-{fy_start.year + 1}"
    
    balance = await db.execute(
        select(LeaveBalance).where(
            LeaveBalance.organization_id == current_user.organization_id,
            LeaveBalance.employee_id == leave.employee_id,
            LeaveBalance.leave_type == leave.leave_type,
            LeaveBalance.financial_year == financial_year
        )
    )
    balance_obj = balance.scalar_one_or_none()
    if balance_obj:
        balance_obj.used = float(balance_obj.used) + float(leave.total_days)
        balance_obj.current_balance = float(balance_obj.current_balance) - float(leave.total_days)
    
    await db.commit()
    
    return {"message": "Leave approved", "status": leave.status.value}


# Leave Balance
@router.get("/leave-balances", response_model=List[dict])
async def get_leave_balances(
    employee_id: Optional[UUID] = None,
    financial_year: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("hr:view")),
):
    query = select(LeaveBalance).where(LeaveBalance.organization_id == current_user.organization_id)
    
    if "hr_manager" not in current_user.roles and "department_head" not in current_user.roles:
        query = query.where(LeaveBalance.employee_id == current_user.id)
    elif employee_id:
        query = query.where(LeaveBalance.employee_id == employee_id)
    
    if financial_year:
        query = query.where(LeaveBalance.financial_year == financial_year)
    
    result = await db.execute(query)
    balances = result.scalars().all()
    
    return [
        {
            "id": str(b.id),
            "employee_id": str(b.employee_id),
            "leave_type": b.leave_type.value,
            "financial_year": b.financial_year,
            "opening_balance": float(b.opening_balance),
            "accrued": float(b.accrued),
            "used": float(b.used),
            "current_balance": float(b.current_balance),
        }
        for b in balances
    ]


# Task Endpoints
class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    assignee_id: UUID
    priority: TaskPriority = TaskPriority.MEDIUM
    due_date: Optional[datetime] = None
    estimated_hours: Optional[float] = None
    related_doctype: Optional[str] = None
    related_doc_id: Optional[UUID] = None
    tags: List[str] = []


@router.post("/tasks", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_task(
    task_data: TaskCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("hr:view")),
):
    # Validate assignee
    assignee = await db.execute(
        select(User).where(
            User.id == task_data.assignee_id,
            User.organization_id == current_user.organization_id
        )
    )
    if not assignee.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Assignee not found")
    
    today = date.today()
    prefix = f"TASK-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(Task.id)).where(
            Task.organization_id == current_user.organization_id,
            Task.task_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    task_number = f"{prefix}{seq:04d}"
    
    task = Task(
        organization_id=current_user.organization_id,
        task_number=task_number,
        title=task_data.title,
        description=task_data.description,
        status=TaskStatus.TODO,
        priority=task_data.priority,
        assignee_id=task_data.assignee_id,
        assigner_id=current_user.id,
        due_date=task_data.due_date,
        estimated_hours=task_data.estimated_hours,
        related_doctype=task_data.related_doctype,
        related_doc_id=task_data.related_doc_id,
        tags=task_data.tags,
        created_by=current_user.id,
    )
    db.add(task)
    await db.commit()
    
    return {"id": str(task.id), "task_number": task_number, "status": task.status.value}


@router.get("/tasks", response_model=List[dict])
async def list_tasks(
    assignee_id: Optional[UUID] = None,
    status: Optional[TaskStatus] = None,
    priority: Optional[TaskPriority] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("hr:view")),
):
    query = select(Task).where(Task.organization_id == current_user.organization_id)
    
    if "hr_manager" not in current_user.roles and "department_head" not in current_user.roles:
        query = query.where(Task.assignee_id == current_user.id)
    elif assignee_id:
        query = query.where(Task.assignee_id == assignee_id)
    
    if status:
        query = query.where(Task.status == status)
    if priority:
        query = query.where(Task.priority == priority)
    
    query = query.order_by(Task.created_at.desc()).limit(100)
    result = await db.execute(query)
    tasks = result.scalars().all()
    
    return [
        {
            "id": str(t.id),
            "task_number": t.task_number,
            "title": t.title,
            "status": t.status.value,
            "priority": t.priority.value,
            "assignee_id": str(t.assignee_id),
            "due_date": t.due_date.isoformat() if t.due_date else None,
        }
        for t in tasks
    ]


@router.post("/tasks/{task_id}/complete")
async def complete_task(
    task_id: UUID,
    actual_hours: Optional[float] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("hr:view")),
):
    result = await db.execute(
        select(Task).where(
            Task.id == task_id,
            Task.organization_id == current_user.organization_id
        )
    )
    task = result.scalar_one_or_none()
    
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    if task.assignee_id != current_user.id and "hr_manager" not in current_user.roles:
        raise HTTPException(status_code=403, detail="Not authorized to complete this task")
    
    task.status = TaskStatus.COMPLETED
    task.completed_at = datetime.now(timezone.utc)
    if actual_hours:
        task.actual_hours = actual_hours
    
    await db.commit()
    
    return {"message": "Task completed", "status": task.status.value}