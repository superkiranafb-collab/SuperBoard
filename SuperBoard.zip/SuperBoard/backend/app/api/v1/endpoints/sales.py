from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from uuid import UUID
from datetime import datetime, date, timezone
from decimal import Decimal
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.models import (
    SalesQuotation, QuotationStatus, SalesQuotationItem,
    SalesOrder, SalesOrderStatus, SalesOrderItem,
    DeliveryNote, DeliveryNoteStatus, DeliveryNoteItem,
    SalesInvoice, SalesInvoiceStatus, SalesInvoiceItem,
    Payment, PaymentMode, PaymentStatus,
    Customer, CustomerAddress, Product, Warehouse, User, PriceList, UOM,
    Organization, Batch, Bin, StockBalance, StockStatus, StockLedgerEntry, TransactionType
)
import structlog

logger = structlog.get_logger()

router = APIRouter()


class SalesQuotationItemCreate(BaseModel):
    product_id: UUID
    description: Optional[str] = None
    qty: float
    uom_id: UUID
    rate: float
    discount_percent: float = 0
    tax_rate: float = 0


class SalesQuotationCreate(BaseModel):
    customer_id: UUID
    customer_address_id: Optional[UUID] = None
    valid_till: date
    price_list_id: Optional[UUID] = None
    currency: str = "INR"
    terms_conditions: Optional[str] = None
    notes: Optional[str] = None
    items: List[SalesQuotationItemCreate]


class SalesQuotationResponse(BaseModel):
    id: UUID
    quotation_number: str
    customer_id: UUID
    customer_name: str
    status: QuotationStatus
    quotation_date: datetime
    valid_till: datetime
    total_amount: float
    created_at: datetime
    
    class Config:
        from_attributes = True


@router.post("/quotations", response_model=SalesQuotationResponse, status_code=status.HTTP_201_CREATED)
async def create_quotation(
    quotation_data: SalesQuotationCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("sales_quotation:create")),
):
    # Validate customer
    customer = await db.execute(
        select(Customer).where(
            Customer.id == quotation_data.customer_id,
            Customer.organization_id == current_user.organization_id
        )
    )
    customer_obj = customer.scalar_one_or_none()
    if not customer_obj:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    # Generate quotation number
    today = date.today()
    prefix = f"SQ-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(SalesQuotation.id)).where(
            SalesQuotation.organization_id == current_user.organization_id,
            SalesQuotation.quotation_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    quotation_number = f"{prefix}{seq:04d}"
    
    # Calculate totals
    subtotal = 0
    discount_amount = 0
    tax_amount = 0
    
    for item in quotation_data.items:
        item_subtotal = item.qty * item.rate
        item_discount = item_subtotal * (item.discount_percent / 100)
        item_taxable = item_subtotal - item_discount
        item_tax = item_taxable * (item.tax_rate / 100)
        
        subtotal += item_subtotal
        discount_amount += item_discount
        tax_amount += item_tax
    
    total_amount = subtotal - discount_amount + tax_amount
    
    quotation = SalesQuotation(
        organization_id=current_user.organization_id,
        quotation_number=quotation_number,
        customer_id=quotation_data.customer_id,
        customer_address_id=quotation_data.customer_address_id,
        status=QuotationStatus.DRAFT,
        quotation_date=datetime.now(timezone.utc),
        valid_till=datetime.combine(quotation_data.valid_till, datetime.max.time()).replace(tzinfo=timezone.utc),
        price_list_id=quotation_data.price_list_id,
        currency=quotation_data.currency,
        subtotal=subtotal,
        discount_amount=discount_amount,
        tax_amount=tax_amount,
        total_amount=total_amount,
        terms_conditions=quotation_data.terms_conditions,
        notes=quotation_data.notes,
        prepared_by=current_user.id,
        created_by=current_user.id,
    )
    db.add(quotation)
    await db.flush()
    
    for idx, item_data in enumerate(quotation_data.items):
        item_subtotal = item_data.qty * item_data.rate
        item_discount = item_subtotal * (item_data.discount_percent / 100)
        item_taxable = item_subtotal - item_discount
        item_tax = item_taxable * (item_data.tax_rate / 100)
        item_amount = item_taxable + item_tax
        
        item = SalesQuotationItem(
            quotation_id=quotation.id,
            product_id=item_data.product_id,
            description=item_data.description,
            qty=item_data.qty,
            uom_id=item_data.uom_id,
            rate=item_data.rate,
            discount_percent=item_data.discount_percent,
            discount_amount=item_discount,
            tax_rate=item_data.tax_rate,
            tax_amount=item_tax,
            amount=item_amount,
            sort_order=idx,
        )
        db.add(item)
    
    await db.commit()
    await db.refresh(quotation)
    
    logger.info("quotation_created", quotation_id=str(quotation.id), number=quotation_number)
    
    return SalesQuotationResponse(
        id=quotation.id,
        quotation_number=quotation.quotation_number,
        customer_id=quotation.customer_id,
        customer_name=customer_obj.name,
        status=quotation.status,
        quotation_date=quotation.quotation_date,
        valid_till=quotation.valid_till,
        total_amount=float(quotation.total_amount),
        created_at=quotation.created_at,
    )


@router.get("/quotations", response_model=List[SalesQuotationResponse])
async def list_quotations(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[QuotationStatus] = None,
    customer_id: Optional[UUID] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("sales_quotation:view")),
):
    query = select(SalesQuotation).where(SalesQuotation.organization_id == current_user.organization_id)
    
    if status:
        query = query.where(SalesQuotation.status == status)
    if customer_id:
        query = query.where(SalesQuotation.customer_id == customer_id)
    
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(SalesQuotation.created_at.desc())
    result = await db.execute(query)
    quotations = result.scalars().all()
    
    # Enrich with customer names
    response = []
    for q in quotations:
        customer = await db.execute(select(Customer).where(Customer.id == q.customer_id))
        cust = customer.scalar_one_or_none()
        response.append(SalesQuotationResponse(
            id=q.id,
            quotation_number=q.quotation_number,
            customer_id=q.customer_id,
            customer_name=cust.name if cust else "",
            status=q.status,
            quotation_date=q.quotation_date,
            valid_till=q.valid_till,
            total_amount=float(q.total_amount),
            created_at=q.created_at,
        ))
    
    return response


class SalesOrderItemCreate(BaseModel):
    product_id: UUID
    description: Optional[str] = None
    qty: float
    uom_id: UUID
    rate: float
    discount_percent: float = 0
    tax_rate: float = 0


class SalesOrderCreate(BaseModel):
    customer_id: UUID
    customer_address_id: Optional[UUID] = None
    quotation_id: Optional[UUID] = None
    delivery_date: Optional[date] = None
    warehouse_id: Optional[UUID] = None
    price_list_id: Optional[UUID] = None
    salesperson_id: Optional[UUID] = None
    currency: str = "INR"
    terms_conditions: Optional[str] = None
    notes: Optional[str] = None
    items: List[SalesOrderItemCreate]


class SalesOrderResponse(BaseModel):
    id: UUID
    order_number: str
    customer_id: UUID
    customer_name: str
    status: SalesOrderStatus
    order_date: datetime
    delivery_date: Optional[datetime]
    total_amount: float
    created_at: datetime
    
    class Config:
        from_attributes = True


@router.post("/orders", response_model=SalesOrderResponse, status_code=status.HTTP_201_CREATED)
async def create_sales_order(
    order_data: SalesOrderCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("sales_order:create")),
):
    # Validate customer
    customer = await db.execute(
        select(Customer).where(
            Customer.id == order_data.customer_id,
            Customer.organization_id == current_user.organization_id
        )
    )
    customer_obj = customer.scalar_one_or_none()
    if not customer_obj:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    if customer_obj.is_blocked:
        raise HTTPException(status_code=400, detail="Customer is blocked")
    
    # Validate warehouse
    warehouse_id = order_data.warehouse_id or customer_obj.assigned_warehouse_id
    if warehouse_id:
        warehouse = await db.execute(
            select(Warehouse).where(
                Warehouse.id == warehouse_id,
                Warehouse.organization_id == current_user.organization_id
            )
        )
        if not warehouse.scalar_one_or_none():
            raise HTTPException(status_code=404, detail="Warehouse not found")
    
    # Generate order number
    today = date.today()
    prefix = f"SO-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(SalesOrder.id)).where(
            SalesOrder.organization_id == current_user.organization_id,
            SalesOrder.order_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    order_number = f"{prefix}{seq:04d}"
    
    # Calculate totals
    subtotal = 0
    discount_amount = 0
    tax_amount = 0
    
    for item in order_data.items:
        item_subtotal = item.qty * item.rate
        item_discount = item_subtotal * (item.discount_percent / 100)
        item_taxable = item_subtotal - item_discount
        item_tax = item_taxable * (item.tax_rate / 100)
        
        subtotal += item_subtotal
        discount_amount += item_discount
        tax_amount += item_tax
    
    total_amount = subtotal - discount_amount + tax_amount
    
    # Determine initial status
    initial_status = SalesOrderStatus.DRAFT
    if total_amount > customer_obj.credit_limit and customer_obj.credit_limit > 0:
        initial_status = SalesOrderStatus.PENDING_APPROVAL
    
    order = SalesOrder(
        organization_id=current_user.organization_id,
        order_number=order_number,
        customer_id=order_data.customer_id,
        customer_address_id=order_data.customer_address_id,
        quotation_id=order_data.quotation_id,
        status=initial_status,
        order_date=datetime.now(timezone.utc),
        delivery_date=datetime.combine(order_data.delivery_date, datetime.max.time()).replace(tzinfo=timezone.utc) if order_data.delivery_date else None,
        warehouse_id=warehouse_id,
        price_list_id=order_data.price_list_id,
        salesperson_id=order_data.salesperson_id or customer_obj.assigned_salesperson_id,
        currency=order_data.currency,
        subtotal=subtotal,
        discount_amount=discount_amount,
        tax_amount=tax_amount,
        total_amount=total_amount,
        terms_conditions=order_data.terms_conditions,
        notes=order_data.notes,
        credit_check_passed=initial_status != SalesOrderStatus.PENDING_APPROVAL,
        created_by=current_user.id,
    )
    db.add(order)
    await db.flush()
    
    for idx, item_data in enumerate(order_data.items):
        item_subtotal = item_data.qty * item_data.rate
        item_discount = item_subtotal * (item_data.discount_percent / 100)
        item_taxable = item_subtotal - item_discount
        item_tax = item_taxable * (item_data.tax_rate / 100)
        item_amount = item_taxable + item_tax
        
        item = SalesOrderItem(
            order_id=order.id,
            product_id=item_data.product_id,
            description=item_data.description,
            qty=item_data.qty,
            uom_id=item_data.uom_id,
            rate=item_data.rate,
            discount_percent=item_data.discount_percent,
            discount_amount=item_discount,
            tax_rate=item_data.tax_rate,
            tax_amount=item_tax,
            amount=item_amount,
            sort_order=idx,
        )
        db.add(item)
    
    # Update quotation status if linked
    if order_data.quotation_id:
        quotation = await db.execute(
            select(SalesQuotation).where(SalesQuotation.id == order_data.quotation_id)
        )
        q = quotation.scalar_one_or_none()
        if q:
            q.status = QuotationStatus.CONVERTED
    
    await db.commit()
    await db.refresh(order)
    
    logger.info("sales_order_created", order_id=str(order.id), number=order_number)
    
    return SalesOrderResponse(
        id=order.id,
        order_number=order.order_number,
        customer_id=order.customer_id,
        customer_name=customer_obj.name,
        status=order.status,
        order_date=order.order_date,
        delivery_date=order.delivery_date,
        total_amount=float(order.total_amount),
        created_at=order.created_at,
    )


@router.get("/orders", response_model=List[SalesOrderResponse])
async def list_sales_orders(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[SalesOrderStatus] = None,
    customer_id: Optional[UUID] = None,
    salesperson_id: Optional[UUID] = None,
    warehouse_id: Optional[UUID] = None,
    from_date: Optional[date] = None,
    to_date: Optional[date] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("sales_order:view")),
):
    query = select(SalesOrder).where(SalesOrder.organization_id == current_user.organization_id)
    
    if status:
        query = query.where(SalesOrder.status == status)
    if customer_id:
        query = query.where(SalesOrder.customer_id == customer_id)
    if salesperson_id:
        query = query.where(SalesOrder.salesperson_id == salesperson_id)
    if warehouse_id:
        query = query.where(SalesOrder.warehouse_id == warehouse_id)
    if from_date:
        query = query.where(SalesOrder.order_date >= from_date)
    if to_date:
        query = query.where(SalesOrder.order_date <= to_date)
    
    # Apply user's warehouse access
    if current_user.assigned_warehouse_ids and not current_user.is_superuser:
        query = query.where(SalesOrder.warehouse_id.in_(current_user.assigned_warehouse_ids))
    
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(SalesOrder.created_at.desc())
    result = await db.execute(query)
    orders = result.scalars().all()
    
    response = []
    for o in orders:
        customer = await db.execute(select(Customer).where(Customer.id == o.customer_id))
        cust = customer.scalar_one_or_none()
        response.append(SalesOrderResponse(
            id=o.id,
            order_number=o.order_number,
            customer_id=o.customer_id,
            customer_name=cust.name if cust else "",
            status=o.status,
            order_date=o.order_date,
            delivery_date=o.delivery_date,
            total_amount=float(o.total_amount),
            created_at=o.created_at,
        ))
    
    return response


@router.get("/orders/{order_id}")
async def get_sales_order(
    order_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("sales_order:view")),
):
    result = await db.execute(
        select(SalesOrder).options(
            selectinload(SalesOrder.items).selectinload(SalesOrderItem.product),
            selectinload(SalesOrder.items).selectinload(SalesOrderItem.uom),
        ).where(
            SalesOrder.id == order_id,
            SalesOrder.organization_id == current_user.organization_id
        )
    )
    order = result.scalar_one_or_none()
    
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    customer = await db.execute(select(Customer).where(Customer.id == order.customer_id))
    customer_obj = customer.scalar_one_or_none()
    
    warehouse = None
    if order.warehouse_id:
        wh = await db.execute(select(Warehouse).where(Warehouse.id == order.warehouse_id))
        warehouse = wh.scalar_one_or_none()
    
    items = []
    for item in order.items:
        product = await db.execute(select(Product).where(Product.id == item.product_id))
        product_obj = product.scalar_one_or_none()
        
        uom = await db.execute(select(UOM).where(UOM.id == item.uom_id))
        uom_obj = uom.scalar_one_or_none()
        
        items.append({
            "id": str(item.id),
            "product_id": str(item.product_id),
            "product_code": product_obj.code if product_obj else "",
            "product_name": product_obj.name if product_obj else "",
            "description": item.description,
            "qty": float(item.qty),
            "uom_id": str(item.uom_id),
            "uom_code": uom_obj.code if uom_obj else "",
            "rate": float(item.rate),
            "discount_percent": float(item.discount_percent),
            "discount_amount": float(item.discount_amount),
            "tax_rate": float(item.tax_rate),
            "tax_amount": float(item.tax_amount),
            "amount": float(item.amount),
            "delivered_qty": float(item.delivered_qty),
            "invoiced_qty": float(item.invoiced_qty),
        })
    
    return {
        "id": str(order.id),
        "order_number": order.order_number,
        "customer_id": str(order.customer_id),
        "customer_name": customer_obj.name if customer_obj else "",
        "customer_address_id": str(order.customer_address_id) if order.customer_address_id else None,
        "quotation_id": str(order.quotation_id) if order.quotation_id else None,
        "status": order.status.value,
        "order_date": order.order_date.isoformat(),
        "delivery_date": order.delivery_date.isoformat() if order.delivery_date else None,
        "warehouse_id": str(order.warehouse_id) if order.warehouse_id else None,
        "warehouse_name": warehouse.name if warehouse else None,
        "salesperson_id": str(order.salesperson_id) if order.salesperson_id else None,
        "currency": order.currency,
        "subtotal": float(order.subtotal),
        "discount_amount": float(order.discount_amount),
        "tax_amount": float(order.tax_amount),
        "total_amount": float(order.total_amount),
        "advance_paid": float(order.advance_paid),
        "credit_check_passed": order.credit_check_passed,
        "stock_check_passed": order.stock_check_passed,
        "terms_conditions": order.terms_conditions,
        "notes": order.notes,
        "items": items,
        "created_at": order.created_at.isoformat(),
        "updated_at": order.updated_at.isoformat(),
    }


@router.post("/orders/{order_id}/approve")
async def approve_sales_order(
    order_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("sales_order:approve")),
):
    result = await db.execute(
        select(SalesOrder).where(
            SalesOrder.id == order_id,
            SalesOrder.organization_id == current_user.organization_id
        )
    )
    order = result.scalar_one_or_none()
    
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    if order.status not in [SalesOrderStatus.DRAFT, SalesOrderStatus.PENDING_APPROVAL]:
        raise HTTPException(status_code=400, detail="Order cannot be approved in current status")
    
    # Check stock availability
    items_result = await db.execute(
        select(SalesOrderItem).where(SalesOrderItem.order_id == order_id)
    )
    items = items_result.scalars().all()
    
    warehouse_id = order.warehouse_id
    if not warehouse_id:
        raise HTTPException(status_code=400, detail="No warehouse assigned to order")
    
    stock_check_passed = True
    for item in items:
        balance = await db.execute(
            select(StockBalance).where(
                StockBalance.organization_id == current_user.organization_id,
                StockBalance.product_id == item.product_id,
                StockBalance.warehouse_id == warehouse_id,
                StockBalance.batch_id == None,
                StockBalance.stock_status == StockStatus.AVAILABLE.value
            )
        )
        balance_obj = balance.scalar_one_or_none()
        
        available_qty = float(balance_obj.qty) if balance_obj else 0
        pending_qty = float(item.qty) - float(item.delivered_qty)
        
        if available_qty < pending_qty:
            stock_check_passed = False
            break
    
    order.status = SalesOrderStatus.APPROVED
    order.stock_check_passed = stock_check_passed
    order.approved_by = current_user.id
    order.approved_at = datetime.now(timezone.utc)
    
    # If stock check passed, reserve stock
    if stock_check_passed:
        for item in items:
            pending_qty = float(item.qty) - float(item.delivered_qty)
            if pending_qty > 0:
                # Create reservation
                from app.models.inventory import StockReservation
                reservation = StockReservation(
                    organization_id=current_user.organization_id,
                    product_id=item.product_id,
                    warehouse_id=warehouse_id,
                    qty=pending_qty,
                    reference_doctype="sales_order",
                    reference_docname=order.order_number,
                    reference_doc_id=order.id,
                )
                db.add(reservation)
    
    await db.commit()
    
    logger.info("sales_order_approved", order_id=str(order.id), approved_by=str(current_user.id))
    
    return {"message": "Order approved", "stock_check_passed": stock_check_passed}


class DeliveryNoteCreate(BaseModel):
    sales_order_id: Optional[UUID] = None
    customer_id: UUID
    customer_address_id: Optional[UUID] = None
    warehouse_id: UUID
    delivery_date: date
    vehicle_number: Optional[str] = None
    driver_name: Optional[str] = None
    driver_phone: Optional[str] = None
    ewaybill_number: Optional[str] = None
    notes: Optional[str] = None
    items: List[dict]  # [{sales_order_item_id, product_id, batch_id, bin_id, qty, uom_id, rate}]


@router.post("/delivery-notes", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_delivery_note(
    dn_data: DeliveryNoteCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:create")),
):
    # Validate customer
    customer = await db.execute(
        select(Customer).where(
            Customer.id == dn_data.customer_id,
            Customer.organization_id == current_user.organization_id
        )
    )
    if not customer.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Customer not found")
    
    # Validate warehouse
    warehouse = await db.execute(
        select(Warehouse).where(
            Warehouse.id == dn_data.warehouse_id,
            Warehouse.organization_id == current_user.organization_id
        )
    )
    if not warehouse.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Warehouse not found")
    
    # Generate delivery number
    today = date.today()
    prefix = f"DN-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(DeliveryNote.id)).where(
            DeliveryNote.organization_id == current_user.organization_id,
            DeliveryNote.delivery_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    delivery_number = f"{prefix}{seq:04d}"
    
    dn = DeliveryNote(
        organization_id=current_user.organization_id,
        delivery_number=delivery_number,
        sales_order_id=dn_data.sales_order_id,
        customer_id=dn_data.customer_id,
        customer_address_id=dn_data.customer_address_id,
        warehouse_id=dn_data.warehouse_id,
        status=DeliveryNoteStatus.PENDING,
        delivery_date=datetime.combine(dn_data.delivery_date, datetime.max.time()).replace(tzinfo=timezone.utc),
        vehicle_number=dn_data.vehicle_number,
        driver_name=dn_data.driver_name,
        driver_phone=dn_data.driver_phone,
        ewaybill_number=dn_data.ewaybill_number,
        notes=dn_data.notes,
        created_by=current_user.id,
    )
    db.add(dn)
    await db.flush()
    
    for item_data in dn_data.items:
        # Validate stock availability
        balance = await db.execute(
            select(StockBalance).where(
                StockBalance.organization_id == current_user.organization_id,
                StockBalance.product_id == item_data["product_id"],
                StockBalance.warehouse_id == dn_data.warehouse_id,
                StockBalance.bin_id == item_data.get("bin_id"),
                StockBalance.batch_id == item_data.get("batch_id"),
                StockBalance.stock_status == StockStatus.AVAILABLE.value
            )
        )
        balance_obj = balance.scalar_one_or_none()
        
        if not balance_obj or float(balance_obj.qty) < item_data["qty"]:
            raise HTTPException(status_code=400, detail=f"Insufficient stock for product {item_data['product_id']}")
        
        item = DeliveryNoteItem(
            delivery_note_id=dn.id,
            sales_order_item_id=item_data.get("sales_order_item_id"),
            product_id=item_data["product_id"],
            batch_id=item_data.get("batch_id"),
            bin_id=item_data.get("bin_id"),
            qty=item_data["qty"],
            uom_id=item_data["uom_id"],
            rate=item_data["rate"],
            amount=item_data["qty"] * item_data["rate"],
        )
        db.add(item)
        
        # Update sales order delivered qty
        if item_data.get("sales_order_item_id"):
            so_item = await db.execute(
                select(SalesOrderItem).where(SalesOrderItem.id == item_data["sales_order_item_id"])
            )
            so_item_obj = so_item.scalar_one_or_none()
            if so_item_obj:
                so_item_obj.delivered_qty = float(so_item_obj.delivered_qty) + item_data["qty"]
    
    await db.commit()
    
    logger.info("delivery_note_created", dn_id=str(dn.id), number=delivery_number)
    
    return {"id": str(dn.id), "delivery_number": delivery_number, "status": dn.status.value}


@router.post("/delivery-notes/{dn_id}/complete")
async def complete_delivery(
    dn_id: UUID,
    completed_data: dict,  # {delivered_by, received_by_name, signature_url, photo_url, latitude, longitude}
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:complete")),
):
    result = await db.execute(
        select(DeliveryNote).where(
            DeliveryNote.id == dn_id,
            DeliveryNote.organization_id == current_user.organization_id
        )
    )
    dn = result.scalar_one_or_none()
    
    if not dn:
        raise HTTPException(status_code=404, detail="Delivery note not found")
    
    if dn.status not in [DeliveryNoteStatus.PENDING, DeliveryNoteStatus.IN_TRANSIT]:
        raise HTTPException(status_code=400, detail="Delivery note cannot be completed in current status")
    
    # Update delivery note
    dn.status = DeliveryNoteStatus.DELIVERED
    dn.delivered_at = datetime.now(timezone.utc)
    dn.delivered_by = completed_data.get("delivered_by")
    dn.received_by_name = completed_data.get("received_by_name")
    dn.signature_url = completed_data.get("signature_url")
    dn.photo_url = completed_data.get("photo_url")
    dn.latitude = completed_data.get("latitude")
    dn.longitude = completed_data.get("longitude")
    
    # Update stock - move from available to delivered (reduce stock)
    items_result = await db.execute(
        select(DeliveryNoteItem).where(DeliveryNoteItem.delivery_note_id == dn_id)
    )
    items = items_result.scalars().all()
    
    for item in items:
        # Reduce stock balance
        balance = await db.execute(
            select(StockBalance).where(
                StockBalance.organization_id == current_user.organization_id,
                StockBalance.product_id == item.product_id,
                StockBalance.warehouse_id == dn.warehouse_id,
                StockBalance.bin_id == item.bin_id,
                StockBalance.batch_id == item.batch_id,
                StockBalance.stock_status == StockStatus.AVAILABLE.value
            )
        )
        balance_obj = balance.scalar_one_or_none()
        
        if balance_obj:
            new_qty = float(balance_obj.qty) - float(item.qty)
            balance_obj.qty = new_qty
            balance_obj.last_transaction_date = datetime.now(timezone.utc)
            balance_obj.last_updated = datetime.now(timezone.utc)
            
            # Create ledger entry
            ledger_entry = StockLedgerEntry(
                organization_id=current_user.organization_id,
                product_id=item.product_id,
                warehouse_id=dn.warehouse_id,
                bin_id=item.bin_id,
                batch_id=item.batch_id,
                transaction_type=TransactionType.SALES_INVOICE.value,  # Using this for delivery
                transaction_id=dn.id,
                transaction_number=dn.delivery_number,
                transaction_date=datetime.now(timezone.utc),
                qty_out=item.qty,
                balance_qty=new_qty,
                valuation_rate=item.rate,
                stock_status=StockStatus.AVAILABLE.value,
                reference_doctype="delivery_note",
                reference_docname=dn.delivery_number,
                created_by=current_user.id,
            )
            db.add(ledger_entry)
            
            # Release reservation if exists
            from app.models.inventory import StockReservation
            # Would need to delete reservation
    
    # Update sales order status
    if dn.sales_order_id:
        so = await db.execute(
            select(SalesOrder).where(SalesOrder.id == dn.sales_order_id)
        )
        so_obj = so.scalar_one_or_none()
        if so_obj:
            # Check if all items delivered
            so_items = await db.execute(
                select(SalesOrderItem).where(SalesOrderItem.order_id == so_obj.id)
            )
            all_delivered = all(
                float(item.delivered_qty) >= float(item.qty) 
                for item in so_items.scalars().all()
            )
            if all_delivered:
                so_obj.status = SalesOrderStatus.DELIVERED
            else:
                so_obj.status = SalesOrderStatus.PARTIALLY_FULFILLED
    
    await db.commit()
    
    logger.info("delivery_completed", dn_id=str(dn_id))
    
    return {"message": "Delivery completed", "status": dn.status.value}


class SalesInvoiceCreate(BaseModel):
    sales_order_id: Optional[UUID] = None
    delivery_note_id: Optional[UUID] = None
    customer_id: UUID
    customer_address_id: Optional[UUID] = None
    due_date: date
    currency: str = "INR"
    terms_conditions: Optional[str] = None
    notes: Optional[str] = None
    gst_type: str = "B2B"
    place_of_supply: Optional[str] = None
    reverse_charge: bool = False


@router.post("/invoices", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_sales_invoice(
    invoice_data: SalesInvoiceCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("invoice:create")),
):
    # Validate customer
    customer = await db.execute(
        select(Customer).where(
            Customer.id == invoice_data.customer_id,
            Customer.organization_id == current_user.organization_id
        )
    )
    customer_obj = customer.scalar_one_or_none()
    if not customer_obj:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    # Generate invoice number
    today = date.today()
    prefix = f"INV-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(SalesInvoice.id)).where(
            SalesInvoice.organization_id == current_user.organization_id,
            SalesInvoice.invoice_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    invoice_number = f"{prefix}{seq:04d}"
    
    # Determine source for line items
    source_items = []
    subtotal = 0
    discount_amount = 0
    tax_amount = 0
    
    if invoice_data.sales_order_id:
        so = await db.execute(
            select(SalesOrder).where(SalesOrder.id == invoice_data.sales_order_id)
        )
        so_obj = so.scalar_one_or_none()
        if so_obj:
            items_result = await db.execute(
                select(SalesOrderItem).where(SalesOrderItem.order_id == so_obj.id)
            )
            for item in items_result.scalars().all():
                pending_qty = float(item.qty) - float(item.invoiced_qty)
                if pending_qty > 0:
                    source_items.append({
                        "sales_order_item_id": str(item.id),
                        "product_id": str(item.product_id),
                        "qty": pending_qty,
                        "uom_id": str(item.uom_id),
                        "rate": float(item.rate),
                        "discount_percent": float(item.discount_percent),
                        "tax_rate": float(item.tax_rate),
                    })
    
    elif invoice_data.delivery_note_id:
        dn = await db.execute(
            select(DeliveryNote).where(DeliveryNote.id == invoice_data.delivery_note_id)
        )
        dn_obj = dn.scalar_one_or_none()
        if dn_obj:
            items_result = await db.execute(
                select(DeliveryNoteItem).where(DeliveryNoteItem.delivery_note_id == dn_obj.id)
            )
            for item in items_result.scalars().all():
                source_items.append({
                    "product_id": str(item.product_id),
                    "batch_id": str(item.batch_id) if item.batch_id else None,
                    "qty": float(item.qty),
                    "uom_id": str(item.uom_id),
                    "rate": float(item.rate),
                    "discount_percent": 0,
                    "tax_rate": float(item.tax_rate) if hasattr(item, 'tax_rate') else 0,
                })
    
    for item in source_items:
        item_subtotal = item["qty"] * item["rate"]
        item_discount = item_subtotal * (item.get("discount_percent", 0) / 100)
        item_taxable = item_subtotal - item_discount
        item_tax = item_taxable * (item.get("tax_rate", 0) / 100)
        
        subtotal += item_subtotal
        discount_amount += item_discount
        tax_amount += item_tax
    
    total_amount = subtotal - discount_amount + tax_amount
    
    invoice = SalesInvoice(
        organization_id=current_user.organization_id,
        invoice_number=invoice_number,
        sales_order_id=invoice_data.sales_order_id,
        delivery_note_id=invoice_data.delivery_note_id,
        customer_id=invoice_data.customer_id,
        customer_address_id=invoice_data.customer_address_id,
        status=SalesInvoiceStatus.DRAFT,
        invoice_date=datetime.now(timezone.utc),
        due_date=datetime.combine(invoice_data.due_date, datetime.max.time()).replace(tzinfo=timezone.utc),
        currency=invoice_data.currency,
        subtotal=subtotal,
        discount_amount=discount_amount,
        tax_amount=tax_amount,
        total_amount=total_amount,
        balance_amount=total_amount,
        gst_type=invoice_data.gst_type,
        place_of_supply=invoice_data.place_of_supply,
        reverse_charge=invoice_data.reverse_charge,
        terms_conditions=invoice_data.terms_conditions,
        notes=invoice_data.notes,
        created_by=current_user.id,
    )
    db.add(invoice)
    await db.flush()
    
    for item in source_items:
        item_subtotal = item["qty"] * item["rate"]
        item_discount = item_subtotal * (item.get("discount_percent", 0) / 100)
        item_taxable = item_subtotal - item_discount
        item_tax = item_taxable * (item.get("tax_rate", 0) / 100)
        item_amount = item_taxable + item_tax
        
        inv_item = SalesInvoiceItem(
            invoice_id=invoice.id,
            sales_order_item_id=UUID(item["sales_order_item_id"]) if item.get("sales_order_item_id") else None,
            product_id=UUID(item["product_id"]),
            batch_id=UUID(item["batch_id"]) if item.get("batch_id") else None,
            qty=item["qty"],
            uom_id=UUID(item["uom_id"]),
            rate=item["rate"],
            discount_percent=item.get("discount_percent", 0),
            discount_amount=item_discount,
            tax_rate=item.get("tax_rate", 0),
            tax_amount=item_tax,
            amount=item_amount,
        )
        db.add(inv_item)
        
        # Update sales order invoiced qty
        if item.get("sales_order_item_id"):
            so_item = await db.execute(
                select(SalesOrderItem).where(SalesOrderItem.id == item["sales_order_item_id"])
            )
            so_item_obj = so_item.scalar_one_or_none()
            if so_item_obj:
                so_item_obj.invoiced_qty = float(so_item_obj.invoiced_qty) + item["qty"]
    
    await db.commit()
    
    logger.info("sales_invoice_created", invoice_id=str(invoice.id), number=invoice_number)
    
    return {"id": str(invoice.id), "invoice_number": invoice_number, "total_amount": float(total_amount)}


@router.post("/invoices/{invoice_id}/issue")
async def issue_sales_invoice(
    invoice_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("invoice:approve")),
):
    result = await db.execute(
        select(SalesInvoice).where(
            SalesInvoice.id == invoice_id,
            SalesInvoice.organization_id == current_user.organization_id
        )
    )
    invoice = result.scalar_one_or_none()
    
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    
    if invoice.status != SalesInvoiceStatus.DRAFT:
        raise HTTPException(status_code=400, detail="Invoice already issued")
    
    invoice.status = SalesInvoiceStatus.ISSUED
    invoice.issued_at = datetime.now(timezone.utc)
    invoice.issued_by = current_user.id
    
    # Update sales order status
    if invoice.sales_order_id:
        so = await db.execute(
            select(SalesOrder).where(SalesOrder.id == invoice.sales_order_id)
        )
        so_obj = so.scalar_one_or_none()
        if so_obj:
            # Check if fully invoiced
            so_items = await db.execute(
                select(SalesOrderItem).where(SalesOrderItem.order_id == so_obj.id)
            )
            all_invoiced = all(
                float(item.invoiced_qty) >= float(item.qty)
                for item in so_items.scalars().all()
            )
            if all_invoiced:
                so_obj.status = SalesOrderStatus.INVOICED
            else:
                so_obj.status = SalesOrderStatus.PARTIALLY_FULFILLED
    
    await db.commit()
    
    logger.info("sales_invoice_issued", invoice_id=str(invoice_id))
    
    return {"message": "Invoice issued", "status": invoice.status.value}