from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_
from sqlalchemy.orm import selectinload
from pydantic import BaseModel, EmailStr
from uuid import UUID
from datetime import datetime
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission, get_password_hash
from app.models import User, UserStatus, Organization, Warehouse
from app.models.organization import UserWarehouseAssignment
import structlog

logger = structlog.get_logger()

router = APIRouter()


class UserBase(BaseModel):
    email: EmailStr
    username: str
    full_name: str
    phone: Optional[str] = None
    department: Optional[str] = None
    designation: Optional[str] = None
    reporting_manager_id: Optional[UUID] = None
    assigned_warehouse_ids: List[UUID] = []
    approval_limit: Optional[float] = None


class UserCreate(UserBase):
    password: str


class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    username: Optional[str] = None
    full_name: Optional[str] = None
    phone: Optional[str] = None
    department: Optional[str] = None
    designation: Optional[str] = None
    reporting_manager_id: Optional[UUID] = None
    assigned_warehouse_ids: Optional[List[UUID]] = None
    approval_limit: Optional[float] = None
    status: Optional[UserStatus] = None
    mfa_enabled: Optional[bool] = None


class UserResponse(UserBase):
    id: UUID
    status: UserStatus
    mfa_enabled: bool
    last_login: Optional[datetime]
    created_at: datetime
    updated_at: datetime
    organization_id: UUID
    
    class Config:
        from_attributes = True


class UserListResponse(BaseModel):
    items: List[UserResponse]
    total: int
    page: int
    page_size: int
    total_pages: int


@router.post("", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(
    user_data: UserCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("user:create")),
):
    # Check duplicates
    existing = await db.execute(
        select(User).where(
            or_(User.email == user_data.email, User.username == user_data.username)
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Email or username already exists")
    
    # Validate organization
    org_result = await db.execute(select(Organization).where(Organization.id == current_user.organization_id))
    org = org_result.scalar_one_or_none()
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    
    user = User(
        **user_data.model_dump(exclude={"password"}),
        hashed_password=get_password_hash(user_data.password),
        organization_id=current_user.organization_id,
        created_by=current_user.id,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    
    # Assign warehouses
    if user_data.assigned_warehouse_ids:
        for wh_id in user_data.assigned_warehouse_ids:
            assignment = UserWarehouseAssignment(
                user_id=user.id,
                warehouse_id=wh_id,
                assigned_by=current_user.id,
            )
            db.add(assignment)
        await db.commit()
    
    logger.info("user_created", user_id=str(user.id), email=user.email)
    return user


@router.get("", response_model=UserListResponse)
async def list_users(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[UserStatus] = None,
    department: Optional[str] = None,
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("user:view")),
):
    query = select(User).where(User.organization_id == current_user.organization_id)
    
    if status:
        query = query.where(User.status == status)
    if department:
        query = query.where(User.department == department)
    if search:
        query = query.where(
            or_(
                User.full_name.ilike(f"%{search}%"),
                User.email.ilike(f"%{search}%"),
                User.username.ilike(f"%{search}%"),
            )
        )
    
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(User.created_at.desc())
    result = await db.execute(query)
    items = result.scalars().all()
    
    return UserListResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=(total + page_size - 1) // page_size,
    )


@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("user:view")),
):
    result = await db.execute(
        select(User).where(
            User.id == user_id,
            User.organization_id == current_user.organization_id
        )
    )
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    return user


@router.put("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: UUID,
    user_data: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("user:update")),
):
    result = await db.execute(
        select(User).where(
            User.id == user_id,
            User.organization_id == current_user.organization_id
        )
    )
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    update_data = user_data.model_dump(exclude_unset=True)
    
    # Handle warehouse assignments separately
    warehouse_ids = update_data.pop("assigned_warehouse_ids", None)
    
    for field, value in update_data.items():
        setattr(user, field, value)
    
    if warehouse_ids is not None:
        # Remove existing assignments
        await db.execute(
            select(UserWarehouseAssignment).where(UserWarehouseAssignment.user_id == user_id)
        )
        # Add new assignments
        for wh_id in warehouse_ids:
            assignment = UserWarehouseAssignment(
                user_id=user.id,
                warehouse_id=wh_id,
                assigned_by=current_user.id,
            )
            db.add(assignment)
    
    await db.commit()
    await db.refresh(user)
    
    logger.info("user_updated", user_id=str(user.id))
    return user


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(
    user_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("user:delete")),
):
    if user_id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot delete yourself")
    
    result = await db.execute(
        select(User).where(
            User.id == user_id,
            User.organization_id == current_user.organization_id
        )
    )
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.status = UserStatus.INACTIVE
    await db.commit()
    
    logger.info("user_deleted", user_id=str(user_id))


@router.post("/{user_id}/reset-password")
async def admin_reset_password(
    user_id: UUID,
    new_password: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("user:update")),
):
    result = await db.execute(
        select(User).where(
            User.id == user_id,
            User.organization_id == current_user.organization_id
        )
    )
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    user.hashed_password = get_password_hash(new_password)
    await db.commit()
    
    logger.info("password_reset_by_admin", user_id=str(user_id), admin_id=str(current_user.id))
    return {"message": "Password reset successfully"}