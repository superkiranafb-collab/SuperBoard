from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
from uuid import UUID
from datetime import datetime, date, timezone
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.models import (
    Vehicle, VehicleType, Driver,
    DeliveryTrip, DeliveryTripStatus, DeliveryTripStop, DeliveryTripStopStatus,
    DeliveryNote, DeliveryNoteItem, GPSLocation,
    Route, RouteStop,
    Customer, CustomerAddress, Warehouse, User, Organization
)
import structlog

logger = structlog.get_logger()

router = APIRouter()


# Vehicle Endpoints
class VehicleCreate(BaseModel):
    registration_number: str
    vehicle_type: VehicleType
    make_model: Optional[str] = None
    capacity_weight_kg: Optional[float] = None
    capacity_volume_cft: Optional[float] = None
    owner_type: str = "company"
    owner_name: Optional[str] = None
    owner_contact: Optional[str] = None
    insurance_expiry: Optional[date] = None
    fitness_expiry: Optional[date] = None
    permit_expiry: Optional[date] = None
    gps_device_id: Optional[str] = None


@router.post("/vehicles", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_vehicle(
    vehicle_data: VehicleCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:create")),
):
    existing = await db.execute(
        select(Vehicle).where(
            Vehicle.organization_id == current_user.organization_id,
            Vehicle.registration_number == vehicle_data.registration_number
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Vehicle registration already exists")
    
    vehicle = Vehicle(
        organization_id=current_user.organization_id,
        **vehicle_data.model_dump(),
    )
    db.add(vehicle)
    await db.commit()
    await db.refresh(vehicle)
    
    return {"id": str(vehicle.id), "registration_number": vehicle.registration_number}


@router.get("/vehicles", response_model=List[dict])
async def list_vehicles(
    vehicle_type: Optional[VehicleType] = None,
    is_active: bool = True,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:view")),
):
    query = select(Vehicle).where(
        Vehicle.organization_id == current_user.organization_id,
        Vehicle.is_active == is_active
    )
    
    if vehicle_type:
        query = query.where(Vehicle.vehicle_type == vehicle_type)
    
    result = await db.execute(query.order_by(Vehicle.registration_number))
    return [
        {
            "id": str(v.id),
            "registration_number": v.registration_number,
            "vehicle_type": v.vehicle_type.value,
            "make_model": v.make_model,
            "capacity_weight_kg": float(v.capacity_weight_kg) if v.capacity_weight_kg else None,
            "owner_type": v.owner_type,
            "is_active": v.is_active,
        }
        for v in result.scalars().all()
    ]


# Driver Endpoints
class DriverCreate(BaseModel):
    user_id: Optional[UUID] = None
    employee_code: Optional[str] = None
    name: str
    phone: str
    license_number: str
    license_expiry: date
    license_type: Optional[str] = None
    address: Optional[str] = None
    emergency_contact: Optional[str] = None
    bank_account_id: Optional[UUID] = None
    default_vehicle_id: Optional[UUID] = None


@router.post("/drivers", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_driver(
    driver_data: DriverCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:create")),
):
    driver = Driver(
        organization_id=current_user.organization_id,
        **driver_data.model_dump(),
    )
    db.add(driver)
    await db.commit()
    await db.refresh(driver)
    
    return {"id": str(driver.id), "name": driver.name, "license_number": driver.license_number}


@router.get("/drivers", response_model=List[dict])
async def list_drivers(
    is_active: bool = True,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:view")),
):
    result = await db.execute(
        select(Driver).where(
            Driver.organization_id == current_user.organization_id,
            Driver.is_active == is_active
        ).order_by(Driver.name)
    )
    return [
        {
            "id": str(d.id),
            "employee_code": d.employee_code,
            "name": d.name,
            "phone": d.phone,
            "license_number": d.license_number,
            "license_expiry": d.license_expiry.isoformat(),
            "default_vehicle_id": str(d.default_vehicle_id) if d.default_vehicle_id else None,
            "rating": float(d.rating) if d.rating else None,
        }
        for d in result.scalars().all()
    ]


# Delivery Trip Endpoints
class DeliveryTripStopCreate(BaseModel):
    sequence: int
    delivery_note_id: Optional[UUID] = None
    customer_id: UUID
    customer_address_id: Optional[UUID] = None
    planned_time: Optional[datetime] = None


class DeliveryTripCreate(BaseModel):
    trip_date: date
    warehouse_id: UUID
    vehicle_id: Optional[UUID] = None
    driver_id: Optional[UUID] = None
    planned_start_time: Optional[datetime] = None
    stops: List[DeliveryTripStopCreate]


@router.post("/trips", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_delivery_trip(
    trip_data: DeliveryTripCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:create")),
):
    # Validate warehouse
    warehouse = await db.execute(
        select(Warehouse).where(
            Warehouse.id == trip_data.warehouse_id,
            Warehouse.organization_id == current_user.organization_id
        )
    )
    if not warehouse.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Warehouse not found")
    
    # Validate vehicle if provided
    if trip_data.vehicle_id:
        vehicle = await db.execute(
            select(Vehicle).where(
                Vehicle.id == trip_data.vehicle_id,
                Vehicle.organization_id == current_user.organization_id
            )
        )
        if not vehicle.scalar_one_or_none():
            raise HTTPException(status_code=404, detail="Vehicle not found")
    
    # Validate driver if provided
    if trip_data.driver_id:
        driver = await db.execute(
            select(Driver).where(
                Driver.id == trip_data.driver_id,
                Driver.organization_id == current_user.organization_id
            )
        )
        if not driver.scalar_one_or_none():
            raise HTTPException(status_code=404, detail="Driver not found")
    
    # Generate trip number
    today = date.today()
    prefix = f"DT-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(DeliveryTrip.id)).where(
            DeliveryTrip.organization_id == current_user.organization_id,
            DeliveryTrip.trip_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    trip_number = f"{prefix}{seq:04d}"
    
    trip = DeliveryTrip(
        organization_id=current_user.organization_id,
        trip_number=trip_number,
        trip_date=datetime.combine(trip_data.trip_date, datetime.min.time()).replace(tzinfo=timezone.utc),
        warehouse_id=trip_data.warehouse_id,
        vehicle_id=trip_data.vehicle_id,
        driver_id=trip_data.driver_id,
        status=DeliveryTripStatus.DRAFT,
        planned_start_time=trip_data.planned_start_time,
        created_by=current_user.id,
    )
    db.add(trip)
    await db.flush()
    
    for stop_data in trip_data.stops:
        # Validate customer
        customer = await db.execute(
            select(Customer).where(
                Customer.id == stop_data.customer_id,
                Customer.organization_id == current_user.organization_id
            )
        )
        if not customer.scalar_one_or_none():
            raise HTTPException(status_code=404, detail=f"Customer {stop_data.customer_id} not found")
        
        stop = DeliveryTripStop(
            trip_id=trip.id,
            sequence=stop_data.sequence,
            delivery_note_id=stop_data.delivery_note_id,
            customer_id=stop_data.customer_id,
            customer_address_id=stop_data.customer_address_id,
            status=DeliveryTripStopStatus.PENDING,
            planned_time=stop_data.planned_time,
        )
        db.add(stop)
    
    await db.commit()
    
    return {"id": str(trip.id), "trip_number": trip_number, "status": trip.status.value}


@router.get("/trips", response_model=List[dict])
async def list_delivery_trips(
    status: Optional[DeliveryTripStatus] = None,
    warehouse_id: Optional[UUID] = None,
    driver_id: Optional[UUID] = None,
    from_date: Optional[date] = None,
    to_date: Optional[date] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:view")),
):
    query = select(DeliveryTrip).where(DeliveryTrip.organization_id == current_user.organization_id)
    
    if status:
        query = query.where(DeliveryTrip.status == status)
    if warehouse_id:
        query = query.where(DeliveryTrip.warehouse_id == warehouse_id)
    if driver_id:
        query = query.where(DeliveryTrip.driver_id == driver_id)
    if from_date:
        query = query.where(DeliveryTrip.trip_date >= from_date)
    if to_date:
        query = query.where(DeliveryTrip.trip_date <= to_date)
    
    query = query.order_by(DeliveryTrip.trip_date.desc()).limit(100)
    result = await db.execute(query)
    trips = result.scalars().all()
    
    return [
        {
            "id": str(t.id),
            "trip_number": t.trip_number,
            "trip_date": t.trip_date.isoformat(),
            "warehouse_id": str(t.warehouse_id),
            "vehicle_id": str(t.vehicle_id) if t.vehicle_id else None,
            "driver_id": str(t.driver_id) if t.driver_id else None,
            "status": t.status.value,
            "total_expenses": float(t.total_expenses),
        }
        for t in trips
    ]


@router.get("/trips/{trip_id}")
async def get_delivery_trip(
    trip_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:view")),
):
    result = await db.execute(
        select(DeliveryTrip).where(
            DeliveryTrip.id == trip_id,
            DeliveryTrip.organization_id == current_user.organization_id
        )
    )
    trip = result.scalar_one_or_none()
    
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    
    # Get stops
    stops_result = await db.execute(
        select(DeliveryTripStop).where(DeliveryTripStop.trip_id == trip_id).order_by(DeliveryTripStop.sequence)
    )
    stops = stops_result.scalars().all()
    
    stops_data = []
    for stop in stops:
        customer = await db.execute(select(Customer).where(Customer.id == stop.customer_id))
        cust = customer.scalar_one_or_none()
        
        delivery_note = None
        if stop.delivery_note_id:
            dn = await db.execute(select(DeliveryNote).where(DeliveryNote.id == stop.delivery_note_id))
            dn_obj = dn.scalar_one_or_none()
            if dn_obj:
                delivery_note = {"id": str(dn_obj.id), "delivery_number": dn_obj.delivery_number}
        
        stops_data.append({
            "id": str(stop.id),
            "sequence": stop.sequence,
            "customer_id": str(stop.customer_id),
            "customer_name": cust.name if cust else "",
            "delivery_note": delivery_note,
            "status": stop.status.value,
            "planned_time": stop.planned_time.isoformat() if stop.planned_time else None,
            "actual_arrival_time": stop.actual_arrival_time.isoformat() if stop.actual_arrival_time else None,
            "cash_to_collect": float(stop.cash_to_collect),
            "cash_collected": float(stop.cash_collected),
            "failure_reason": stop.failure_reason,
        })
    
    return {
        "id": str(trip.id),
        "trip_number": trip.trip_number,
        "trip_date": trip.trip_date.isoformat(),
        "warehouse_id": str(trip.warehouse_id),
        "vehicle_id": str(trip.vehicle_id) if trip.vehicle_id else None,
        "driver_id": str(trip.driver_id) if trip.driver_id else None,
        "status": trip.status.value,
        "planned_start_time": trip.planned_start_time.isoformat() if trip.planned_start_time else None,
        "actual_start_time": trip.actual_start_time.isoformat() if trip.actual_start_time else None,
        "actual_end_time": trip.actual_end_time.isoformat() if trip.actual_end_time else None,
        "total_distance_km": float(trip.total_distance_km) if trip.total_distance_km else None,
        "total_expenses": float(trip.total_expenses),
        "stops": stops_data,
    }


@router.post("/trips/{trip_id}/start")
async def start_delivery_trip(
    trip_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:create")),
):
    result = await db.execute(
        select(DeliveryTrip).where(
            DeliveryTrip.id == trip_id,
            DeliveryTrip.organization_id == current_user.organization_id
        )
    )
    trip = result.scalar_one_or_none()
    
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    
    if trip.status != DeliveryTripStatus.PLANNED and trip.status != DeliveryTripStatus.ASSIGNED:
        raise HTTPException(status_code=400, detail="Trip cannot be started")
    
    trip.status = DeliveryTripStatus.IN_PROGRESS
    trip.actual_start_time = datetime.now(timezone.utc)
    
    await db.commit()
    
    return {"message": "Trip started", "status": trip.status.value}


@router.post("/trips/{trip_id}/complete")
async def complete_delivery_trip(
    trip_id: UUID,
    end_data: dict,  # {total_distance_km, fuel_cost, toll_cost, driver_allowance, other_expenses}
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:complete")),
):
    result = await db.execute(
        select(DeliveryTrip).where(
            DeliveryTrip.id == trip_id,
            DeliveryTrip.organization_id == current_user.organization_id
        )
    )
    trip = result.scalar_one_or_none()
    
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    
    if trip.status != DeliveryTripStatus.IN_PROGRESS:
        raise HTTPException(status_code=400, detail="Trip not in progress")
    
    trip.status = DeliveryTripStatus.COMPLETED
    trip.actual_end_time = datetime.now(timezone.utc)
    trip.total_distance_km = end_data.get("total_distance_km")
    trip.fuel_cost = end_data.get("fuel_cost", 0)
    trip.toll_cost = end_data.get("toll_cost", 0)
    trip.driver_allowance = end_data.get("driver_allowance", 0)
    trip.other_expenses = end_data.get("other_expenses", 0)
    trip.total_expenses = (
        float(trip.fuel_cost) + float(trip.toll_cost) + 
        float(trip.driver_allowance) + float(trip.other_expenses)
    )
    
    # Update all pending stops to skipped if not delivered
    stops_result = await db.execute(
        select(DeliveryTripStop).where(
            DeliveryTripStop.trip_id == trip_id,
            DeliveryTripStop.status == DeliveryTripStopStatus.PENDING
        )
    )
    for stop in stops_result.scalars().all():
        stop.status = DeliveryTripStopStatus.SKIPPED
    
    await db.commit()
    
    return {"message": "Trip completed", "status": trip.status.value}


# Delivery Trip Stop - Arrive/Depart
@router.post("/trips/{trip_id}/stops/{stop_id}/arrive")
async def arrive_at_stop(
    trip_id: UUID,
    stop_id: UUID,
    latitude: Optional[float] = None,
    longitude: Optional[float] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:create")),
):
    result = await db.execute(
        select(DeliveryTripStop).where(
            DeliveryTripStop.id == stop_id,
            DeliveryTripStop.trip_id == trip_id
        )
    )
    stop = result.scalar_one_or_none()
    
    if not stop:
        raise HTTPException(status_code=404, detail="Stop not found")
    
    stop.status = DeliveryTripStopStatus.IN_PROGRESS
    stop.actual_arrival_time = datetime.now(timezone.utc)
    stop.latitude = latitude
    stop.longitude = longitude
    
    await db.commit()
    
    return {"message": "Arrived at stop", "status": stop.status.value}


@router.post("/trips/{trip_id}/stops/{stop_id}/complete")
async def complete_stop(
    trip_id: UUID,
    stop_id: UUID,
    complete_data: dict,  # {status, cash_collected, payment_mode, signature_url, photo_url, failure_reason, latitude, longitude}
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:complete")),
):
    result = await db.execute(
        select(DeliveryTripStop).where(
            DeliveryTripStop.id == stop_id,
            DeliveryTripStop.trip_id == trip_id
        )
    )
    stop = result.scalar_one_or_none()
    
    if not stop:
        raise HTTPException(status_code=404, detail="Stop not found")
    
    stop.status = DeliveryTripStopStatus(complete_data.get("status", "delivered"))
    stop.actual_departure_time = datetime.now(timezone.utc)
    stop.cash_collected = complete_data.get("cash_collected", 0)
    stop.payment_mode = complete_data.get("payment_mode")
    stop.signature_url = complete_data.get("signature_url")
    stop.photo_url = complete_data.get("photo_url")
    stop.failure_reason = complete_data.get("failure_reason")
    stop.latitude = complete_data.get("latitude", stop.latitude)
    stop.longitude = complete_data.get("longitude", stop.longitude)
    
    # If delivery note linked, update it
    if stop.delivery_note_id:
        dn = await db.execute(select(DeliveryNote).where(DeliveryNote.id == stop.delivery_note_id))
        dn_obj = dn.scalar_one_or_none()
        if dn_obj:
            dn_obj.status = "delivered" if stop.status == DeliveryTripStopStatus.DELIVERED else "failed"
            dn_obj.delivered_at = datetime.now(timezone.utc)
            dn_obj.received_by_name = complete_data.get("received_by_name")
            dn_obj.signature_url = complete_data.get("signature_url")
            dn_obj.photo_url = complete_data.get("photo_url")
            dn_obj.latitude = complete_data.get("latitude")
            dn_obj.longitude = complete_data.get("longitude")
    
    await db.commit()
    
    return {"message": "Stop completed", "status": stop.status.value}


# Route Endpoints
class RouteStopCreate(BaseModel):
    sequence: int
    customer_id: UUID
    customer_address_id: Optional[UUID] = None
    estimated_arrival: Optional[str] = None  # HH:MM
    estimated_departure: Optional[str] = None  # HH:MM
    service_time_minutes: int = 15


class RouteCreate(BaseModel):
    code: str
    name: str
    description: Optional[str] = None
    warehouse_id: UUID
    salesperson_id: Optional[UUID] = None
    frequency: str = "daily"
    day_of_week: Optional[int] = None
    estimated_distance_km: Optional[float] = None
    estimated_duration_minutes: Optional[int] = None
    stops: List[RouteStopCreate]


@router.post("/routes", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_route(
    route_data: RouteCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:create")),
):
    existing = await db.execute(
        select(Route).where(
            Route.organization_id == current_user.organization_id,
            Route.code == route_data.code
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Route code already exists")
    
    route = Route(
        organization_id=current_user.organization_id,
        **route_data.model_dump(exclude={"stops"}),
    )
    db.add(route)
    await db.flush()
    
    for stop_data in route_data.stops:
        stop = RouteStop(
            route_id=route.id,
            **stop_data.model_dump(),
        )
        db.add(stop)
    
    await db.commit()
    
    return {"id": str(route.id), "code": route.code, "name": route.name}


@router.get("/routes", response_model=List[dict])
async def list_routes(
    warehouse_id: Optional[UUID] = None,
    is_active: bool = True,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:view")),
):
    query = select(Route).where(
        Route.organization_id == current_user.organization_id,
        Route.is_active == is_active
    )
    
    if warehouse_id:
        query = query.where(Route.warehouse_id == warehouse_id)
    
    result = await db.execute(query.order_by(Route.code))
    return [
        {
            "id": str(r.id),
            "code": r.code,
            "name": r.name,
            "warehouse_id": str(r.warehouse_id),
            "frequency": r.frequency,
            "is_active": r.is_active,
        }
        for r in result.scalars().all()
    ]


# GPS Location - for real-time tracking
@router.post("/gps-location")
async def record_gps_location(
    trip_id: Optional[UUID] = None,
    driver_id: Optional[UUID] = None,
    vehicle_id: Optional[UUID] = None,
    latitude: float = 0,
    longitude: float = 0,
    speed_kmph: Optional[float] = None,
    heading: Optional[float] = None,
    accuracy_meters: Optional[float] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:view")),
):
    location = GPSLocation(
        organization_id=current_user.organization_id,
        trip_id=trip_id,
        driver_id=driver_id,
        vehicle_id=vehicle_id,
        latitude=latitude,
        longitude=longitude,
        speed_kmph=speed_kmph,
        heading=heading,
        accuracy_meters=accuracy_meters,
        recorded_at=datetime.now(timezone.utc),
    )
    db.add(location)
    await db.commit()
    
    return {"message": "Location recorded"}


@router.get("/trips/{trip_id}/gps-track")
async def get_trip_gps_track(
    trip_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("delivery:view")),
):
    result = await db.execute(
        select(GPSLocation).where(
            GPSLocation.trip_id == trip_id,
            GPSLocation.organization_id == current_user.organization_id
        ).order_by(GPSLocation.recorded_at)
    )
    locations = result.scalars().all()
    
    return [
        {
            "latitude": float(loc.latitude),
            "longitude": float(loc.longitude),
            "speed_kmph": float(loc.speed_kmph) if loc.speed_kmph else None,
            "recorded_at": loc.recorded_at.isoformat(),
        }
        for loc in locations
    ]