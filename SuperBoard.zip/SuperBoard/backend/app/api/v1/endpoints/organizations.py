from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from sqlalchemy.orm import selectinload
from pydantic import BaseModel, EmailStr
from uuid import UUID
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.models import User, Organization, OrganizationType, UserStatus
import structlog

logger = structlog.get_logger()

router = APIRouter()


class OrganizationBase(BaseModel):
    name: str
    code: str
    type: OrganizationType = OrganizationType.BRANCH
    parent_id: Optional[UUID] = None
    gstin: Optional[str] = None
    pan: Optional[str] = None
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    country: str = "India"
    phone: Optional[str] = None
    email: Optional[EmailStr] = None


class OrganizationCreate(OrganizationBase):
    pass


class OrganizationUpdate(BaseModel):
    name: Optional[str] = None
    code: Optional[str] = None
    type: Optional[OrganizationType] = None
    parent_id: Optional[UUID] = None
    gstin: Optional[str] = None
    pan: Optional[str] = None
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    country: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[EmailStr] = None
    is_active: Optional[bool] = None
    settings: Optional[dict] = None


class OrganizationResponse(OrganizationBase):
    id: UUID
    is_active: bool
    settings: dict
    created_at: str
    updated_at: str
    created_by: Optional[UUID]
    
    class Config:
        from_attributes = True


class OrganizationListResponse(BaseModel):
    items: List[OrganizationResponse]
    total: int
    page: int
    page_size: int
    total_pages: int


@router.post("", response_model=OrganizationResponse, status_code=status.HTTP_201_CREATED)
async def create_organization(
    org_data: OrganizationCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("org:create")),
):
    # Check if code already exists
    existing = await db.execute(select(Organization).where(Organization.code == org_data.code))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Organization code already exists")
    
    org = Organization(
        **org_data.model_dump(),
        created_by=current_user.id,
    )
    db.add(org)
    await db.commit()
    await db.refresh(org)
    
    logger.info("organization_created", org_id=str(org.id), code=org.code)
    return org


@router.get("", response_model=OrganizationListResponse)
async def list_organizations(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    type: Optional[OrganizationType] = None,
    is_active: Optional[bool] = None,
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("org:view")),
):
    query = select(Organization)
    
    if type:
        query = query.where(Organization.type == type)
    if is_active is not None:
        query = query.where(Organization.is_active == is_active)
    if search:
        query = query.where(
            Organization.name.ilike(f"%{search}%") | 
            Organization.code.ilike(f"%{search}%")
        )
    
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    # Paginate
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(Organization.created_at.desc())
    result = await db.execute(query)
    items = result.scalars().all()
    
    return OrganizationListResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=(total + page_size - 1) // page_size,
    )


@router.get("/{org_id}", response_model=OrganizationResponse)
async def get_organization(
    org_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("org:view")),
):
    result = await db.execute(select(Organization).where(Organization.id == org_id))
    org = result.scalar_one_or_none()
    
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    
    return org


@router.put("/{org_id}", response_model=OrganizationResponse)
async def update_organization(
    org_id: UUID,
    org_data: OrganizationUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("org:update")),
):
    result = await db.execute(select(Organization).where(Organization.id == org_id))
    org = result.scalar_one_or_none()
    
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    
    update_data = org_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(org, field, value)
    
    await db.commit()
    await db.refresh(org)
    
    logger.info("organization_updated", org_id=str(org.id))
    return org


@router.delete("/{org_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_organization(
    org_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("org:delete")),
):
    result = await db.execute(select(Organization).where(Organization.id == org_id))
    org = result.scalar_one_or_none()
    
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    
    # Check for children
    children = await db.execute(select(Organization).where(Organization.parent_id == org_id))
    if children.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Cannot delete organization with child organizations")
    
    org.is_active = False
    await db.commit()
    
    logger.info("organization_deleted", org_id=str(org_id))


@router.get("/{org_id}/hierarchy")
async def get_organization_hierarchy(
    org_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("org:view")),
):
    # Get the organization and all descendants
    result = await db.execute(select(Organization).where(Organization.id == org_id))
    org = result.scalar_one_or_none()
    
    if not org:
        raise HTTPException(status_code=404, detail="Organization not found")
    
    # Recursive CTE to get all descendants
    from sqlalchemy import text
    cte_query = text("""
        WITH RECURSIVE org_tree AS (
            SELECT id, name, code, type, parent_id, 0 as level
            FROM organizations
            WHERE id = :org_id
            UNION ALL
            SELECT o.id, o.name, o.code, o.type, o.parent_id, ot.level + 1
            FROM organizations o
            INNER JOIN org_tree ot ON o.parent_id = ot.id
        )
        SELECT * FROM org_tree ORDER BY level, name
    """)
    result = await db.execute(cte_query, {"org_id": str(org_id)})
    hierarchy = result.mappings().all()
    
    return {"hierarchy": [dict(h) for h in hierarchy]}