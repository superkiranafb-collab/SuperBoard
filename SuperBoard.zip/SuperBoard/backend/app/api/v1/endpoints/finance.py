from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
from uuid import UUID
from datetime import datetime, date, timezone
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.models import (
    Account, AccountType, AccountGroup,
    JournalEntry, JournalEntryStatus, JournalEntryLine,
    CostCenter,
    ExpenseClaim, ExpenseClaimStatus, ExpenseClaimItem,
    GSTReturn, GSTReturnStatus,
    TDSEntry,
    Payment, PaymentMode, PaymentStatus,
    BankAccount,
    User, Organization
)
import structlog

logger = structlog.get_logger()

router = APIRouter()


# Chart of Accounts
class AccountCreate(BaseModel):
    code: str
    name: str
    account_type: AccountType
    account_group: AccountGroup
    parent_id: Optional[UUID] = None
    description: Optional[str] = None
    is_control_account: bool = False
    control_account_type: Optional[str] = None
    gst_applicable: bool = False
    gst_rate: Optional[float] = None
    opening_balance: float = 0
    opening_balance_type: str = "Dr"


@router.post("/accounts", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_account(
    account_data: AccountCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("finance:view")),
):
    existing = await db.execute(
        select(Account).where(
            Account.organization_id == current_user.organization_id,
            Account.code == account_data.code
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Account code already exists")
    
    account = Account(
        organization_id=current_user.organization_id,
        **account_data.model_dump(),
        created_by=current_user.id,
    )
    db.add(account)
    await db.commit()
    await db.refresh(account)
    
    return {"id": str(account.id), "code": account.code, "name": account.name}


@router.get("/accounts", response_model=List[dict])
async def list_accounts(
    account_type: Optional[AccountType] = None,
    is_active: bool = True,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("finance:view")),
):
    query = select(Account).where(
        Account.organization_id == current_user.organization_id,
        Account.is_active == is_active
    )
    
    if account_type:
        query = query.where(Account.account_type == account_type)
    
    result = await db.execute(query.order_by(Account.code))
    accounts = result.scalars().all()
    
    return [
        {
            "id": str(a.id),
            "code": a.code,
            "name": a.name,
            "account_type": a.account_type.value,
            "account_group": a.account_group.value,
            "parent_id": str(a.parent_id) if a.parent_id else None,
            "is_control_account": a.is_control_account,
            "control_account_type": a.control_account_type,
            "current_balance": float(a.current_balance),
        }
        for a in accounts
    ]


# Journal Entries
class JournalEntryLineCreate(BaseModel):
    account_id: UUID
    party_type: Optional[str] = None
    party_id: Optional[UUID] = None
    debit: float = 0
    credit: float = 0
    narration: Optional[str] = None
    cost_center_id: Optional[UUID] = None


class JournalEntryCreate(BaseModel):
    entry_date: date
    reference_doctype: Optional[str] = None
    reference_doc_id: Optional[UUID] = None
    reference_docname: Optional[str] = None
    narration: str
    lines: List[JournalEntryLineCreate]


@router.post("/journal-entries", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_journal_entry(
    je_data: JournalEntryCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("finance:view")),
):
    # Validate balanced
    total_debit = sum(line.debit for line in je_data.lines)
    total_credit = sum(line.credit for line in je_data.lines)
    
    if abs(total_debit - total_credit) > 0.01:
        raise HTTPException(status_code=400, detail="Journal entry must be balanced")
    
    # Generate entry number
    today = date.today()
    prefix = f"JE-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(JournalEntry.id)).where(
            JournalEntry.organization_id == current_user.organization_id,
            JournalEntry.entry_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    entry_number = f"{prefix}{seq:04d}"
    
    je = JournalEntry(
        organization_id=current_user.organization_id,
        entry_number=entry_number,
        entry_date=datetime.combine(je_data.entry_date, datetime.max.time()).replace(tzinfo=timezone.utc),
        reference_doctype=je_data.reference_doctype,
        reference_doc_id=je_data.reference_doc_id,
        reference_docname=je_data.reference_docname,
        narration=je_data.narration,
        total_debit=total_debit,
        total_credit=total_credit,
        status=JournalEntryStatus.DRAFT,
        created_by=current_user.id,
    )
    db.add(je)
    await db.flush()
    
    for idx, line_data in enumerate(je_data.lines):
        line = JournalEntryLine(
            journal_entry_id=je.id,
            account_id=line_data.account_id,
            party_type=line_data.party_type,
            party_id=line_data.party_id,
            debit=line_data.debit,
            credit=line_data.credit,
            narration=line_data.narration,
            cost_center_id=line_data.cost_center_id,
            sort_order=idx,
        )
        db.add(line)
    
    await db.commit()
    
    return {"id": str(je.id), "entry_number": entry_number, "status": je.status.value}


@router.post("/journal-entries/{je_id}/post")
async def post_journal_entry(
    je_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("finance:view")),
):
    result = await db.execute(
        select(JournalEntry).where(
            JournalEntry.id == je_id,
            JournalEntry.organization_id == current_user.organization_id
        )
    )
    je = result.scalar_one_or_none()
    
    if not je:
        raise HTTPException(status_code=404, detail="Journal entry not found")
    
    if je.status == JournalEntryStatus.POSTED:
        raise HTTPException(status_code=400, detail="Already posted")
    
    # Update account balances
    lines_result = await db.execute(
        select(JournalEntryLine).where(JournalEntryLine.journal_entry_id == je_id)
    )
    for line in lines_result.scalars().all():
        account = await db.execute(select(Account).where(Account.id == line.account_id))
        account_obj = account.scalar_one_or_none()
        if account_obj:
            if line.debit > 0:
                account_obj.current_balance = float(account_obj.current_balance) + line.debit
            if line.credit > 0:
                account_obj.current_balance = float(account_obj.current_balance) - line.credit
    
    je.status = JournalEntryStatus.POSTED
    je.posted_at = datetime.now(timezone.utc)
    je.posted_by = current_user.id
    
    await db.commit()
    
    return {"message": "Journal entry posted", "status": je.status.value}


# Expense Claims
class ExpenseClaimItemCreate(BaseModel):
    expense_date: date
    account_id: UUID
    description: str
    amount: float
    currency: str = "INR"
    tax_amount: float = 0
    receipt_url: Optional[str] = None
    is_billable: bool = False
    project_id: Optional[UUID] = None
    cost_center_id: Optional[UUID] = None


class ExpenseClaimCreate(BaseModel):
    claim_date: date
    items: List[ExpenseClaimItemCreate]


@router.post("/expense-claims", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_expense_claim(
    claim_data: ExpenseClaimCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("expense:create")),
):
    today = date.today()
    prefix = f"EXP-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(ExpenseClaim.id)).where(
            ExpenseClaim.organization_id == current_user.organization_id,
            ExpenseClaim.claim_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    claim_number = f"{prefix}{seq:04d}"
    
    total_amount = sum(item.amount for item in claim_data.items)
    
    claim = ExpenseClaim(
        organization_id=current_user.organization_id,
        claim_number=claim_number,
        employee_id=current_user.id,
        status=ExpenseClaimStatus.DRAFT,
        claim_date=datetime.combine(claim_data.claim_date, datetime.max.time()).replace(tzinfo=timezone.utc),
        total_amount=total_amount,
        created_by=current_user.id,
    )
    db.add(claim)
    await db.flush()
    
    for item_data in claim_data.items:
        item = ExpenseClaimItem(
            claim_id=claim.id,
            expense_date=datetime.combine(item_data.expense_date, datetime.max.time()).replace(tzinfo=timezone.utc),
            account_id=item_data.account_id,
            description=item_data.description,
            amount=item_data.amount,
            currency=item_data.currency,
            tax_amount=item_data.tax_amount,
            receipt_url=item_data.receipt_url,
            is_billable=item_data.is_billable,
            project_id=item_data.project_id,
            cost_center_id=item_data.cost_center_id,
        )
        db.add(item)
    
    await db.commit()
    
    return {"id": str(claim.id), "claim_number": claim_number, "total_amount": total_amount}


@router.post("/expense-claims/{claim_id}/submit")
async def submit_expense_claim(
    claim_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("expense:create")),
):
    result = await db.execute(
        select(ExpenseClaim).where(
            ExpenseClaim.id == claim_id,
            ExpenseClaim.organization_id == current_user.organization_id,
            ExpenseClaim.employee_id == current_user.id
        )
    )
    claim = result.scalar_one_or_none()
    
    if not claim:
        raise HTTPException(status_code=404, detail="Expense claim not found")
    
    if claim.status != ExpenseClaimStatus.DRAFT:
        raise HTTPException(status_code=400, detail="Claim already submitted")
    
    claim.status = ExpenseClaimStatus.SUBMITTED
    await db.commit()
    
    return {"message": "Expense claim submitted", "status": claim.status.value}


# GST Returns
@router.get("/gst-returns", response_model=List[dict])
async def list_gst_returns(
    return_type: Optional[str] = None,
    period: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("gst:report")),
):
    query = select(GSTReturn).where(GSTReturn.organization_id == current_user.organization_id)
    
    if return_type:
        query = query.where(GSTReturn.return_type == return_type)
    if period:
        query = query.where(GSTReturn.period == period)
    
    result = await db.execute(query.order_by(GSTReturn.period.desc()))
    returns = result.scalars().all()
    
    return [
        {
            "id": str(r.id),
            "return_type": r.return_type,
            "period": r.period,
            "status": r.status.value,
            "total_tax_liability": float(r.total_tax_liability),
            "itc_available": float(r.itc_available),
            "tax_paid": float(r.tax_paid),
            "filing_date": r.filing_date.isoformat() if r.filing_date else None,
        }
        for r in returns
    ]


@router.post("/gst-returns/compute")
async def compute_gst_return(
    return_type: str,
    period: str,  # YYYY-MM
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("gst:report")),
):
    # This would compute GSTR-1 or GSTR-3B from sales/purchase invoices
    # For now, return a placeholder
    
    existing = await db.execute(
        select(GSTReturn).where(
            GSTReturn.organization_id == current_user.organization_id,
            GSTReturn.return_type == return_type,
            GSTReturn.period == period
        )
    )
    existing_return = existing.scalar_one_or_none()
    
    if existing_return:
        return {"message": "Return already computed", "id": str(existing_return.id)}
    
    gst_return = GSTReturn(
        organization_id=current_user.organization_id,
        return_type=return_type,
        period=period,
        status=GSTReturnStatus.COMPUTED,
        data_json={"computed_at": datetime.now(timezone.utc).isoformat()},
        created_by=current_user.id,
    )
    db.add(gst_return)
    await db.commit()
    
    return {"id": str(gst_return.id), "message": "GST return computed"}


# Bank Accounts
class BankAccountCreate(BaseModel):
    account_name: str
    bank_name: str
    branch: Optional[str] = None
    account_number: str
    ifsc_code: Optional[str] = None
    account_type: str = "current"
    is_default: bool = False
    opening_balance: float = 0


@router.post("/bank-accounts", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_bank_account(
    account_data: BankAccountCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("finance:view")),
):
    existing = await db.execute(
        select(BankAccount).where(
            BankAccount.organization_id == current_user.organization_id,
            BankAccount.account_number == account_data.account_number
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Account number already exists")
    
    if account_data.is_default:
        # Unset other defaults
        await db.execute(
            select(BankAccount).where(
                BankAccount.organization_id == current_user.organization_id,
                BankAccount.is_default == True
            )
        )
        # Would update
    
    account = BankAccount(
        organization_id=current_user.organization_id,
        **account_data.model_dump(),
        current_balance=account_data.opening_balance,
    )
    db.add(account)
    await db.commit()
    await db.refresh(account)
    
    return {"id": str(account.id), "account_name": account.account_name, "account_number": account.account_number}


@router.get("/bank-accounts", response_model=List[dict])
async def list_bank_accounts(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("finance:view")),
):
    result = await db.execute(
        select(BankAccount).where(
            BankAccount.organization_id == current_user.organization_id,
            BankAccount.is_active == True
        ).order_by(BankAccount.created_at.desc())
    )
    return [
        {
            "id": str(a.id),
            "account_name": a.account_name,
            "bank_name": a.bank_name,
            "account_number": a.account_number,
            "account_type": a.account_type,
            "current_balance": float(a.current_balance),
            "is_default": a.is_default,
        }
        for a in result.scalars().all()
    ]


# Cost Centers
class CostCenterCreate(BaseModel):
    code: str
    name: str
    parent_id: Optional[UUID] = None
    description: Optional[str] = None


@router.post("/cost-centers", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_cost_center(
    cc_data: CostCenterCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("finance:view")),
):
    existing = await db.execute(
        select(CostCenter).where(
            CostCenter.organization_id == current_user.organization_id,
            CostCenter.code == cc_data.code
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Cost center code already exists")
    
    cc = CostCenter(
        organization_id=current_user.organization_id,
        **cc_data.model_dump(),
    )
    db.add(cc)
    await db.commit()
    await db.refresh(cc)
    
    return {"id": str(cc.id), "code": cc.code, "name": cc.name}


@router.get("/cost-centers", response_model=List[dict])
async def list_cost_centers(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("finance:view")),
):
    result = await db.execute(
        select(CostCenter).where(
            CostCenter.organization_id == current_user.organization_id,
            CostCenter.is_active == True
        ).order_by(CostCenter.code)
    )
    return [
        {
            "id": str(cc.id),
            "code": cc.code,
            "name": cc.name,
            "parent_id": str(cc.parent_id) if cc.parent_id else None,
        }
        for cc in result.scalars().all()
    ]


# Financial Reports
@router.get("/reports/trial-balance")
async def get_trial_balance(
    as_of_date: date,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("report:view")),
):
    # Get all accounts with balances as of date
    accounts = await db.execute(
        select(Account).where(
            Account.organization_id == current_user.organization_id,
            Account.is_active == True
        ).order_by(Account.code)
    )
    
    report_data = []
    total_debit = 0
    total_credit = 0
    
    for account in accounts.scalars().all():
        balance = float(account.current_balance)
        debit = balance if balance > 0 else 0
        credit = -balance if balance < 0 else 0
        
        total_debit += debit
        total_credit += credit
        
        if debit > 0 or credit > 0:
            report_data.append({
                "account_code": account.code,
                "account_name": account.name,
                "account_type": account.account_type.value,
                "debit": debit,
                "credit": credit,
            })
    
    return {
        "as_of_date": as_of_date.isoformat(),
        "accounts": report_data,
        "total_debit": total_debit,
        "total_credit": total_credit,
        "is_balanced": abs(total_debit - total_credit) < 0.01,
    }


@router.get("/reports/profit-loss")
async def get_profit_loss(
    from_date: date,
    to_date: date,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("report:view")),
):
    # Get income and expense accounts
    income_accounts = await db.execute(
        select(Account).where(
            Account.organization_id == current_user.organization_id,
            Account.account_type == AccountType.INCOME,
            Account.is_active == True
        )
    )
    
    expense_accounts = await db.execute(
        select(Account).where(
            Account.organization_id == current_user.organization_id,
            Account.account_type == AccountType.EXPENSE,
            Account.is_active == True
        )
    )
    
    income_items = []
    total_income = 0
    for acc in income_accounts.scalars().all():
        balance = float(acc.current_balance)
        if balance != 0:
            income_items.append({
                "account_code": acc.code,
                "account_name": acc.name,
                "amount": balance,
            })
            total_income += balance
    
    expense_items = []
    total_expense = 0
    for acc in expense_accounts.scalars().all():
        balance = float(acc.current_balance)
        if balance != 0:
            expense_items.append({
                "account_code": acc.code,
                "account_name": acc.name,
                "amount": balance,
            })
            total_expense += balance
    
    net_profit = total_income - total_expense
    
    return {
        "from_date": from_date.isoformat(),
        "to_date": to_date.isoformat(),
        "income": income_items,
        "total_income": total_income,
        "expenses": expense_items,
        "total_expenses": total_expense,
        "net_profit": net_profit,
    }