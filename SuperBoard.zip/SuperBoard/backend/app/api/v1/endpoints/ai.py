from typing import Optional, List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_, text
from pydantic import BaseModel
from uuid import UUID
from datetime import datetime, date, timezone, timedelta
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.core.config import settings
from app.models import (
    SalesOrder, SalesOrderStatus, SalesInvoice, SalesInvoiceStatus,
    Customer, Product, Warehouse, StockBalance, StockStatus,
    Batch, PurchaseOrder, PurchaseOrderStatus, WorkOrder, WorkOrderStatus,
    Approval, ApprovalStatus, User, Organization, DeliveryNote, DeliveryNoteStatus,
    JournalEntry, Account, AccountType
)
import structlog
import json

logger = structlog.get_logger()

router = APIRouter()


# AI Tool definitions - these are the controlled functions AI can call
class AITool:
    """Base class for AI tools with permission checking"""
    
    def __init__(self, db: AsyncSession, user: User):
        self.db = db
        self.user = user
    
    async def check_permission(self, permission: str) -> bool:
        # Simplified - would check Casbin in production
        user_perms = self.user.permissions or []
        return permission in user_perms or "*" in user_perms
    
    def get_warehouse_filter(self):
        """Get warehouse IDs user has access to"""
        return self.user.assigned_warehouse_ids if self.user.assigned_warehouse_ids else []


class BusinessSummaryTool(AITool):
    """Get business summary for owner dashboard"""
    
    async def execute(self, period: str = "today") -> Dict[str, Any]:
        if not await self.check_permission("ai:query"):
            return {"error": "Permission denied"}
        
        # Determine date range
        today = date.today()
        if period == "today":
            start_date = datetime.combine(today, datetime.min.time()).replace(tzinfo=timezone.utc)
            end_date = datetime.combine(today, datetime.max.time()).replace(tzinfo=timezone.utc)
        elif period == "yesterday":
            yesterday = today - timedelta(days=1)
            start_date = datetime.combine(yesterday, datetime.min.time()).replace(tzinfo=timezone.utc)
            end_date = datetime.combine(yesterday, datetime.max.time()).replace(tzinfo=timezone.utc)
        elif period == "week":
            start_date = datetime.combine(today - timedelta(days=today.weekday()), datetime.min.time()).replace(tzinfo=timezone.utc)
            end_date = datetime.combine(today, datetime.max.time()).replace(tzinfo=timezone.utc)
        elif period == "month":
            start_date = datetime.combine(today.replace(day=1), datetime.min.time()).replace(tzinfo=timezone.utc)
            end_date = datetime.combine(today, datetime.max.time()).replace(tzinfo=timezone.utc)
        else:
            start_date = datetime.combine(today, datetime.min.time()).replace(tzinfo=timezone.utc)
            end_date = datetime.combine(today, datetime.max.time()).replace(tzinfo=timezone.utc)
        
        org_id = self.user.organization_id
        
        # Sales
        sales_result = await self.db.execute(
            select(
                func.count(SalesInvoice.id),
                func.sum(SalesInvoice.total_amount)
            ).where(
                SalesInvoice.organization_id == org_id,
                SalesInvoice.invoice_date >= start_date,
                SalesInvoice.invoice_date <= end_date,
                SalesInvoice.status == SalesInvoiceStatus.ISSUED
            )
        )
        sales_count, sales_total = sales_result.one()
        
        # Collections
        collections_result = await self.db.execute(
            select(func.sum(Payment.amount)).where(
                Payment.organization_id == org_id,
                Payment.payment_type == "receipt",
                Payment.status == PaymentStatus.COMPLETED,
                Payment.created_at >= start_date,
                Payment.created_at <= end_date
            )
        )
        collections_total = collections_result.scalar() or 0
        
        # Receivables
        receivables_result = await self.db.execute(
            select(func.sum(SalesInvoice.balance_amount)).where(
                SalesInvoice.organization_id == org_id,
                SalesInvoice.status.in_([SalesInvoiceStatus.ISSUED, SalesInvoiceStatus.PARTIAL, SalesInvoiceStatus.OVERDUE])
            )
        )
        receivables_total = receivables_result.scalar() or 0
        
        # Stock alerts
        low_stock_result = await self.db.execute(
            select(func.count(StockBalance.id.distinct())).where(
                StockBalance.organization_id == org_id,
                StockBalance.qty > 0,
                StockBalance.stock_status == StockStatus.AVAILABLE.value
            ).join(Product, StockBalance.product_id == Product.id).where(
                StockBalance.qty <= Product.reorder_level
            )
        )
        low_stock_count = low_stock_result.scalar() or 0
        
        expiry_result = await self.db.execute(
            select(func.count(Batch.id)).where(
                Batch.organization_id == org_id,
                Batch.status == "active",
                Batch.expiry_date <= datetime.now(timezone.utc) + timedelta(days=30)
            )
        )
        expiring_batches = expiry_result.scalar() or 0
        
        # Production
        production_result = await self.db.execute(
            select(
                func.count(WorkOrder.id),
                func.sum(WorkOrder.produced_qty)
            ).where(
                WorkOrder.organization_id == org_id,
                WorkOrder.planned_start_date >= start_date,
                WorkOrder.planned_start_date <= end_date,
                WorkOrder.status.in_([WorkOrderStatus.IN_PROGRESS, WorkOrderStatus.COMPLETED])
            )
        )
        production_count, production_qty = production_result.one()
        
        # Pending approvals
        approvals_result = await self.db.execute(
            select(func.count(Approval.id)).where(
                Approval.organization_id == org_id,
                Approval.status == ApprovalStatus.PENDING
            )
        )
        pending_approvals = approvals_result.scalar() or 0
        
        return {
            "period": period,
            "period_start": start_date.isoformat(),
            "period_end": end_date.isoformat(),
            "sales": {
                "invoice_count": sales_count or 0,
                "total_amount": float(sales_total or 0),
            },
            "collections": {
                "total_amount": float(collections_total),
            },
            "receivables": {
                "total_outstanding": float(receivables_total),
            },
            "inventory_alerts": {
                "low_stock_products": low_stock_count,
                "expiring_batches_30_days": expiring_batches,
            },
            "production": {
                "work_orders": production_count or 0,
                "produced_qty": float(production_qty or 0),
            },
            "pending_approvals": pending_approvals,
        }


class WarehousePerformanceTool(AITool):
    """Get warehouse performance metrics"""
    
    async def execute(self, warehouse_ids: Optional[List[UUID]] = None) -> Dict[str, Any]:
        if not await self.check_permission("ai:query"):
            return {"error": "Permission denied"}
        
        org_id = self.user.organization_id
        wh_ids = warehouse_ids or self.get_warehouse_filter()
        
        if not wh_ids:
            # Get all warehouses in org
            wh_result = await self.db.execute(
                select(Warehouse.id).where(Warehouse.organization_id == org_id)
            )
            wh_ids = [row[0] for row in wh_result.all()]
        
        results = []
        for wh_id in wh_ids:
            wh = await self.db.execute(select(Warehouse).where(Warehouse.id == wh_id))
            wh_obj = wh.scalar_one_or_none()
            
            # Stock value
            stock_result = await self.db.execute(
                select(
                    func.sum(StockBalance.qty * StockBalance.valuation_rate)
                ).where(
                    StockBalance.organization_id == org_id,
                    StockBalance.warehouse_id == wh_id,
                    StockBalance.stock_status == StockStatus.AVAILABLE.value
                )
            )
            stock_value = stock_result.scalar() or 0
            
            # Dispatches today
            today = date.today()
            dispatch_result = await self.db.execute(
                select(func.count(DeliveryNote.id)).where(
                    DeliveryNote.organization_id == org_id,
                    DeliveryNote.warehouse_id == wh_id,
                    DeliveryNote.delivery_date >= today,
                    DeliveryNote.status == DeliveryNoteStatus.DELIVERED
                )
            )
            dispatches = dispatch_result.scalar() or 0
            
            # Pending picks
            pending_result = await self.db.execute(
                select(func.count(SalesOrder.id)).where(
                    SalesOrder.organization_id == org_id,
                    SalesOrder.warehouse_id == wh_id,
                    SalesOrder.status.in_([SalesOrderStatus.APPROVED, SalesOrderStatus.PARTIALLY_FULFILLED])
                )
            )
            pending = pending_result.scalar() or 0
            
            results.append({
                "warehouse_id": str(wh_id),
                "warehouse_code": wh_obj.code if wh_obj else "",
                "warehouse_name": wh_obj.name if wh_obj else "",
                "stock_value": float(stock_value),
                "dispatches_today": dispatches,
                "pending_orders": pending,
            })
        
        return {"warehouses": results}


class TopCustomersTool(AITool):
    """Get top customers by revenue/margin/overdue"""
    
    async def execute(self, by: str = "revenue", limit: int = 10) -> Dict[str, Any]:
        if not await self.check_permission("ai:query"):
            return {"error": "Permission denied"}
        
        org_id = self.user.organization_id
        
        if by == "revenue":
            query = text("""
                SELECT c.id, c.code, c.name, 
                       SUM(si.total_amount) as total_revenue,
                       COUNT(si.id) as invoice_count
                FROM customers c
                JOIN sales_invoices si ON si.customer_id = c.id
                WHERE si.organization_id = :org_id
                  AND si.status = 'issued'
                  AND si.invoice_date >= :start_date
                GROUP BY c.id, c.code, c.name
                ORDER BY total_revenue DESC
                LIMIT :limit
            """)
        elif by == "overdue":
            query = text("""
                SELECT c.id, c.code, c.name,
                       SUM(si.balance_amount) as overdue_amount,
                       COUNT(si.id) as overdue_count
                FROM customers c
                JOIN sales_invoices si ON si.customer_id = c.id
                WHERE si.organization_id = :org_id
                  AND si.status IN ('issued', 'partial', 'overdue')
                  AND si.due_date < :today
                GROUP BY c.id, c.code, c.name
                ORDER BY overdue_amount DESC
                LIMIT :limit
            """)
        else:
            return {"error": "Invalid 'by' parameter. Use 'revenue' or 'overdue'"}
        
        today = date.today()
        start_date = today - timedelta(days=30)
        
        result = await self.db.execute(query, {"org_id": org_id, "limit": limit, "start_date": start_date, "today": today})
        
        customers = []
        for row in result.mappings().all():
            customers.append({
                "id": str(row["id"]),
                "code": row["code"],
                "name": row["name"],
                "total_revenue": float(row.get("total_revenue", 0)),
                "overdue_amount": float(row.get("overdue_amount", 0)),
                "invoice_count": row.get("invoice_count", 0),
                "overdue_count": row.get("overdue_count", 0),
            })
        
        return {"customers": customers, "sorted_by": by}


class StockAlertsTool(AITool):
    """Get stock alerts - reorder, expiry, slow moving"""
    
    async def execute(self, threshold: str = "reorder") -> Dict[str, Any]:
        if not await self.check_permission("ai:query"):
            return {"error": "Permission denied"}
        
        org_id = self.user.organization_id
        wh_filter = self.get_warehouse_filter()
        
        if threshold == "reorder":
            query = select(StockBalance, Product, Warehouse).join(
                Product, StockBalance.product_id == Product.id
            ).join(
                Warehouse, StockBalance.warehouse_id == Warehouse.id
            ).where(
                StockBalance.organization_id == org_id,
                StockBalance.qty > 0,
                StockBalance.stock_status == StockStatus.AVAILABLE.value,
                StockBalance.qty <= Product.reorder_level
            )
        elif threshold == "expiry":
            cutoff = datetime.now(timezone.utc) + timedelta(days=30)
            query = select(StockBalance, Product, Warehouse, Batch).join(
                Product, StockBalance.product_id == Product.id
            ).join(
                Warehouse, StockBalance.warehouse_id == Warehouse.id
            ).join(
                Batch, StockBalance.batch_id == Batch.id
            ).where(
                StockBalance.organization_id == org_id,
                StockBalance.qty > 0,
                StockBalance.stock_status == StockStatus.AVAILABLE.value,
                Batch.expiry_date <= cutoff,
                Batch.status == "active"
            )
        elif threshold == "slow_moving":
            # Items with no movement in 90 days
            cutoff = datetime.now(timezone.utc) - timedelta(days=90)
            query = select(StockBalance, Product, Warehouse).join(
                Product, StockBalance.product_id == Product.id
            ).join(
                Warehouse, StockBalance.warehouse_id == Warehouse.id
            ).where(
                StockBalance.organization_id == org_id,
                StockBalance.qty > 0,
                StockBalance.stock_status == StockStatus.AVAILABLE.value,
                StockBalance.last_transaction_date <= cutoff
            )
        else:
            return {"error": "Invalid threshold. Use 'reorder', 'expiry', or 'slow_moving'"}
        
        if wh_filter:
            query = query.where(StockBalance.warehouse_id.in_(wh_filter))
        
        query = query.limit(50)
        result = await self.db.execute(query)
        
        alerts = []
        for row in result.all():
            balance = row[0]
            product = row[1]
            warehouse = row[2]
            batch = row[3] if len(row) > 3 else None
            
            alert = {
                "product_id": str(product.id),
                "product_code": product.code,
                "product_name": product.name,
                "warehouse_id": str(warehouse.id),
                "warehouse_code": warehouse.code,
                "warehouse_name": warehouse.name,
                "current_qty": float(balance.qty),
                "reorder_level": float(product.reorder_level),
            }
            if batch:
                alert["batch_number"] = batch.batch_number
                alert["expiry_date"] = batch.expiry_date.isoformat() if batch.expiry_date else None
            
            alerts.append(alert)
        
        return {"alerts": alerts, "type": threshold}


class ProductionPlanTool(AITool):
    """Get production plan for a date"""
    
    async def execute(self, target_date: date) -> Dict[str, Any]:
        if not await self.check_permission("ai:query"):
            return {"error": "Permission denied"}
        
        org_id = self.user.organization_id
        
        start_dt = datetime.combine(target_date, datetime.min.time()).replace(tzinfo=timezone.utc)
        end_dt = datetime.combine(target_date, datetime.max.time()).replace(tzinfo=timezone.utc)
        
        result = await self.db.execute(
            select(WorkOrder, Product).join(
                BOMHeader, WorkOrder.bom_id == BOMHeader.id
            ).join(
                Product, BOMHeader.finished_product_id == Product.id
            ).where(
                WorkOrder.organization_id == org_id,
                WorkOrder.planned_start_date <= end_dt,
                WorkOrder.planned_end_date >= start_dt,
                WorkOrder.status.in_([WorkOrderStatus.PLANNED, WorkOrderStatus.RELEASED, WorkOrderStatus.IN_PROGRESS])
            )
        )
        
        plan = []
        for wo, product in result.all():
            plan.append({
                "work_order_id": str(wo.id),
                "work_order_number": wo.work_order_number,
                "product_code": product.code,
                "product_name": product.name,
                "planned_qty": float(wo.planned_qty),
                "produced_qty": float(wo.produced_qty),
                "status": wo.status.value,
                "priority": wo.priority.value,
            })
        
        return {"date": target_date.isoformat(), "work_orders": plan}


class PendingApprovalsTool(AITool):
    """Get pending approvals for a department"""
    
    async def execute(self, department: Optional[str] = None) -> Dict[str, Any]:
        if not await self.check_permission("ai:query"):
            return {"error": "Permission denied"}
        
        org_id = self.user.organization_id
        
        query = select(Approval).where(
            Approval.organization_id == org_id,
            Approval.status == ApprovalStatus.PENDING
        )
        
        if department:
            query = query.where(Approval.approver_role == department)
        
        query = query.order_by(Approval.created_at).limit(50)
        result = await self.db.execute(query)
        
        approvals = []
        for a in result.scalars().all():
            approvals.append({
                "id": str(a.id),
                "approval_number": a.approval_number,
                "type": a.approval_type.value,
                "title": a.title,
                "reference_doctype": a.reference_doctype,
                "reference_docname": a.reference_docname,
                "requested_by": str(a.requested_by),
                "approver_role": a.approver_role,
                "created_at": a.created_at.isoformat(),
                "due_date": a.due_date.isoformat() if a.due_date else None,
            })
        
        return {"pending_approvals": approvals, "count": len(approvals)}


class PreparePurchaseDraftTool(AITool):
    """Prepare purchase order draft for items below reorder level"""
    
    async def execute(self) -> Dict[str, Any]:
        if not await self.check_permission("ai:action"):
            return {"error": "Permission denied"}
        
        org_id = self.user.organization_id
        wh_filter = self.get_warehouse_filter()
        
        # Find products below reorder level
        query = select(StockBalance, Product, Warehouse).join(
            Product, StockBalance.product_id == Product.id
        ).join(
            Warehouse, StockBalance.warehouse_id == Warehouse.id
        ).where(
            StockBalance.organization_id == org_id,
            StockBalance.qty > 0,
            StockBalance.stock_status == StockStatus.AVAILABLE.value,
            StockBalance.qty <= Product.reorder_level,
            Product.is_purchasable == True
        )
        
        if wh_filter:
            query = query.where(StockBalance.warehouse_id.in_(wh_filter))
        
        result = await self.db.execute(query.limit(20))
        
        items = []
        for balance, product, warehouse in result.all():
            # Get preferred supplier
            # For now, use a default supplier or first active supplier
            supplier_result = await self.db.execute(
                select(Supplier).where(
                    Supplier.organization_id == org_id,
                    Supplier.is_active == True
                ).limit(1)
            )
            supplier = supplier_result.scalar_one_or_none()
            
            # Calculate order qty (reorder_qty or to max level)
            order_qty = product.reorder_qty if product.reorder_qty > 0 else (product.max_stock_level - float(balance.qty))
            if order_qty <= 0:
                order_qty = product.max_stock_level if product.max_stock_level > 0 else 100
            
            # Get supplier price
            price = product.standard_cost if product.standard_cost > 0 else 100
            
            items.append({
                "product_id": str(product.id),
                "product_code": product.code,
                "product_name": product.name,
                "warehouse_id": str(warehouse.id),
                "warehouse_name": warehouse.name,
                "current_stock": float(balance.qty),
                "reorder_level": float(product.reorder_level),
                "suggested_qty": float(order_qty),
                "supplier_id": str(supplier.id) if supplier else None,
                "supplier_name": supplier.name if supplier else "No supplier assigned",
                "estimated_rate": float(price),
                "estimated_amount": float(order_qty * price),
            })
        
        total_amount = sum(item["estimated_amount"] for item in items)
        
        return {
            "items": items,
            "total_items": len(items),
            "total_estimated_amount": total_amount,
            "message": f"Prepared draft for {len(items)} items needing replenishment",
        }


# AI Chat endpoint
class AIChatRequest(BaseModel):
    message: str
    context: Optional[Dict[str, Any]] = None


class AIChatResponse(BaseModel):
    response: str
    tools_used: List[str] = []
    tool_results: List[Dict[str, Any]] = []
    requires_approval: bool = False
    approval_data: Optional[Dict[str, Any]] = None


@router.post("/chat", response_model=AIChatResponse)
async def ai_chat(
    request: AIChatRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Main AI chat endpoint with tool calling"""
    
    message = request.message.lower()
    tools_used = []
    tool_results = []
    requires_approval = False
    approval_data = None
    
    # Simple intent detection
    if any(kw in message for kw in ["business", "performance", "how did we do", "summary", "dashboard"]):
        tool = BusinessSummaryTool(db, current_user)
        result = await tool.execute("today")
        tools_used.append("business_summary")
        tool_results.append(result)
        
        response = f"""Business Summary for Today:
- Sales: {result['sales']['invoice_count']} invoices, ₹{result['sales']['total_amount']:,.2f}
- Collections: ₹{result['collections']['total_amount']:,.2f}
- Outstanding Receivables: ₹{result['receivables']['total_outstanding']:,.2f}
- Low Stock Alerts: {result['inventory_alerts']['low_stock_products']} products
- Expiring Batches (30 days): {result['inventory_alerts']['expiring_batches_30_days']}
- Production: {result['production']['work_orders']} work orders, {result['production']['produced_qty']:.2f} units
- Pending Approvals: {result['pending_approvals']}"""
    
    elif any(kw in message for kw in ["warehouse", "stock", "inventory", "stock balance"]):
        if "alert" in message or "reorder" in message or "low stock" in message:
            tool = StockAlertsTool(db, current_user)
            result = await tool.execute("reorder")
            tools_used.append("stock_alerts_reorder")
        elif "expiry" in message or "expiring" in message:
            tool = StockAlertsTool(db, current_user)
            result = await tool.execute("expiry")
            tools_used.append("stock_alerts_expiry")
        else:
            tool = WarehousePerformanceTool(db, current_user)
            result = await tool.execute()
            tools_used.append("warehouse_performance")
        
        tool_results.append(result)
        
        if "alerts" in result:
            response = f"Found {len(result['alerts'])} stock alerts:\n"
            for alert in result['alerts'][:10]:
                response += f"- {alert['product_code']} ({alert['product_name']}) at {alert['warehouse_code']}: {alert['current_qty']} (reorder at {alert['reorder_level']})\n"
        else:
            response = f"Warehouse Performance:\n"
            for wh in result.get('warehouses', []):
                response += f"- {wh['warehouse_code']}: Stock ₹{wh['stock_value']:,.2f}, {wh['dispatches_today']} dispatches, {wh['pending_orders']} pending\n"
    
    elif any(kw in message for kw in ["customer", "top customer", "overdue", "receivables"]):
        if "overdue" in message:
            tool = TopCustomersTool(db, current_user)
            result = await tool.execute("overdue", 10)
        else:
            tool = TopCustomersTool(db, current_user)
            result = await tool.execute("revenue", 10)
        
        tools_used.append("top_customers")
        tool_results.append(result)
        
        response = f"Top 10 Customers by {'Overdue' if 'overdue' in message else 'Revenue'}:\n"
        for c in result['customers'][:10]:
            if 'overdue' in message:
                response += f"- {c['code']} {c['name']}: ₹{c['overdue_amount']:,.2f} overdue ({c['overdue_count']} invoices)\n"
            else:
                response += f"- {c['code']} {c['name']}: ₹{c['total_revenue']:,.2f} ({c['invoice_count']} invoices)\n"
    
    elif any(kw in message for kw in ["production", "manufacturing", "work order", "produce"]):
        if "tomorrow" in message:
            target_date = date.today() + timedelta(days=1)
        elif "today" in message:
            target_date = date.today()
        else:
            target_date = date.today()
        
        tool = ProductionPlanTool(db, current_user)
        result = await tool.execute(target_date)
        tools_used.append("production_plan")
        tool_results.append(result)
        
        response = f"Production Plan for {target_date}:\n"
        for wo in result['work_orders']:
            response += f"- {wo['work_order_number']}: {wo['product_code']} ({wo['product_name']}) - Plan: {wo['planned_qty']}, Produced: {wo['produced_qty']} - {wo['status']}\n"
        if not result['work_orders']:
            response += "No work orders scheduled."
    
    elif any(kw in message for kw in ["approval", "pending approval", "approve"]):
        tool = PendingApprovalsTool(db, current_user)
        result = await tool.execute()
        tools_used.append("pending_approvals")
        tool_results.append(result)
        
        response = f"Pending Approvals ({result['count']}):\n"
        for a in result['pending_approvals'][:10]:
            response += f"- {a['approval_number']}: {a['title']} ({a['type']}) - Due: {a['due_date']}\n"
        if not result['pending_approvals']:
            response = "No pending approvals."
    
    elif any(kw in message for kw in ["purchase", "buy", "reorder", "replenish"]):
        tool = PreparePurchaseDraftTool(db, current_user)
        result = await tool.execute()
        tools_used.append("prepare_purchase_draft")
        tool_results.append(result)
        
        requires_approval = True
        approval_data = {
            "type": "purchase_order",
            "items": result['items'],
            "total_amount": result['total_estimated_amount'],
        }
        
        response = f"{result['message']}\nTotal estimated amount: ₹{result['total_estimated_amount']:,.2f}\n\nThis requires purchase manager approval. Shall I create the draft purchase order?"
    
    else:
        # Default response
        response = """I can help you with:
- Business summary (sales, collections, receivables, production)
- Warehouse performance and stock alerts
- Top customers by revenue or overdue amounts
- Production plans
- Pending approvals
- Purchase order drafts for replenishment

Try asking: "How did business perform today?", "Show me low stock alerts", "Who are my top customers?", "What's the production plan for tomorrow?", "Show pending approvals", "Prepare purchase order for low stock items"."""
    
    return AIChatResponse(
        response=response,
        tools_used=tools_used,
        tool_results=tool_results,
        requires_approval=requires_approval,
        approval_data=approval_data,
    )


# Morning report endpoint
@router.get("/morning-report")
async def get_morning_report(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Generate morning business report for owner"""
    
    if not await BusinessSummaryTool(db, current_user).check_permission("ai:query"):
        raise HTTPException(status_code=403, detail="Permission denied")
    
    # Get yesterday's summary
    tool = BusinessSummaryTool(db, current_user)
    summary = await tool.execute("yesterday")
    
    # Get stock alerts
    stock_tool = StockAlertsTool(db, current_user)
    reorder_alerts = await stock_tool.execute("reorder")
    expiry_alerts = await stock_tool.execute("expiry")
    
    # Get overdue customers
    customer_tool = TopCustomersTool(db, current_user)
    overdue = await customer_tool.execute("overdue", 5)
    
    # Get pending approvals
    approval_tool = PendingApprovalsTool(db, current_user)
    approvals = await approval_tool.execute()
    
    # Get production plan for today
    prod_tool = ProductionPlanTool(db, current_user)
    production = await prod_tool.execute(date.today())
    
    report = f"""
╔══════════════════════════════════════════════════════════════════╗
║                    MORNING BUSINESS REPORT                       ║
║                         {date.today().strftime('%d %B %Y')}                          ║
╠══════════════════════════════════════════════════════════════════╣
║  YESTERDAY'S PERFORMANCE                                         ║
║  ────────────────────────                                        ║
║  Sales Invoices: {summary['sales']['invoice_count']:>3} | Revenue: ₹{summary['sales']['total_amount']:>12,.2f}  ║
║  Collections:      ₹{summary['collections']['total_amount']:>12,.2f}                           ║
║  Outstanding AR:   ₹{summary['receivables']['total_outstanding']:>12,.2f}                           ║
╠══════════════════════════════════════════════════════════════════╣
║  INVENTORY ALERTS                                                ║
║  ─────────────────────                                           ║
║  Low Stock Products:      {len(reorder_alerts.get('alerts', [])):>3}                              ║
║  Expiring Batches (30d):  {len(expiry_alerts.get('alerts', [])):>3}                              ║
╠══════════════════════════════════════════════════════════════════╣
║  TOP OVERDUE CUSTOMERS                                         ║
║  ──────────────────────────                                    ║
"""
    
    for c in overdue.get('customers', [])[:5]:
        report += f"║  {c['code'][:15]:<15} {c['name'][:25]:<25} ₹{c['overdue_amount']:>10,.2f} ║\n"
    
    report += f"""╠══════════════════════════════════════════════════════════════════╣
║  TODAY'S PRODUCTION PLAN                                       ║
║  ──────────────────────────────                                ║
║  Work Orders: {len(production.get('work_orders', [])):>3}                                          ║
"""
    
    for wo in production.get('work_orders', [])[:5]:
        report += f"║  {wo['work_order_number'][:30]:<30} {wo['product_code'][:15]:<15} ║\n"
    
    report += f"""╠══════════════════════════════════════════════════════════════════╣
║  PENDING APPROVALS ({approvals['count']:>2})                                               ║
║  ──────────────────────────────                                ║
"""
    
    for a in approvals.get('pending_approvals', [])[:5]:
        report += f"║  {a['approval_number'][:20]:<20} {a['title'][:35]:<35} ║\n"
    
    report += "╚══════════════════════════════════════════════════════════════════╝"
    
    return {"report": report, "data": {
        "summary": summary,
        "reorder_alerts": reorder_alerts,
        "expiry_alerts": expiry_alerts,
        "overdue_customers": overdue,
        "pending_approvals": approvals,
        "production_plan": production,
    }}