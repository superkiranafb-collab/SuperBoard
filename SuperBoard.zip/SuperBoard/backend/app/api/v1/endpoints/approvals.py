from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
from uuid import UUID
from datetime import datetime, timezone
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.models import (
    Approval, ApprovalStatus, ApprovalType,
    User, Organization
)
import structlog

logger = structlog.get_logger()

router = APIRouter()


# Approval configuration - defines what requires approval and who can approve
APPROVAL_CONFIG = {
    ApprovalType.DISCOUNT: {
        "limit_field": "discount_percent",
        "approver_roles": ["sales_supervisor", "department_head", "owner"],
        "limits": {
            "salesperson": 5,
            "sales_supervisor": 10,
            "department_head": 15,
            "owner": 100,
        }
    },
    ApprovalType.CREDIT_LIMIT: {
        "limit_field": "credit_limit",
        "approver_roles": ["accountant", "department_head", "owner"],
        "limits": {
            "accountant": 100000,
            "department_head": 500000,
            "owner": 10000000,
        }
    },
    ApprovalType.STOCK_ADJUSTMENT: {
        "limit_field": "adjustment_qty",
        "approver_roles": ["warehouse_manager", "department_head", "owner"],
    },
    ApprovalType.PURCHASE_ORDER: {
        "limit_field": "total_amount",
        "approver_roles": ["department_head", "owner"],
        "limits": {
            "department_head": 500000,
            "owner": 10000000,
        }
    },
    ApprovalType.PAYMENT: {
        "limit_field": "amount",
        "approver_roles": ["accountant", "department_head", "owner"],
        "limits": {
            "accountant": 100000,
            "department_head": 500000,
            "owner": 10000000,
        }
    },
    ApprovalType.BATCH_RELEASE: {
        "limit_field": "released_qty",
        "approver_roles": ["quality_supervisor", "production_manager", "owner"],
    },
    ApprovalType.LEAVE: {
        "approver_roles": ["hr_manager", "department_head"],
    },
    ApprovalType.EXPENSE: {
        "limit_field": "total_amount",
        "approver_roles": ["accountant", "department_head", "owner"],
        "limits": {
            "accountant": 50000,
            "department_head": 200000,
            "owner": 1000000,
        }
    },
    ApprovalType.WORK_ORDER: {
        "limit_field": "planned_qty",
        "approver_roles": ["production_manager", "department_head", "owner"],
    },
    ApprovalType.PRICE_CHANGE: {
        "approver_roles": ["department_head", "owner"],
    },
}


def get_approver_for_request(approval_type: ApprovalType, amount: float, requester_role: str) -> tuple:
    """Determine who should approve based on amount and requester role."""
    config = APPROVAL_CONFIG.get(approval_type, {})
    limits = config.get("limits", {})
    approver_roles = config.get("approver_roles", ["owner"])
    
    requester_limit = limits.get(requester_role, 0)
    
    # If amount is within requester's limit, no approval needed
    if amount <= requester_limit:
        return None, None
    
    # Find first approver with sufficient limit
    for role in approver_roles:
        role_limit = limits.get(role, float('inf'))
        if amount <= role_limit:
            return role, role_limit
    
    # Default to owner
    return "owner", limits.get("owner", float('inf'))


@router.post("/check-required")
async def check_approval_required(
    approval_type: ApprovalType,
    amount: float,
    requester_role: str = "salesperson",
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    """Check if approval is required for a given action."""
    config = APPROVAL_CONFIG.get(approval_type, {})
    limits = config.get("limits", {})
    requester_limit = limits.get(requester_role, 0)
    
    if amount <= requester_limit:
        return {"approval_required": False, "approver_role": None, "limit": requester_limit}
    
    for role in config.get("approver_roles", ["owner"]):
        role_limit = limits.get(role, float('inf'))
        if amount <= role_limit:
            return {
                "approval_required": True,
                "approver_role": role,
                "requester_limit": requester_limit,
                "approver_limit": role_limit,
            }
    
    return {
        "approval_required": True,
        "approver_role": "owner",
        "requester_limit": requester_limit,
        "approver_limit": limits.get("owner", float('inf')),
    }


class ApprovalCreate(BaseModel):
    approval_type: ApprovalType
    title: str
    description: Optional[str] = None
    reference_doctype: str
    reference_doc_id: UUID
    reference_docname: Optional[str] = None
    approval_limit: Optional[float] = None


@router.post("", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_approval_request(
    approval_data: ApprovalCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    # Generate approval number
    today = date.today()
    prefix = f"APR-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(Approval.id)).where(
            Approval.organization_id == current_user.organization_id,
            Approval.approval_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    approval_number = f"{prefix}{seq:04d}"
    
    # Determine approver role
    config = APPROVAL_CONFIG.get(approval_data.approval_type, {})
    approver_role = config.get("approver_roles", ["owner"])[0]
    
    # Find user with that role (simplified - would query user_roles table)
    approver = await db.execute(
        select(User).where(
            User.organization_id == current_user.organization_id,
            User.department == approver_role  # Simplified
        )
    )
    approver_user = approver.scalar_one_or_none()
    
    approval = Approval(
        organization_id=current_user.organization_id,
        approval_number=approval_number,
        approval_type=approval_data.approval_type,
        status=ApprovalStatus.PENDING,
        title=approval_data.title,
        description=approval_data.description,
        reference_doctype=approval_data.reference_doctype,
        reference_doc_id=approval_data.reference_doc_id,
        reference_docname=approval_data.reference_docname,
        requested_by=current_user.id,
        approver_id=approver_user.id if approver_user else None,
        approver_role=approver_role,
        approval_limit=approval_data.approval_limit,
        due_date=datetime.now(timezone.utc) + timedelta(days=1),
        created_by=current_user.id,
    )
    db.add(approval)
    await db.commit()
    
    logger.info("approval_created", approval_id=str(approval.id), type=approval_data.approval_type.value)
    
    return {"id": str(approval.id), "approval_number": approval_number, "status": approval.status.value}


@router.get("", response_model=List[dict])
async def list_approvals(
    status: Optional[ApprovalStatus] = None,
    approval_type: Optional[ApprovalType] = None,
    approver_id: Optional[UUID] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("approval:view")),
):
    query = select(Approval).where(Approval.organization_id == current_user.organization_id)
    
    # Filter by user's role
    if "owner" not in current_user.roles and "department_head" not in current_user.roles:
        # Show approvals where user is requester or approver
        query = query.where(
            (Approval.requested_by == current_user.id) | 
            (Approval.approver_id == current_user.id)
        )
    elif approver_id:
        query = query.where(Approval.approver_id == approver_id)
    
    if status:
        query = query.where(Approval.status == status)
    if approval_type:
        query = query.where(Approval.approval_type == approval_type)
    
    query = query.order_by(Approval.created_at.desc()).limit(100)
    result = await db.execute(query)
    approvals = result.scalars().all()
    
    return [
        {
            "id": str(a.id),
            "approval_number": a.approval_number,
            "approval_type": a.approval_type.value,
            "status": a.status.value,
            "title": a.title,
            "reference_doctype": a.reference_doctype,
            "reference_docname": a.reference_docname,
            "requested_by": str(a.requested_by),
            "approver_id": str(a.approver_id) if a.approver_id else None,
            "approver_role": a.approver_role,
            "created_at": a.created_at.isoformat(),
            "due_date": a.due_date.isoformat() if a.due_date else None,
        }
        for a in approvals
    ]


@router.post("/{approval_id}/decide")
async def decide_approval(
    approval_id: UUID,
    decision: str,  # "approved" or "rejected"
    decision_notes: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("approval:decide")),
):
    result = await db.execute(
        select(Approval).where(
            Approval.id == approval_id,
            Approval.organization_id == current_user.organization_id
        )
    )
    approval = result.scalar_one_or_none()
    
    if not approval:
        raise HTTPException(status_code=404, detail="Approval not found")
    
    if approval.status != ApprovalStatus.PENDING:
        raise HTTPException(status_code=400, detail="Approval already decided")
    
    # Check if current user is authorized to approve
    if approval.approver_id and approval.approver_id != current_user.id:
        # Check if user has higher role
        pass  # Simplified
    
    approval.status = ApprovalStatus.APPROVED if decision == "approved" else ApprovalStatus.REJECTED
    approval.decided_by = current_user.id
    approval.decided_at = datetime.now(timezone.utc)
    approval.decision = decision
    approval.decision_notes = decision_notes
    
    await db.commit()
    
    # Update the referenced document status
    # This would be implemented based on reference_doctype
    
    logger.info("approval_decided", approval_id=str(approval_id), decision=decision)
    
    return {"message": f"Approval {decision}", "status": approval.status.value}


@router.get("/pending-count")
async def get_pending_approvals_count(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    # Count pending approvals for current user as approver
    count_result = await db.execute(
        select(func.count(Approval.id)).where(
            Approval.organization_id == current_user.organization_id,
            Approval.status == ApprovalStatus.PENDING,
            Approval.approver_id == current_user.id
        )
    )
    count = count_result.scalar() or 0
    
    return {"pending_count": count}