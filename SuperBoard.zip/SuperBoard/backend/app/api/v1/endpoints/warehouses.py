from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from uuid import UUID
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.models import Warehouse, WarehouseType, Organization, Rack, Shelf, Bin
import structlog

logger = structlog.get_logger()

router = APIRouter()


class WarehouseBase(BaseModel):
    code: str
    name: str
    type: WarehouseType = WarehouseType.FINISHED_GOODS
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    manager_id: Optional[UUID] = None
    allow_negative_stock: bool = False


class WarehouseCreate(WarehouseBase):
    pass


class WarehouseUpdate(BaseModel):
    code: Optional[str] = None
    name: Optional[str] = None
    type: Optional[WarehouseType] = None
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    manager_id: Optional[UUID] = None
    is_active: Optional[bool] = None
    allow_negative_stock: Optional[bool] = None


class WarehouseResponse(WarehouseBase):
    id: UUID
    organization_id: UUID
    is_active: bool
    settings: dict
    created_at: str
    updated_at: str
    manager_name: Optional[str] = None
    
    class Config:
        from_attributes = True


class WarehouseListResponse(BaseModel):
    items: List[WarehouseResponse]
    total: int
    page: int
    page_size: int
    total_pages: int


@router.post("", response_model=WarehouseResponse, status_code=status.HTTP_201_CREATED)
async def create_warehouse(
    wh_data: WarehouseCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("warehouse:create")),
):
    # Check code uniqueness within organization
    existing = await db.execute(
        select(Warehouse).where(
            Warehouse.organization_id == current_user.organization_id,
            Warehouse.code == wh_data.code
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Warehouse code already exists in this organization")
    
    warehouse = Warehouse(
        **wh_data.model_dump(),
        organization_id=current_user.organization_id,
        created_by=current_user.id,
    )
    db.add(warehouse)
    await db.commit()
    await db.refresh(warehouse)
    
    logger.info("warehouse_created", warehouse_id=str(warehouse.id), code=warehouse.code)
    return warehouse


@router.get("", response_model=WarehouseListResponse)
async def list_warehouses(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    type: Optional[WarehouseType] = None,
    is_active: Optional[bool] = None,
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("warehouse:view")),
):
    query = select(Warehouse).where(Warehouse.organization_id == current_user.organization_id)
    
    if type:
        query = query.where(Warehouse.type == type)
    if is_active is not None:
        query = query.where(Warehouse.is_active == is_active)
    if search:
        query = query.where(
            Warehouse.name.ilike(f"%{search}%") | 
            Warehouse.code.ilike(f"%{search}%")
        )
    
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(Warehouse.created_at.desc())
    result = await db.execute(query)
    items = result.scalars().all()
    
    # Enrich with manager names
    response_items = []
    for item in items:
        manager_name = None
        if item.manager_id:
            manager = await db.execute(select(User).where(User.id == item.manager_id))
            mgr = manager.scalar_one_or_none()
            if mgr:
                manager_name = mgr.full_name
        
        response_items.append(WarehouseResponse(
            **item.__dict__,
            manager_name=manager_name
        ))
    
    return WarehouseListResponse(
        items=response_items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=(total + page_size - 1) // page_size,
    )


@router.get("/{warehouse_id}", response_model=WarehouseResponse)
async def get_warehouse(
    warehouse_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("warehouse:view")),
):
    result = await db.execute(
        select(Warehouse).where(
            Warehouse.id == warehouse_id,
            Warehouse.organization_id == current_user.organization_id
        )
    )
    warehouse = result.scalar_one_or_none()
    
    if not warehouse:
        raise HTTPException(status_code=404, detail="Warehouse not found")
    
    manager_name = None
    if warehouse.manager_id:
        manager = await db.execute(select(User).where(User.id == warehouse.manager_id))
        mgr = manager.scalar_one_or_none()
        if mgr:
            manager_name = mgr.full_name
    
    return WarehouseResponse(
        **warehouse.__dict__,
        manager_name=manager_name
    )


@router.put("/{warehouse_id}", response_model=WarehouseResponse)
async def update_warehouse(
    warehouse_id: UUID,
    wh_data: WarehouseUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("warehouse:update")),
):
    result = await db.execute(
        select(Warehouse).where(
            Warehouse.id == warehouse_id,
            Warehouse.organization_id == current_user.organization_id
        )
    )
    warehouse = result.scalar_one_or_none()
    
    if not warehouse:
        raise HTTPException(status_code=404, detail="Warehouse not found")
    
    update_data = wh_data.model_dump(exclude_unset=True)
    
    # Check code uniqueness if changing
    if "code" in update_data:
        existing = await db.execute(
            select(Warehouse).where(
                Warehouse.organization_id == current_user.organization_id,
                Warehouse.code == update_data["code"],
                Warehouse.id != warehouse_id
            )
        )
        if existing.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="Warehouse code already exists")
    
    for field, value in update_data.items():
        setattr(warehouse, field, value)
    
    await db.commit()
    await db.refresh(warehouse)
    
    logger.info("warehouse_updated", warehouse_id=str(warehouse.id))
    return warehouse


@router.delete("/{warehouse_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_warehouse(
    warehouse_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("warehouse:delete")),
):
    result = await db.execute(
        select(Warehouse).where(
            Warehouse.id == warehouse_id,
            Warehouse.organization_id == current_user.organization_id
        )
    )
    warehouse = result.scalar_one_or_none()
    
    if not warehouse:
        raise HTTPException(status_code=404, detail="Warehouse not found")
    
    # Check for stock
    from app.models.inventory import StockBalance
    stock = await db.execute(
        select(StockBalance).where(StockBalance.warehouse_id == warehouse_id)
    )
    if stock.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Cannot delete warehouse with existing stock")
    
    warehouse.is_active = False
    await db.commit()
    
    logger.info("warehouse_deleted", warehouse_id=str(warehouse_id))


# Rack endpoints
class RackBase(BaseModel):
    code: str
    name: Optional[str] = None
    description: Optional[str] = None


class RackCreate(RackBase):
    pass


class RackResponse(RackBase):
    id: UUID
    warehouse_id: UUID
    is_active: bool
    created_at: str
    
    class Config:
        from_attributes = True


@router.post("/{warehouse_id}/racks", response_model=RackResponse, status_code=status.HTTP_201_CREATED)
async def create_rack(
    warehouse_id: UUID,
    rack_data: RackCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("warehouse:update")),
):
    # Verify warehouse exists
    wh = await db.execute(
        select(Warehouse).where(
            Warehouse.id == warehouse_id,
            Warehouse.organization_id == current_user.organization_id
        )
    )
    if not wh.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Warehouse not found")
    
    existing = await db.execute(
        select(Rack).where(Rack.warehouse_id == warehouse_id, Rack.code == rack_data.code)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Rack code already exists in this warehouse")
    
    rack = Rack(
        **rack_data.model_dump(),
        warehouse_id=warehouse_id,
    )
    db.add(rack)
    await db.commit()
    await db.refresh(rack)
    
    return rack


@router.get("/{warehouse_id}/racks", response_model=List[RackResponse])
async def list_racks(
    warehouse_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("warehouse:view")),
):
    result = await db.execute(
        select(Rack).where(
            Rack.warehouse_id == warehouse_id,
            Rack.is_active == True
        ).order_by(Rack.code)
    )
    return result.scalars().all()


# Shelf endpoints
class ShelfBase(BaseModel):
    code: str
    name: Optional[str] = None


class ShelfCreate(ShelfBase):
    pass


class ShelfResponse(ShelfBase):
    id: UUID
    rack_id: UUID
    is_active: bool
    created_at: str
    
    class Config:
        from_attributes = True


@router.post("/racks/{rack_id}/shelves", response_model=ShelfResponse, status_code=status.HTTP_201_CREATED)
async def create_shelf(
    rack_id: UUID,
    shelf_data: ShelfCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("warehouse:update")),
):
    rack = await db.execute(
        select(Rack).where(Rack.id == rack_id)
    )
    if not rack.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Rack not found")
    
    existing = await db.execute(
        select(Shelf).where(Shelf.rack_id == rack_id, Shelf.code == shelf_data.code)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Shelf code already exists in this rack")
    
    shelf = Shelf(
        **shelf_data.model_dump(),
        rack_id=rack_id,
    )
    db.add(shelf)
    await db.commit()
    await db.refresh(shelf)
    
    return shelf


@router.get("/racks/{rack_id}/shelves", response_model=List[ShelfResponse])
async def list_shelves(
    rack_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("warehouse:view")),
):
    result = await db.execute(
        select(Shelf).where(
            Shelf.rack_id == rack_id,
            Shelf.is_active == True
        ).order_by(Shelf.code)
    )
    return result.scalars().all()


# Bin endpoints
class BinBase(BaseModel):
    code: str
    name: Optional[str] = None
    max_capacity: Optional[float] = None


class BinCreate(BinBase):
    pass


class BinResponse(BinBase):
    id: UUID
    shelf_id: UUID
    is_active: bool
    created_at: str
    
    class Config:
        from_attributes = True


@router.post("/shelves/{shelf_id}/bins", response_model=BinResponse, status_code=status.HTTP_201_CREATED)
async def create_bin(
    shelf_id: UUID,
    bin_data: BinCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("warehouse:update")),
):
    shelf = await db.execute(
        select(Shelf).where(Shelf.id == shelf_id)
    )
    if not shelf.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Shelf not found")
    
    existing = await db.execute(
        select(Bin).where(Bin.shelf_id == shelf_id, Bin.code == bin_data.code)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Bin code already exists in this shelf")
    
    bin_obj = Bin(
        **bin_data.model_dump(),
        shelf_id=shelf_id,
    )
    db.add(bin_obj)
    await db.commit()
    await db.refresh(bin_obj)
    
    return bin_obj


@router.get("/shelves/{shelf_id}/bins", response_model=List[BinResponse])
async def list_bins(
    shelf_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("warehouse:view")),
):
    result = await db.execute(
        select(Bin).where(
            Bin.shelf_id == shelf_id,
            Bin.is_active == True
        ).order_by(Bin.code)
    )
    return result.scalars().all()