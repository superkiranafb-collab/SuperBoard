from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_
from pydantic import BaseModel, EmailStr
from uuid import UUID
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.models import (
    Customer, CustomerChannel, CustomerAddress, CustomerContact,
    PriceList, User, Warehouse
)
import structlog

logger = structlog.get_logger()

router = APIRouter()


class CustomerAddressBase(BaseModel):
    address_type: str
    name: str
    contact_person: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[EmailStr] = None
    address_line1: str
    address_line2: Optional[str] = None
    city: str
    state: str
    pincode: str
    country: str = "India"
    gstin: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    is_default: bool = False


class CustomerAddressCreate(CustomerAddressBase):
    pass


class CustomerAddressResponse(CustomerAddressBase):
    id: UUID
    customer_id: UUID
    is_active: bool
    created_at: str
    
    class Config:
        from_attributes = True


class CustomerContactBase(BaseModel):
    name: str
    designation: Optional[str] = None
    phone: Optional[str] = None
    mobile: Optional[str] = None
    email: Optional[EmailStr] = None
    department: Optional[str] = None
    is_primary: bool = False


class CustomerContactCreate(CustomerContactBase):
    pass


class CustomerContactResponse(CustomerContactBase):
    id: UUID
    customer_id: UUID
    is_active: bool
    created_at: str
    
    class Config:
        from_attributes = True


class CustomerBase(BaseModel):
    channel: CustomerChannel = CustomerChannel.RETAIL
    code: str
    name: str
    trade_name: Optional[str] = None
    gstin: Optional[str] = None
    pan: Optional[str] = None
    customer_type: Optional[str] = None
    credit_limit: float = 0
    credit_days: int = 30
    price_list_id: Optional[UUID] = None
    assigned_salesperson_id: Optional[UUID] = None
    assigned_warehouse_id: Optional[UUID] = None
    payment_terms: Optional[str] = None


class CustomerCreate(CustomerBase):
    addresses: List[CustomerAddressCreate] = []
    contacts: List[CustomerContactCreate] = []


class CustomerUpdate(BaseModel):
    channel: Optional[CustomerChannel] = None
    name: Optional[str] = None
    trade_name: Optional[str] = None
    gstin: Optional[str] = None
    pan: Optional[str] = None
    customer_type: Optional[str] = None
    credit_limit: Optional[float] = None
    credit_days: Optional[int] = None
    price_list_id: Optional[UUID] = None
    assigned_salesperson_id: Optional[UUID] = None
    assigned_warehouse_id: Optional[UUID] = None
    payment_terms: Optional[str] = None
    is_active: Optional[bool] = None
    is_blocked: Optional[bool] = None
    block_reason: Optional[str] = None


class CustomerResponse(CustomerBase):
    id: UUID
    organization_id: UUID
    is_active: bool
    is_blocked: bool
    block_reason: Optional[str]
    created_at: str
    updated_at: str
    addresses: List[CustomerAddressResponse] = []
    contacts: List[CustomerContactResponse] = []
    price_list_name: Optional[str] = None
    salesperson_name: Optional[str] = None
    warehouse_name: Optional[str] = None
    
    class Config:
        from_attributes = True


class CustomerListResponse(BaseModel):
    items: List[CustomerResponse]
    total: int
    page: int
    page_size: int
    total_pages: int


@router.post("", response_model=CustomerResponse, status_code=status.HTTP_201_CREATED)
async def create_customer(
    customer_data: CustomerCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("customer:create")),
):
    existing = await db.execute(
        select(Customer).where(
            Customer.organization_id == current_user.organization_id,
            Customer.code == customer_data.code
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Customer code already exists")
    
    if customer_data.gstin:
        existing_gstin = await db.execute(
            select(Customer).where(
                Customer.organization_id == current_user.organization_id,
                Customer.gstin == customer_data.gstin
            )
        )
        if existing_gstin.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="GSTIN already registered")
    
    addresses_data = customer_data.addresses
    contacts_data = customer_data.contacts
    
    customer = Customer(
        **customer_data.model_dump(exclude={"addresses", "contacts"}),
        organization_id=current_user.organization_id,
        created_by=current_user.id,
    )
    db.add(customer)
    await db.flush()
    
    # Add addresses
    for addr_data in addresses_data:
        address = CustomerAddress(
            **addr_data.model_dump(),
            customer_id=customer.id,
        )
        db.add(address)
    
    # Add contacts
    for contact_data in contacts_data:
        contact = CustomerContact(
            **contact_data.model_dump(),
            customer_id=customer.id,
        )
        db.add(contact)
    
    await db.commit()
    await db.refresh(customer)
    
    logger.info("customer_created", customer_id=str(customer.id), code=customer.code)
    return customer


@router.get("", response_model=CustomerListResponse)
async def list_customers(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    channel: Optional[CustomerChannel] = None,
    is_active: Optional[bool] = None,
    is_blocked: Optional[bool] = None,
    salesperson_id: Optional[UUID] = None,
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("customer:view")),
):
    query = select(Customer).where(Customer.organization_id == current_user.organization_id)
    
    if channel:
        query = query.where(Customer.channel == channel)
    if is_active is not None:
        query = query.where(Customer.is_active == is_active)
    if is_blocked is not None:
        query = query.where(Customer.is_blocked == is_blocked)
    if salesperson_id:
        query = query.where(Customer.assigned_salesperson_id == salesperson_id)
    if search:
        query = query.where(
            or_(
                Customer.name.ilike(f"%{search}%"),
                Customer.code.ilike(f"%{search}%"),
                Customer.gstin.ilike(f"%{search}%"),
                Customer.trade_name.ilike(f"%{search}%"),
            )
        )
    
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(Customer.created_at.desc())
    result = await db.execute(query)
    items = result.scalars().all()
    
    # Enrich with related names
    response_items = []
    for item in items:
        pl_name = None
        if item.price_list_id:
            pl = await db.execute(select(PriceList).where(PriceList.id == item.price_list_id))
            pl_obj = pl.scalar_one_or_none()
            if pl_obj:
                pl_name = pl_obj.name
        
        sp_name = None
        if item.assigned_salesperson_id:
            sp = await db.execute(select(User).where(User.id == item.assigned_salesperson_id))
            sp_obj = sp.scalar_one_or_none()
            if sp_obj:
                sp_name = sp_obj.full_name
        
        wh_name = None
        if item.assigned_warehouse_id:
            wh = await db.execute(select(Warehouse).where(Warehouse.id == item.assigned_warehouse_id))
            wh_obj = wh.scalar_one_or_none()
            if wh_obj:
                wh_name = wh_obj.name
        
        # Get addresses and contacts
        addr_result = await db.execute(
            select(CustomerAddress).where(CustomerAddress.customer_id == item.id)
        )
        addresses = addr_result.scalars().all()
        
        contact_result = await db.execute(
            select(CustomerContact).where(CustomerContact.customer_id == item.id)
        )
        contacts = contact_result.scalars().all()
        
        response_items.append(CustomerResponse(
            **item.__dict__,
            price_list_name=pl_name,
            salesperson_name=sp_name,
            warehouse_name=wh_name,
            addresses=addresses,
            contacts=contacts,
        ))
    
    return CustomerListResponse(
        items=response_items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=(total + page_size - 1) // page_size,
    )


@router.get("/{customer_id}", response_model=CustomerResponse)
async def get_customer(
    customer_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("customer:view")),
):
    result = await db.execute(
        select(Customer).where(
            Customer.id == customer_id,
            Customer.organization_id == current_user.organization_id
        )
    )
    customer = result.scalar_one_or_none()
    
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    # Enrich
    pl_name = None
    if customer.price_list_id:
        pl = await db.execute(select(PriceList).where(PriceList.id == customer.price_list_id))
        pl_obj = pl.scalar_one_or_none()
        if pl_obj:
            pl_name = pl_obj.name
    
    sp_name = None
    if customer.assigned_salesperson_id:
        sp = await db.execute(select(User).where(User.id == customer.assigned_salesperson_id))
        sp_obj = sp.scalar_one_or_none()
        if sp_obj:
            sp_name = sp_obj.full_name
    
    wh_name = None
    if customer.assigned_warehouse_id:
        wh = await db.execute(select(Warehouse).where(Warehouse.id == customer.assigned_warehouse_id))
        wh_obj = wh.scalar_one_or_none()
        if wh_obj:
            wh_name = wh_obj.name
    
    addr_result = await db.execute(
        select(CustomerAddress).where(CustomerAddress.customer_id == customer.id)
    )
    addresses = addr_result.scalars().all()
    
    contact_result = await db.execute(
        select(CustomerContact).where(CustomerContact.customer_id == customer.id)
    )
    contacts = contact_result.scalars().all()
    
    return CustomerResponse(
        **customer.__dict__,
        price_list_name=pl_name,
        salesperson_name=sp_name,
        warehouse_name=wh_name,
        addresses=addresses,
        contacts=contacts,
    )


@router.put("/{customer_id}", response_model=CustomerResponse)
async def update_customer(
    customer_id: UUID,
    customer_data: CustomerUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("customer:update")),
):
    result = await db.execute(
        select(Customer).where(
            Customer.id == customer_id,
            Customer.organization_id == current_user.organization_id
        )
    )
    customer = result.scalar_one_or_none()
    
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    update_data = customer_data.model_dump(exclude_unset=True)
    
    if "code" in update_data:
        existing = await db.execute(
            select(Customer).where(
                Customer.organization_id == current_user.organization_id,
                Customer.code == update_data["code"],
                Customer.id != customer_id
            )
        )
        if existing.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="Customer code already exists")
    
    if "gstin" in update_data and update_data["gstin"]:
        existing = await db.execute(
            select(Customer).where(
                Customer.organization_id == current_user.organization_id,
                Customer.gstin == update_data["gstin"],
                Customer.id != customer_id
            )
        )
        if existing.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="GSTIN already registered")
    
    for field, value in update_data.items():
        setattr(customer, field, value)
    
    await db.commit()
    await db.refresh(customer)
    
    logger.info("customer_updated", customer_id=str(customer.id))
    return customer


@router.delete("/{customer_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_customer(
    customer_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("customer:delete")),
):
    result = await db.execute(
        select(Customer).where(
            Customer.id == customer_id,
            Customer.organization_id == current_user.organization_id
        )
    )
    customer = result.scalar_one_or_none()
    
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    customer.is_active = False
    await db.commit()
    
    logger.info("customer_deleted", customer_id=str(customer_id))


@router.post("/{customer_id}/addresses", response_model=CustomerAddressResponse, status_code=status.HTTP_201_CREATED)
async def add_customer_address(
    customer_id: UUID,
    address_data: CustomerAddressCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("customer:update")),
):
    customer = await db.execute(
        select(Customer).where(
            Customer.id == customer_id,
            Customer.organization_id == current_user.organization_id
        )
    )
    if not customer.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Customer not found")
    
    if address_data.is_default:
        # Unset other defaults
        await db.execute(
            select(CustomerAddress).where(
                CustomerAddress.customer_id == customer_id,
                CustomerAddress.is_default == True
            )
        )
        # Would need update statement
    
    address = CustomerAddress(
        **address_data.model_dump(),
        customer_id=customer_id,
    )
    db.add(address)
    await db.commit()
    await db.refresh(address)
    return address


@router.post("/{customer_id}/contacts", response_model=CustomerContactResponse, status_code=status.HTTP_201_CREATED)
async def add_customer_contact(
    customer_id: UUID,
    contact_data: CustomerContactCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("customer:update")),
):
    customer = await db.execute(
        select(Customer).where(
            Customer.id == customer_id,
            Customer.organization_id == current_user.organization_id
        )
    )
    if not customer.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Customer not found")
    
    contact = CustomerContact(
        **contact_data.model_dump(),
        customer_id=customer_id,
    )
    db.add(contact)
    await db.commit()
    await db.refresh(contact)
    return contact