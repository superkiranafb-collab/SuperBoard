from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_, text
from sqlalchemy.orm import selectinload
from pydantic import BaseModel
from uuid import UUID
from datetime import datetime, date
from decimal import Decimal
from app.core.database import get_db
from app.core.security import get_current_active_user, require_permission
from app.models import (
    Product, Warehouse, Bin, Batch, StockLedgerEntry, StockBalance,
    StockReservation, StockTransfer, StockTransferStatus, StockTransferItem,
    PhysicalStockCount, PhysicalStockCountStatus, PhysicalStockCountItem,
    StockStatus, TransactionType, Organization, User
)
import structlog

logger = structlog.get_logger()

router = APIRouter()


class StockBalanceResponse(BaseModel):
    product_id: UUID
    product_code: str
    product_name: str
    warehouse_id: UUID
    warehouse_code: str
    warehouse_name: str
    bin_id: Optional[UUID] = None
    bin_code: Optional[str] = None
    batch_id: Optional[UUID] = None
    batch_number: Optional[str] = None
    manufacture_date: Optional[date] = None
    expiry_date: Optional[date] = None
    stock_status: str
    qty: float
    valuation_rate: Optional[float] = None
    valuation_amount: Optional[float] = None
    last_transaction_date: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class StockBalanceListResponse(BaseModel):
    items: List[StockBalanceResponse]
    total: int
    page: int
    page_size: int
    total_pages: int


@router.get("/stock-balance", response_model=StockBalanceListResponse)
async def get_stock_balance(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    warehouse_id: Optional[UUID] = None,
    product_id: Optional[UUID] = None,
    batch_id: Optional[UUID] = None,
    stock_status: Optional[StockStatus] = None,
    low_stock_only: bool = False,
    expiry_within_days: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("inventory:view")),
):
    query = select(StockBalance).where(
        StockBalance.organization_id == current_user.organization_id,
        StockBalance.qty > 0
    )
    
    if warehouse_id:
        query = query.where(StockBalance.warehouse_id == warehouse_id)
    if product_id:
        query = query.where(StockBalance.product_id == product_id)
    if batch_id:
        query = query.where(StockBalance.batch_id == batch_id)
    if stock_status:
        query = query.where(StockBalance.stock_status == stock_status)
    
    if low_stock_only:
        # Join with product to check reorder level
        query = query.join(Product, StockBalance.product_id == Product.id).where(
            StockBalance.qty <= Product.reorder_level
        )
    
    if expiry_within_days:
        cutoff_date = date.today() + timedelta(days=expiry_within_days)
        query = query.join(Batch, StockBalance.batch_id == Batch.id).where(
            Batch.expiry_date <= cutoff_date
        )
    
    # Apply warehouse access control
    if current_user.assigned_warehouse_ids:
        query = query.where(StockBalance.warehouse_id.in_(current_user.assigned_warehouse_ids))
    
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(StockBalance.last_updated.desc())
    result = await db.execute(query)
    balances = result.scalars().all()
    
    # Enrich with product/warehouse/batch details
    response_items = []
    for bal in balances:
        product = await db.execute(select(Product).where(Product.id == bal.product_id))
        product_obj = product.scalar_one_or_none()
        
        warehouse = await db.execute(select(Warehouse).where(Warehouse.id == bal.warehouse_id))
        warehouse_obj = warehouse.scalar_one_or_none()
        
        bin_code = None
        if bal.bin_id:
            bin_obj = await db.execute(select(Bin).where(Bin.id == bal.bin_id))
            bin_obj = bin_obj.scalar_one_or_none()
            if bin_obj:
                bin_code = bin_obj.code
        
        batch_number = None
        manufacture_date = None
        expiry_date = None
        if bal.batch_id:
            batch = await db.execute(select(Batch).where(Batch.id == bal.batch_id))
            batch_obj = batch.scalar_one_or_none()
            if batch_obj:
                batch_number = batch_obj.batch_number
                manufacture_date = batch_obj.manufacture_date
                expiry_date = batch_obj.expiry_date
        
        valuation_amount = None
        if bal.qty and bal.valuation_rate:
            valuation_amount = float(bal.qty) * float(bal.valuation_rate)
        
        response_items.append(StockBalanceResponse(
            product_id=bal.product_id,
            product_code=product_obj.code if product_obj else "",
            product_name=product_obj.name if product_obj else "",
            warehouse_id=bal.warehouse_id,
            warehouse_code=warehouse_obj.code if warehouse_obj else "",
            warehouse_name=warehouse_obj.name if warehouse_obj else "",
            bin_id=bal.bin_id,
            bin_code=bin_code,
            batch_id=bal.batch_id,
            batch_number=batch_number,
            manufacture_date=manufacture_date,
            expiry_date=expiry_date,
            stock_status=bal.stock_status,
            qty=float(bal.qty),
            valuation_rate=float(bal.valuation_rate) if bal.valuation_rate else None,
            valuation_amount=valuation_amount,
            last_transaction_date=bal.last_transaction_date,
        ))
    
    return StockBalanceListResponse(
        items=response_items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=(total + page_size - 1) // page_size,
    )


class StockLedgerEntryResponse(BaseModel):
    id: UUID
    product_id: UUID
    product_code: str
    product_name: str
    warehouse_id: UUID
    warehouse_code: str
    bin_id: Optional[UUID] = None
    bin_code: Optional[str] = None
    batch_id: Optional[UUID] = None
    batch_number: Optional[str] = None
    transaction_type: str
    transaction_number: Optional[str] = None
    transaction_date: datetime
    qty_in: float
    qty_out: float
    balance_qty: float
    valuation_rate: Optional[float] = None
    stock_status: str
    reference_doctype: Optional[str] = None
    reference_docname: Optional[str] = None
    created_by_name: Optional[str] = None
    created_at: datetime
    
    class Config:
        from_attributes = True


class StockLedgerListResponse(BaseModel):
    items: List[StockLedgerEntryResponse]
    total: int
    page: int
    page_size: int
    total_pages: int


@router.get("/stock-ledger", response_model=StockLedgerListResponse)
async def get_stock_ledger(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    product_id: Optional[UUID] = None,
    warehouse_id: Optional[UUID] = None,
    batch_id: Optional[UUID] = None,
    transaction_type: Optional[TransactionType] = None,
    from_date: Optional[date] = None,
    to_date: Optional[date] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("inventory:view")),
):
    query = select(StockLedgerEntry).where(
        StockLedgerEntry.organization_id == current_user.organization_id
    )
    
    if product_id:
        query = query.where(StockLedgerEntry.product_id == product_id)
    if warehouse_id:
        query = query.where(StockLedgerEntry.warehouse_id == warehouse_id)
    if batch_id:
        query = query.where(StockLedgerEntry.batch_id == batch_id)
    if transaction_type:
        query = query.where(StockLedgerEntry.transaction_type == transaction_type)
    if from_date:
        query = query.where(StockLedgerEntry.transaction_date >= from_date)
    if to_date:
        query = query.where(StockLedgerEntry.transaction_date <= to_date)
    
    # Warehouse access control
    if current_user.assigned_warehouse_ids:
        query = query.where(StockLedgerEntry.warehouse_id.in_(current_user.assigned_warehouse_ids))
    
    count_query = select(func.count()).select_from(query.subquery())
    total = await db.scalar(count_query)
    
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(StockLedgerEntry.created_at.desc())
    result = await db.execute(query)
    entries = result.scalars().all()
    
    # Enrich
    response_items = []
    for entry in entries:
        product = await db.execute(select(Product).where(Product.id == entry.product_id))
        product_obj = product.scalar_one_or_none()
        
        warehouse = await db.execute(select(Warehouse).where(Warehouse.id == entry.warehouse_id))
        warehouse_obj = warehouse.scalar_one_or_none()
        
        bin_code = None
        if entry.bin_id:
            bin_obj = await db.execute(select(Bin).where(Bin.id == entry.bin_id))
            bin_obj = bin_obj.scalar_one_or_none()
            if bin_obj:
                bin_code = bin_obj.code
        
        batch_number = None
        if entry.batch_id:
            batch = await db.execute(select(Batch).where(Batch.id == entry.batch_id))
            batch_obj = batch.scalar_one_or_none()
            if batch_obj:
                batch_number = batch_obj.batch_number
        
        created_by_name = None
        if entry.created_by:
            user = await db.execute(select(User).where(User.id == entry.created_by))
            user_obj = user.scalar_one_or_none()
            if user_obj:
                created_by_name = user_obj.full_name
        
        response_items.append(StockLedgerEntryResponse(
            id=entry.id,
            product_id=entry.product_id,
            product_code=product_obj.code if product_obj else "",
            product_name=product_obj.name if product_obj else "",
            warehouse_id=entry.warehouse_id,
            warehouse_code=warehouse_obj.code if warehouse_obj else "",
            bin_id=entry.bin_id,
            bin_code=bin_code,
            batch_id=entry.batch_id,
            batch_number=batch_number,
            transaction_type=entry.transaction_type,
            transaction_number=entry.transaction_number,
            transaction_date=entry.transaction_date,
            qty_in=float(entry.qty_in),
            qty_out=float(entry.qty_out),
            balance_qty=float(entry.balance_qty),
            valuation_rate=float(entry.valuation_rate) if entry.valuation_rate else None,
            stock_status=entry.stock_status,
            reference_doctype=entry.reference_doctype,
            reference_docname=entry.reference_docname,
            created_by_name=created_by_name,
            created_at=entry.created_at,
        ))
    
    return StockLedgerListResponse(
        items=response_items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=(total + page_size - 1) // page_size,
    )


class StockAdjustmentRequest(BaseModel):
    product_id: UUID
    warehouse_id: UUID
    bin_id: Optional[UUID] = None
    batch_id: Optional[UUID] = None
    adjustment_qty: float  # Positive for increase, negative for decrease
    stock_status: StockStatus = StockStatus.AVAILABLE
    valuation_rate: Optional[float] = None
    reason: str
    reference_doctype: Optional[str] = None
    reference_docname: Optional[str] = None


@router.post("/stock-adjustment", status_code=status.HTTP_201_CREATED)
async def create_stock_adjustment(
    adjustment: StockAdjustmentRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("inventory:adjust")),
):
    # Validate product
    product = await db.execute(
        select(Product).where(
            Product.id == adjustment.product_id,
            Product.organization_id == current_user.organization_id
        )
    )
    product_obj = product.scalar_one_or_none()
    if not product_obj:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # Validate warehouse
    warehouse = await db.execute(
        select(Warehouse).where(
            Warehouse.id == adjustment.warehouse_id,
            Warehouse.organization_id == current_user.organization_id
        )
    )
    warehouse_obj = warehouse.scalar_one_or_none()
    if not warehouse_obj:
        raise HTTPException(status_code=404, detail="Warehouse not found")
    
    # Check batch if provided
    if adjustment.batch_id:
        batch = await db.execute(
            select(Batch).where(
                Batch.id == adjustment.batch_id,
                Batch.product_id == adjustment.product_id
            )
        )
        if not batch.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="Batch does not belong to this product")
    
    # Get current balance
    balance_query = select(StockBalance).where(
        StockBalance.organization_id == current_user.organization_id,
        StockBalance.product_id == adjustment.product_id,
        StockBalance.warehouse_id == adjustment.warehouse_id,
        StockBalance.bin_id == adjustment.bin_id,
        StockBalance.batch_id == adjustment.batch_id,
        StockBalance.stock_status == adjustment.stock_status
    )
    balance = await db.execute(balance_query)
    balance_obj = balance.scalar_one_or_none()
    
    current_qty = float(balance_obj.qty) if balance_obj else 0
    new_qty = current_qty + adjustment.adjustment_qty
    
    if new_qty < 0 and not warehouse_obj.allow_negative_stock:
        raise HTTPException(status_code=400, detail="Insufficient stock for adjustment")
    
    # Determine transaction type
    txn_type = TransactionType.STOCK_ADJUSTMENT if adjustment.adjustment_qty > 0 else TransactionType.STOCK_ADJUSTMENT
    
    # Create ledger entry
    ledger_entry = StockLedgerEntry(
        organization_id=current_user.organization_id,
        product_id=adjustment.product_id,
        warehouse_id=adjustment.warehouse_id,
        bin_id=adjustment.bin_id,
        batch_id=adjustment.batch_id,
        transaction_type=txn_type.value,
        transaction_date=datetime.now(timezone.utc),
        qty_in=adjustment.adjustment_qty if adjustment.adjustment_qty > 0 else 0,
        qty_out=abs(adjustment.adjustment_qty) if adjustment.adjustment_qty < 0 else 0,
        balance_qty=new_qty,
        valuation_rate=adjustment.valuation_rate,
        stock_status=adjustment.stock_status.value,
        reference_doctype=adjustment.reference_doctype,
        reference_docname=adjustment.reference_docname,
        notes=adjustment.reason,
        created_by=current_user.id,
    )
    db.add(ledger_entry)
    
    # Update or create balance
    if balance_obj:
        balance_obj.qty = new_qty
        if adjustment.valuation_rate:
            balance_obj.valuation_rate = adjustment.valuation_rate
        balance_obj.last_transaction_date = datetime.now(timezone.utc)
        balance_obj.last_updated = datetime.now(timezone.utc)
    else:
        new_balance = StockBalance(
            organization_id=current_user.organization_id,
            product_id=adjustment.product_id,
            warehouse_id=adjustment.warehouse_id,
            bin_id=adjustment.bin_id,
            batch_id=adjustment.batch_id,
            stock_status=adjustment.stock_status.value,
            qty=new_qty,
            valuation_rate=adjustment.valuation_rate,
            last_transaction_date=datetime.now(timezone.utc),
        )
        db.add(new_balance)
    
    await db.commit()
    
    logger.info("stock_adjustment_created", 
                product_id=str(adjustment.product_id),
                warehouse_id=str(adjustment.warehouse_id),
                adjustment_qty=adjustment.adjustment_qty,
                user_id=str(current_user.id))
    
    return {"message": "Stock adjustment completed", "new_qty": new_qty}


class StockTransferCreateRequest(BaseModel):
    from_warehouse_id: UUID
    to_warehouse_id: UUID
    transfer_date: date
    expected_date: Optional[date] = None
    vehicle_number: Optional[str] = None
    driver_name: Optional[str] = None
    driver_phone: Optional[str] = None
    notes: Optional[str] = None
    items: List[dict]  # [{product_id, batch_id, from_bin_id, to_bin_id, qty, valuation_rate}]


@router.post("/stock-transfers", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_stock_transfer(
    transfer_data: StockTransferCreateRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("inventory:transfer")),
):
    # Validate warehouses
    from_wh = await db.execute(
        select(Warehouse).where(
            Warehouse.id == transfer_data.from_warehouse_id,
            Warehouse.organization_id == current_user.organization_id
        )
    )
    if not from_wh.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Source warehouse not found")
    
    to_wh = await db.execute(
        select(Warehouse).where(
            Warehouse.id == transfer_data.to_warehouse_id,
            Warehouse.organization_id == current_user.organization_id
        )
    )
    if not to_wh.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Destination warehouse not found")
    
    if transfer_data.from_warehouse_id == transfer_data.to_warehouse_id:
        raise HTTPException(status_code=400, detail="Source and destination warehouses cannot be the same")
    
    # Generate transfer number
    from datetime import date as dt
    today = dt.today()
    prefix = f"ST-{today.strftime('%Y%m%d')}-"
    count_result = await db.execute(
        select(func.count(StockTransfer.id)).where(
            StockTransfer.organization_id == current_user.organization_id,
            StockTransfer.transfer_number.like(f"{prefix}%")
        )
    )
    seq = (count_result.scalar() or 0) + 1
    transfer_number = f"{prefix}{seq:04d}"
    
    transfer = StockTransfer(
        organization_id=current_user.organization_id,
        transfer_number=transfer_number,
        from_warehouse_id=transfer_data.from_warehouse_id,
        to_warehouse_id=transfer_data.to_warehouse_id,
        transfer_date=datetime.combine(transfer_data.transfer_date, datetime.min.time()).replace(tzinfo=timezone.utc),
        expected_date=datetime.combine(transfer_data.expected_date, datetime.min.time()).replace(tzinfo=timezone.utc) if transfer_data.expected_date else None,
        vehicle_number=transfer_data.vehicle_number,
        driver_name=transfer_data.driver_name,
        driver_phone=transfer_data.driver_phone,
        notes=transfer_data.notes,
        status=StockTransferStatus.DRAFT,
        created_by=current_user.id,
    )
    db.add(transfer)
    await db.flush()
    
    # Add items
    for item_data in transfer_data.items:
        item = StockTransferItem(
            transfer_id=transfer.id,
            product_id=item_data["product_id"],
            batch_id=item_data.get("batch_id"),
            from_bin_id=item_data.get("from_bin_id"),
            to_bin_id=item_data.get("to_bin_id"),
            qty=item_data["qty"],
            valuation_rate=item_data.get("valuation_rate"),
        )
        db.add(item)
    
    await db.commit()
    
    logger.info("stock_transfer_created", transfer_id=str(transfer.id), transfer_number=transfer_number)
    
    return {"id": str(transfer.id), "transfer_number": transfer_number, "status": transfer.status.value}


@router.get("/stock-transfers", response_model=List[dict])
async def list_stock_transfers(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[StockTransferStatus] = None,
    from_warehouse_id: Optional[UUID] = None,
    to_warehouse_id: Optional[UUID] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("inventory:view")),
):
    query = select(StockTransfer).where(StockTransfer.organization_id == current_user.organization_id)
    
    if status:
        query = query.where(StockTransfer.status == status)
    if from_warehouse_id:
        query = query.where(StockTransfer.from_warehouse_id == from_warehouse_id)
    if to_warehouse_id:
        query = query.where(StockTransfer.to_warehouse_id == to_warehouse_id)
    
    query = query.offset((page - 1) * page_size).limit(page_size).order_by(StockTransfer.created_at.desc())
    result = await db.execute(query)
    transfers = result.scalars().all()
    
    return [
        {
            "id": str(t.id),
            "transfer_number": t.transfer_number,
            "from_warehouse_id": str(t.from_warehouse_id),
            "to_warehouse_id": str(t.to_warehouse_id),
            "status": t.status.value,
            "transfer_date": t.transfer_date.isoformat() if t.transfer_date else None,
            "expected_date": t.expected_date.isoformat() if t.expected_date else None,
        }
        for t in transfers
    ]


@router.post("/stock-transfers/{transfer_id}/dispatch")
async def dispatch_stock_transfer(
    transfer_id: UUID,
    dispatched_by: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("inventory:transfer")),
):
    result = await db.execute(
        select(StockTransfer).where(
            StockTransfer.id == transfer_id,
            StockTransfer.organization_id == current_user.organization_id
        )
    )
    transfer = result.scalar_one_or_none()
    
    if not transfer:
        raise HTTPException(status_code=404, detail="Transfer not found")
    
    if transfer.status != StockTransferStatus.APPROVED:
        raise HTTPException(status_code=400, detail="Transfer must be approved before dispatch")
    
    # Create stock reservations and ledger entries for dispatch
    items_result = await db.execute(
        select(StockTransferItem).where(StockTransferItem.transfer_id == transfer_id)
    )
    items = items_result.scalars().all()
    
    for item in items:
        # Reserve stock in source warehouse
        balance_query = select(StockBalance).where(
            StockBalance.organization_id == current_user.organization_id,
            StockBalance.product_id == item.product_id,
            StockBalance.warehouse_id == transfer.from_warehouse_id,
            StockBalance.bin_id == item.from_bin_id,
            StockBalance.batch_id == item.batch_id,
            StockBalance.stock_status == StockStatus.AVAILABLE.value
        )
        balance = await db.execute(balance_query)
        balance_obj = balance.scalar_one_or_none()
        
        if not balance_obj or float(balance_obj.qty) < float(item.qty):
            raise HTTPException(
                status_code=400, 
                detail=f"Insufficient stock for product {item.product_id} in source warehouse"
            )
        
        # Create reservation
        reservation = StockReservation(
            organization_id=current_user.organization_id,
            product_id=item.product_id,
            warehouse_id=transfer.from_warehouse_id,
            batch_id=item.batch_id,
            bin_id=item.from_bin_id,
            qty=item.qty,
            reference_doctype="stock_transfer",
            reference_docname=transfer.transfer_number,
            reference_doc_id=transfer.id,
        )
        db.add(reservation)
        
        # Create ledger entry for dispatch (stock out)
        new_qty = float(balance_obj.qty) - float(item.qty)
        ledger_entry = StockLedgerEntry(
            organization_id=current_user.organization_id,
            product_id=item.product_id,
            warehouse_id=transfer.from_warehouse_id,
            bin_id=item.from_bin_id,
            batch_id=item.batch_id,
            transaction_type=TransactionType.STOCK_TRANSFER_OUT.value,
            transaction_id=transfer.id,
            transaction_number=transfer.transfer_number,
            transaction_date=datetime.now(timezone.utc),
            qty_out=item.qty,
            balance_qty=new_qty,
            valuation_rate=item.valuation_rate,
            stock_status=StockStatus.IN_TRANSIT.value,
            reference_doctype="stock_transfer",
            reference_docname=transfer.transfer_number,
            created_by=current_user.id,
        )
        db.add(ledger_entry)
        
        # Update source balance
        balance_obj.qty = new_qty
        balance_obj.last_transaction_date = datetime.now(timezone.utc)
        balance_obj.last_updated = datetime.now(timezone.utc)
        
        # Create in-transit balance at destination
        in_transit_balance = StockBalance(
            organization_id=current_user.organization_id,
            product_id=item.product_id,
            warehouse_id=transfer.to_warehouse_id,
            bin_id=item.to_bin_id,
            batch_id=item.batch_id,
            stock_status=StockStatus.IN_TRANSIT.value,
            qty=item.qty,
            valuation_rate=item.valuation_rate,
            last_transaction_date=datetime.now(timezone.utc),
        )
        db.add(in_transit_balance)
    
    transfer.status = StockTransferStatus.IN_TRANSIT
    transfer.dispatched_date = datetime.now(timezone.utc)
    transfer.dispatched_by = dispatched_by
    
    await db.commit()
    
    logger.info("stock_transfer_dispatched", transfer_id=str(transfer_id))
    
    return {"message": "Transfer dispatched successfully"}


@router.post("/stock-transfers/{transfer_id}/receive")
async def receive_stock_transfer(
    transfer_id: UUID,
    received_by: UUID,
    items: List[dict],  # [{item_id, received_qty, to_bin_id, quality_status}]
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_permission("inventory:transfer")),
):
    result = await db.execute(
        select(StockTransfer).where(
            StockTransfer.id == transfer_id,
            StockTransfer.organization_id == current_user.organization_id
        )
    )
    transfer = result.scalar_one_or_none()
    
    if not transfer:
        raise HTTPException(status_code=404, detail="Transfer not found")
    
    if transfer.status != StockTransferStatus.IN_TRANSIT:
        raise HTTPException(status_code=400, detail="Transfer is not in transit")
    
    for item_data in items:
        item = await db.execute(
            select(StockTransferItem).where(
                StockTransferItem.id == item_data["item_id"],
                StockTransferItem.transfer_id == transfer_id
            )
        )
        transfer_item = item.scalar_one_or_none()
        
        if not transfer_item:
            continue
        
        received_qty = item_data["received_qty"]
        to_bin_id = item_data.get("to_bin_id") or transfer_item.to_bin_id
        
        # Release reservation
        await db.execute(
            select(StockReservation).where(
                StockReservation.reference_doc_id == transfer_id,
                StockReservation.product_id == transfer_item.product_id,
                StockReservation.warehouse_id == transfer.from_warehouse_id
            )
        )
        # Would need delete statement
        
        # Update transfer item
        transfer_item.received_qty = float(transfer_item.received_qty) + received_qty
        transfer_item.to_bin_id = to_bin_id
        
        # Remove in-transit balance
        in_transit_balance = await db.execute(
            select(StockBalance).where(
                StockBalance.organization_id == current_user.organization_id,
                StockBalance.product_id == transfer_item.product_id,
                StockBalance.warehouse_id == transfer.to_warehouse_id,
                StockBalance.bin_id == transfer_item.to_bin_id,
                StockBalance.batch_id == transfer_item.batch_id,
                StockBalance.stock_status == StockStatus.IN_TRANSIT.value
            )
        )
        in_transit_obj = in_transit_balance.scalar_one_or_none()
        if in_transit_obj:
            in_transit_obj.qty = float(in_transit_obj.qty) - received_qty
            if in_transit_obj.qty <= 0:
                await db.delete(in_transit_obj)
        
        # Create available balance at destination
        status_val = item_data.get("quality_status", StockStatus.AVAILABLE.value)
        dest_balance = await db.execute(
            select(StockBalance).where(
                StockBalance.organization_id == current_user.organization_id,
                StockBalance.product_id == transfer_item.product_id,
                StockBalance.warehouse_id == transfer.to_warehouse_id,
                StockBalance.bin_id == to_bin_id,
                StockBalance.batch_id == transfer_item.batch_id,
                StockBalance.stock_status == status_val
            )
        )
        dest_obj = dest_balance.scalar_one_or_none()
        
        new_qty = received_qty
        if dest_obj:
            new_qty = float(dest_obj.qty) + received_qty
            dest_obj.qty = new_qty
            dest_obj.last_transaction_date = datetime.now(timezone.utc)
            dest_obj.last_updated = datetime.now(timezone.utc)
        else:
            dest_obj = StockBalance(
                organization_id=current_user.organization_id,
                product_id=transfer_item.product_id,
                warehouse_id=transfer.to_warehouse_id,
                bin_id=to_bin_id,
                batch_id=transfer_item.batch_id,
                stock_status=status_val,
                qty=received_qty,
                valuation_rate=transfer_item.valuation_rate,
                last_transaction_date=datetime.now(timezone.utc),
            )
            db.add(dest_obj)
        
        # Create ledger entry for receipt
        ledger_entry = StockLedgerEntry(
            organization_id=current_user.organization_id,
            product_id=transfer_item.product_id,
            warehouse_id=transfer.to_warehouse_id,
            bin_id=to_bin_id,
            batch_id=transfer_item.batch_id,
            transaction_type=TransactionType.STOCK_TRANSFER_IN.value,
            transaction_id=transfer.id,
            transaction_number=transfer.transfer_number,
            transaction_date=datetime.now(timezone.utc),
            qty_in=received_qty,
            balance_qty=new_qty,
            valuation_rate=transfer_item.valuation_rate,
            stock_status=status_val,
            reference_doctype="stock_transfer",
            reference_docname=transfer.transfer_number,
            created_by=current_user.id,
        )
        db.add(ledger_entry)
    
    # Check if all items fully received
    items_result = await db.execute(
        select(StockTransferItem).where(StockTransferItem.transfer_id == transfer_id)
    )
    all_items = items_result.scalars().all()
    
    all_received = all(float(item.received_qty) >= float(item.qty) for item in all_items)
    partially_received = any(float(item.received_qty) > 0 for item in all_items)
    
    if all_received:
        transfer.status = StockTransferStatus.RECEIVED
        transfer.received_date = datetime.now(timezone.utc)
    elif partially_received:
        transfer.status = StockTransferStatus.PARTIAL_RECEIVED
    
    transfer.received_by = received_by
    
    await db.commit()
    
    logger.info("stock_transfer_received", transfer_id=str(transfer_id), status=transfer.status.value)
    
    return {"message": "Transfer received", "status": transfer.status.value}