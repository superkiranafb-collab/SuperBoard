import casbin
import casbin_sqlalchemy_adapter
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.core.config import settings
from app.core.database import Base

# Casbin model definition
CASBIN_MODEL = """
[request_definition]
r = sub, obj, act

[policy_definition]
p = sub, obj, act

[role_definition]
g = _, _

[policy_effect]
e = some(where (p.eft == allow))

[matchers]
m = g(r.sub, p.sub) && r.obj == p.obj && r.act == p.act
"""

# Database adapter for Casbin
engine = create_engine(settings.DATABASE_URL.replace("+asyncpg", ""))
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

adapter = casbin_sqlalchemy_adapter.Adapter(engine, db_class=Base)


def get_enforcer() -> casbin.Enforcer:
    enforcer = casbin.Enforcer(CASBIN_MODEL, adapter)
    return enforcer


# Permission constants
class Permissions:
    # Organization
    ORG_VIEW = "org:view"
    ORG_CREATE = "org:create"
    ORG_UPDATE = "org:update"
    ORG_DELETE = "org:delete"

    # User Management
    USER_VIEW = "user:view"
    USER_CREATE = "user:create"
    USER_UPDATE = "user:update"
    USER_DELETE = "user:delete"
    USER_ASSIGN_ROLE = "user:assign_role"

    # Warehouse
    WAREHOUSE_VIEW = "warehouse:view"
    WAREHOUSE_CREATE = "warehouse:create"
    WAREHOUSE_UPDATE = "warehouse:update"
    WAREHOUSE_DELETE = "warehouse:delete"
    WAREHOUSE_TRANSFER = "warehouse:transfer"

    # Customer
    CUSTOMER_VIEW = "customer:view"
    CUSTOMER_CREATE = "customer:create"
    CUSTOMER_UPDATE = "customer:update"
    CUSTOMER_DELETE = "customer:delete"

    # Product
    PRODUCT_VIEW = "product:view"
    PRODUCT_CREATE = "product:create"
    PRODUCT_UPDATE = "product:update"
    PRODUCT_DELETE = "product:delete"

    # Sales
    SALES_ORDER_VIEW = "sales_order:view"
    SALES_ORDER_CREATE = "sales_order:create"
    SALES_ORDER_UPDATE = "sales_order:update"
    SALES_ORDER_APPROVE = "sales_order:approve"
    SALES_ORDER_CANCEL = "sales_order:cancel"
    SALES_QUOTATION_CREATE = "sales_quotation:create"

    # Purchase
    PURCHASE_ORDER_VIEW = "purchase_order:view"
    PURCHASE_ORDER_CREATE = "purchase_order:create"
    PURCHASE_ORDER_APPROVE = "purchase_order:approve"
    PURCHASE_RECEIVE = "purchase_receive:create"

    # Inventory
    INVENTORY_VIEW = "inventory:view"
    INVENTORY_ADJUST = "inventory:adjust"
    INVENTORY_COUNT = "inventory:count"
    INVENTORY_TRANSFER = "inventory:transfer"
    PICKING_CREATE = "picking:create"
    PACKING_CREATE = "packing:create"

    # Delivery
    DELIVERY_VIEW = "delivery:view"
    DELIVERY_CREATE = "delivery:create"
    DELIVERY_COMPLETE = "delivery:complete"
    DELIVERY_CASH_COLLECT = "delivery:cash_collect"

    # Manufacturing
    BOM_VIEW = "bom:view"
    BOM_CREATE = "bom:create"
    BOM_UPDATE = "bom:update"
    WORK_ORDER_VIEW = "work_order:view"
    WORK_ORDER_CREATE = "work_order:create"
    WORK_ORDER_UPDATE = "work_order:update"
    PRODUCTION_RECORD = "production:record"
    QC_VIEW = "qc:view"
    QC_CREATE = "qc:create"
    QC_APPROVE = "qc:approve"
    BATCH_RELEASE = "batch:release"

    # Finance
    FINANCE_VIEW = "finance:view"
    INVOICE_CREATE = "invoice:create"
    INVOICE_APPROVE = "invoice:approve"
    PAYMENT_CREATE = "payment:create"
    PAYMENT_APPROVE = "payment:approve"
    EXPENSE_CREATE = "expense:create"
    EXPENSE_APPROVE = "expense:approve"
    JOURNAL_CREATE = "journal:create"
    GST_REPORT = "gst:report"

    # HR
    HR_VIEW = "hr:view"
    ATTENDANCE_VIEW = "attendance:view"
    ATTENDANCE_CREATE = "attendance:create"
    LEAVE_APPROVE = "leave:approve"
    PAYROLL_VIEW = "payroll:view"

    # Approvals
    APPROVAL_VIEW = "approval:view"
    APPROVAL_DECIDE = "approval:decide"

    # Reports
    REPORT_VIEW = "report:view"
    REPORT_EXPORT = "report:export"

    # AI
    AI_QUERY = "ai:query"
    AI_ACTION = "ai:action"


# Role definitions with permissions
ROLE_PERMISSIONS = {
    "owner": [
        Permissions.ORG_VIEW, Permissions.ORG_CREATE, Permissions.ORG_UPDATE, Permissions.ORG_DELETE,
        Permissions.USER_VIEW, Permissions.USER_CREATE, Permissions.USER_UPDATE, Permissions.USER_DELETE, Permissions.USER_ASSIGN_ROLE,
        Permissions.WAREHOUSE_VIEW, Permissions.WAREHOUSE_CREATE, Permissions.WAREHOUSE_UPDATE, Permissions.WAREHOUSE_DELETE, Permissions.WAREHOUSE_TRANSFER,
        Permissions.CUSTOMER_VIEW, Permissions.CUSTOMER_CREATE, Permissions.CUSTOMER_UPDATE, Permissions.CUSTOMER_DELETE,
        Permissions.PRODUCT_VIEW, Permissions.PRODUCT_CREATE, Permissions.PRODUCT_UPDATE, Permissions.PRODUCT_DELETE,
        Permissions.SALES_ORDER_VIEW, Permissions.SALES_ORDER_CREATE, Permissions.SALES_ORDER_UPDATE, Permissions.SALES_ORDER_APPROVE, Permissions.SALES_ORDER_CANCEL,
        Permissions.PURCHASE_ORDER_VIEW, Permissions.PURCHASE_ORDER_CREATE, Permissions.PURCHASE_ORDER_APPROVE, Permissions.PURCHASE_RECEIVE,
        Permissions.INVENTORY_VIEW, Permissions.INVENTORY_ADJUST, Permissions.INVENTORY_COUNT, Permissions.INVENTORY_TRANSFER,
        Permissions.DELIVERY_VIEW, Permissions.DELIVERY_CREATE, Permissions.DELIVERY_COMPLETE, Permissions.DELIVERY_CASH_COLLECT,
        Permissions.BOM_VIEW, Permissions.BOM_CREATE, Permissions.BOM_UPDATE,
        Permissions.WORK_ORDER_VIEW, Permissions.WORK_ORDER_CREATE, Permissions.WORK_ORDER_UPDATE,
        Permissions.PRODUCTION_RECORD, Permissions.QC_VIEW, Permissions.QC_CREATE, Permissions.QC_APPROVE, Permissions.BATCH_RELEASE,
        Permissions.FINANCE_VIEW, Permissions.INVOICE_CREATE, Permissions.INVOICE_APPROVE,
        Permissions.PAYMENT_CREATE, Permissions.PAYMENT_APPROVE, Permissions.EXPENSE_CREATE, Permissions.EXPENSE_APPROVE,
        Permissions.JOURNAL_CREATE, Permissions.GST_REPORT,
        Permissions.HR_VIEW, Permissions.ATTENDANCE_VIEW, Permissions.LEAVE_APPROVE, Permissions.PAYROLL_VIEW,
        Permissions.APPROVAL_VIEW, Permissions.APPROVAL_DECIDE,
        Permissions.REPORT_VIEW, Permissions.REPORT_EXPORT,
        Permissions.AI_QUERY, Permissions.AI_ACTION,
    ],
    "department_head": [
        Permissions.ORG_VIEW,
        Permissions.USER_VIEW, Permissions.USER_CREATE, Permissions.USER_UPDATE,
        Permissions.WAREHOUSE_VIEW, Permissions.WAREHOUSE_TRANSFER,
        Permissions.CUSTOMER_VIEW, Permissions.CUSTOMER_CREATE, Permissions.CUSTOMER_UPDATE,
        Permissions.PRODUCT_VIEW, Permissions.PRODUCT_CREATE, Permissions.PRODUCT_UPDATE,
        Permissions.SALES_ORDER_VIEW, Permissions.SALES_ORDER_CREATE, Permissions.SALES_ORDER_UPDATE, Permissions.SALES_ORDER_APPROVE,
        Permissions.PURCHASE_ORDER_VIEW, Permissions.PURCHASE_ORDER_CREATE, Permissions.PURCHASE_ORDER_APPROVE, Permissions.PURCHASE_RECEIVE,
        Permissions.INVENTORY_VIEW, Permissions.INVENTORY_ADJUST, Permissions.INVENTORY_COUNT, Permissions.INVENTORY_TRANSFER,
        Permissions.DELIVERY_VIEW, Permissions.DELIVERY_CREATE, Permissions.DELIVERY_COMPLETE,
        Permissions.BOM_VIEW, Permissions.BOM_CREATE, Permissions.BOM_UPDATE,
        Permissions.WORK_ORDER_VIEW, Permissions.WORK_ORDER_CREATE, Permissions.WORK_ORDER_UPDATE,
        Permissions.PRODUCTION_RECORD, Permissions.QC_VIEW, Permissions.QC_CREATE, Permissions.QC_APPROVE, Permissions.BATCH_RELEASE,
        Permissions.FINANCE_VIEW, Permissions.INVOICE_CREATE, Permissions.INVOICE_APPROVE,
        Permissions.PAYMENT_CREATE, Permissions.PAYMENT_APPROVE, Permissions.EXPENSE_CREATE, Permissions.EXPENSE_APPROVE,
        Permissions.GST_REPORT,
        Permissions.HR_VIEW, Permissions.ATTENDANCE_VIEW, Permissions.LEAVE_APPROVE,
        Permissions.APPROVAL_VIEW, Permissions.APPROVAL_DECIDE,
        Permissions.REPORT_VIEW, Permissions.REPORT_EXPORT,
        Permissions.AI_QUERY,
    ],
    "regional_manager": [
        Permissions.ORG_VIEW,
        Permissions.USER_VIEW,
        Permissions.WAREHOUSE_VIEW,
        Permissions.CUSTOMER_VIEW, Permissions.CUSTOMER_CREATE, Permissions.CUSTOMER_UPDATE,
        Permissions.PRODUCT_VIEW,
        Permissions.SALES_ORDER_VIEW, Permissions.SALES_ORDER_CREATE, Permissions.SALES_ORDER_UPDATE,
        Permissions.PURCHASE_ORDER_VIEW, Permissions.PURCHASE_RECEIVE,
        Permissions.INVENTORY_VIEW, Permissions.INVENTORY_COUNT,
        Permissions.DELIVERY_VIEW, Permissions.DELIVERY_CREATE, Permissions.DELIVERY_COMPLETE,
        Permissions.WORK_ORDER_VIEW,
        Permissions.QC_VIEW,
        Permissions.FINANCE_VIEW,
        Permissions.ATTENDANCE_VIEW,
        Permissions.APPROVAL_VIEW, Permissions.APPROVAL_DECIDE,
        Permissions.REPORT_VIEW,
        Permissions.AI_QUERY,
    ],
    "warehouse_manager": [
        Permissions.WAREHOUSE_VIEW,
        Permissions.PRODUCT_VIEW,
        Permissions.SALES_ORDER_VIEW,
        Permissions.PURCHASE_RECEIVE,
        Permissions.INVENTORY_VIEW, Permissions.INVENTORY_ADJUST, Permissions.INVENTORY_COUNT, Permissions.INVENTORY_TRANSFER, Permissions.PICKING_CREATE, Permissions.PACKING_CREATE,
        Permissions.DELIVERY_VIEW,
        Permissions.QC_VIEW, Permissions.QC_CREATE,
        Permissions.REPORT_VIEW,
        Permissions.AI_QUERY,
    ],
    "sales_supervisor": [
        Permissions.CUSTOMER_VIEW, Permissions.CUSTOMER_CREATE, Permissions.CUSTOMER_UPDATE,
        Permissions.PRODUCT_VIEW,
        Permissions.SALES_ORDER_VIEW, Permissions.SALES_ORDER_CREATE, Permissions.SALES_ORDER_UPDATE, Permissions.SALES_QUOTATION_CREATE,
        Permissions.INVENTORY_VIEW,
        Permissions.DELIVERY_VIEW,
        Permissions.REPORT_VIEW,
        Permissions.AI_QUERY,
    ],
    "accountant": [
        Permissions.ORG_VIEW,
        Permissions.CUSTOMER_VIEW,
        Permissions.PRODUCT_VIEW,
        Permissions.SALES_ORDER_VIEW,
        Permissions.PURCHASE_ORDER_VIEW, Permissions.PURCHASE_RECEIVE,
        Permissions.INVENTORY_VIEW,
        Permissions.FINANCE_VIEW, Permissions.INVOICE_CREATE, Permissions.INVOICE_APPROVE,
        Permissions.PAYMENT_CREATE, Permissions.PAYMENT_APPROVE, Permissions.EXPENSE_CREATE, Permissions.EXPENSE_APPROVE,
        Permissions.JOURNAL_CREATE, Permissions.GST_REPORT,
        Permissions.REPORT_VIEW, Permissions.REPORT_EXPORT,
        Permissions.AI_QUERY,
    ],
    "production_manager": [
        Permissions.PRODUCT_VIEW, Permissions.PRODUCT_CREATE, Permissions.PRODUCT_UPDATE,
        Permissions.WAREHOUSE_VIEW,
        Permissions.PURCHASE_ORDER_VIEW, Permissions.PURCHASE_RECEIVE,
        Permissions.INVENTORY_VIEW, Permissions.INVENTORY_ADJUST, Permissions.INVENTORY_COUNT, Permissions.INVENTORY_TRANSFER,
        Permissions.BOM_VIEW, Permissions.BOM_CREATE, Permissions.BOM_UPDATE,
        Permissions.WORK_ORDER_VIEW, Permissions.WORK_ORDER_CREATE, Permissions.WORK_ORDER_UPDATE,
        Permissions.PRODUCTION_RECORD, Permissions.QC_VIEW, Permissions.QC_CREATE, Permissions.QC_APPROVE, Permissions.BATCH_RELEASE,
        Permissions.REPORT_VIEW,
        Permissions.AI_QUERY,
    ],
    "quality_supervisor": [
        Permissions.PRODUCT_VIEW,
        Permissions.INVENTORY_VIEW,
        Permissions.QC_VIEW, Permissions.QC_CREATE, Permissions.QC_APPROVE,
        Permissions.BATCH_RELEASE,
        Permissions.REPORT_VIEW,
    ],
    "hr_manager": [
        Permissions.USER_VIEW, Permissions.USER_CREATE, Permissions.USER_UPDATE,
        Permissions.HR_VIEW, Permissions.ATTENDANCE_VIEW, Permissions.ATTENDANCE_CREATE, Permissions.LEAVE_APPROVE, Permissions.PAYROLL_VIEW,
        Permissions.APPROVAL_VIEW, Permissions.APPROVAL_DECIDE,
        Permissions.REPORT_VIEW,
    ],
    "salesperson": [
        Permissions.CUSTOMER_VIEW, Permissions.CUSTOMER_CREATE,
        Permissions.PRODUCT_VIEW,
        Permissions.SALES_ORDER_VIEW, Permissions.SALES_ORDER_CREATE,
        Permissions.INVENTORY_VIEW,
        Permissions.DELIVERY_VIEW,
        Permissions.ATTENDANCE_CREATE,
        Permissions.AI_QUERY,
    ],
    "warehouse_staff": [
        Permissions.PRODUCT_VIEW,
        Permissions.SALES_ORDER_VIEW,
        Permissions.PURCHASE_RECEIVE,
        Permissions.INVENTORY_VIEW, Permissions.INVENTORY_COUNT, Permissions.PICKING_CREATE, Permissions.PACKING_CREATE,
        Permissions.DELIVERY_VIEW,
    ],
    "driver": [
        Permissions.DELIVERY_VIEW, Permissions.DELIVERY_CREATE, Permissions.DELIVERY_COMPLETE, Permissions.DELIVERY_CASH_COLLECT,
    ],
    "factory_operator": [
        Permissions.PRODUCT_VIEW,
        Permissions.INVENTORY_VIEW,
        Permissions.WORK_ORDER_VIEW,
        Permissions.PRODUCTION_RECORD,
        Permissions.QC_VIEW, Permissions.QC_CREATE,
    ],
    "helper": [
        Permissions.INVENTORY_VIEW,
        Permissions.PRODUCTION_RECORD,
    ],
}


async def init_casbin_policies() -> None:
    """Initialize Casbin policies from role definitions."""
    enforcer = get_enforcer()
    
    # Clear existing policies
    enforcer.clear_policy()
    
    # Add role permissions
    for role, permissions in ROLE_PERMISSIONS.items():
        for perm in permissions:
            enforcer.add_policy(role, perm, "read")
            enforcer.add_policy(role, perm, "write")
    
    # Add role hierarchy
    enforcer.add_grouping_policy("department_head", "owner")
    enforcer.add_grouping_policy("regional_manager", "department_head")
    enforcer.add_grouping_policy("warehouse_manager", "regional_manager")
    enforcer.add_grouping_policy("sales_supervisor", "regional_manager")
    enforcer.add_grouping_policy("accountant", "department_head")
    enforcer.add_grouping_policy("production_manager", "department_head")
    enforcer.add_grouping_policy("quality_supervisor", "production_manager")
    enforcer.add_grouping_policy("hr_manager", "department_head")
    enforcer.add_grouping_policy("salesperson", "sales_supervisor")
    enforcer.add_grouping_policy("warehouse_staff", "warehouse_manager")
    enforcer.add_grouping_policy("driver", "warehouse_manager")
    enforcer.add_grouping_policy("factory_operator", "production_manager")
    enforcer.add_grouping_policy("helper", "factory_operator")
    
    enforcer.save_policy()