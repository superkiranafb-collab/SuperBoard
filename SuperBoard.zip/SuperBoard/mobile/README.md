# SuperBoard Mobile - Flutter ERP App

Offline-first Flutter mobile application for the SuperBoard ERP system.

## Features

- **Offline-First Architecture**: Full offline capability with Drift/SQLite local database
- **Background Sync**: Automatic synchronization when online with conflict resolution
- **15+ ERP Modules**: Sales, Inventory, Purchase, Manufacturing, Finance, HR, Logistics
- **Material 3 Design**: Modern, accessible UI with dark/light theme support
- **Riverpod State Management**: Reactive, type-safe state management
- **GoRouter Navigation**: Declarative routing with deep linking support

## Tech Stack

- **Framework**: Flutter 3.19+
- **Language**: Dart 3.3+
- **Database**: Drift (SQLite) with sqlcipher for encryption
- **State Management**: Riverpod 2.4+
- **Navigation**: GoRouter 13+
- **Networking**: Dio 5.4+ with interceptors
- **Code Generation**: Freezed, JSON Serializable, Drift Dev
- **Architecture**: Clean Architecture with Repository pattern

## Project Structure

```
lib/
├── core/
│   ├── config/          # App configuration, environment
│   ├── router/          # GoRouter configuration
│   └── theme/           # Material 3 theme (light/dark)
├── data/
│   ├── database/        # Drift database schema & DAOs
│   ├── models/          # Freezed data models
│   ├── repositories/    # Repository implementations
│   └── sync/            # Sync service & conflict resolution
├── presentation/
│   ├── providers/       # Riverpod providers
│   ├── screens/         # UI screens by module
│   │   ├── auth/
│   │   ├── dashboard/
│   │   ├── inventory/
│   │   ├── sales/
│   │   └── manufacturing/
│   └── widgets/         # Reusable UI components
└── main.dart            # App entry point
```

## Getting Started

### Prerequisites

- Flutter SDK 3.19+
- Dart SDK 3.3+
- Android Studio / VS Code
- Android SDK / Xcode (for iOS)

### Installation

```bash
cd mobile
flutter pub get
flutter pub run build_runner build --delete-conflicting-outputs
flutter run
```

### Environment Variables

Create a `.env` file or pass via `--dart-define`:

```bash
flutter run --dart-define=API_BASE_URL=https://your-api.com/api/v1
```

## Code Generation

Run build runner after model changes:

```bash
flutter pub run build_runner build --delete-conflicting-outputs
```

Watch mode for development:

```bash
flutter pub run build_runner watch --delete-conflicting-outputs
```

## Database Schema

The Drift database (`app_database.dart`) mirrors the backend PostgreSQL schema with 35+ tables:

- **Core**: Organizations, Users, Warehouses
- **Products**: Products, Categories, UOMs, Batches
- **Sales**: Customers, Sales Orders, Order Lines
- **Purchase**: Suppliers, Purchase Orders, Order Lines
- **Manufacturing**: BOMs, Work Orders, Production Entries, Quality Checks
- **Finance**: Chart of Accounts, Journal Entries, Expense Claims, GST Returns
- **HR**: Attendance, Shifts, Leave Applications
- **Logistics**: Vehicles, Drivers, Delivery Trips, Routes

## Offline Sync

The `SyncService` handles:

1. **Outbound Queue**: Local mutations queued in `sync_queue` table
2. **Conflict Resolution**: Server-wins with manual override option
3. **Background Sync**: WorkManager for periodic background sync
4. **Connectivity Awareness**: Automatic sync on network restoration
5. **Progress Tracking**: Real-time sync status in UI

## Testing

```bash
# Unit tests
flutter test

# Integration tests
flutter test integration_test/

# Coverage
flutter test --coverage
genhtml coverage/lcov.info -o coverage/html
```

## Building

### Android

```bash
flutter build apk --release
flutter build appbundle --release
```

### iOS

```bash
flutter build ios --release
```

## Architecture Decisions

1. **Drift over SQLite**: Type-safe, reactive queries with compile-time verification
2. **Riverpod over Provider**: Compile-time safety, better testing, no context dependency
3. **Freezed for Models**: Immutable, copyWith, pattern matching, JSON serialization
4. **GoRouter over Navigator 2.0**: Declarative, deep linking, web support
5. **Repository Pattern**: Testable, swappable data sources (local/remote)

## Contributing

1. Follow the existing code style (enforced by `analysis_options.yaml`)
2. Write tests for new features
3. Run `flutter analyze` and `flutter test` before PR
4. Update documentation for API changes

## License

Proprietary - SuperBoard ERP