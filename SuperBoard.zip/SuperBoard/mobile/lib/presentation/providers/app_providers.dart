import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:superboard_mobile/core/config/app_config.dart';
import 'package:superboard_mobile/data/database/app_database.dart';
import 'package:superboard_mobile/data/repositories/organization_repository.dart';
import 'package:superboard_mobile/data/repositories/user_repository.dart';
import 'package:superboard_mobile/data/repositories/product_repository.dart';
import 'package:superboard_mobile/data/repositories/customer_repository.dart';
import 'package:superboard_mobile/data/repositories/sales_order_repository.dart';
import 'package:superboard_mobile/data/sync/sync_service.dart';

// Database provider
final appDatabaseProvider = Provider<AppDatabase>((ref) {
  return AppConfig.database;
});

// Repository providers
final organizationRepositoryProvider = Provider<OrganizationRepository>((ref) {
  return OrganizationRepository(ref.watch(appDatabaseProvider));
});

final userRepositoryProvider = Provider<UserRepository>((ref) {
  return UserRepository(ref.watch(appDatabaseProvider));
});

final productRepositoryProvider = Provider<ProductRepository>((ref) {
  return ProductRepository(ref.watch(appDatabaseProvider));
});

final customerRepositoryProvider = Provider<CustomerRepository>((ref) {
  return CustomerRepository(ref.watch(appDatabaseProvider));
});

final salesOrderRepositoryProvider = Provider<SalesOrderRepository>((ref) {
  return SalesOrderRepository(ref.watch(appDatabaseProvider));
});

// Sync service provider
final syncServiceProvider = Provider<SyncService>((ref) {
  return SyncService(
    database: ref.watch(appDatabaseProvider),
    organizationRepository: ref.watch(organizationRepositoryProvider),
    userRepository: ref.watch(userRepositoryProvider),
    productRepository: ref.watch(productRepositoryProvider),
    customerRepository: ref.watch(customerRepositoryProvider),
    salesOrderRepository: ref.watch(salesOrderRepositoryProvider),
  );
});

// Auth state provider
final authStateProvider = StateProvider<AuthState>((ref) => AuthState.unauthenticated);

enum AuthState {
  unauthenticated,
  authenticating,
  authenticated,
  error,
}

// Current user provider
final currentUserProvider = StateProvider<UserData?>((ref) => null);

// Current organization provider
final currentOrganizationProvider = StateProvider<OrganizationData?>((ref) => null);

// Connectivity provider
final connectivityProvider = StreamProvider<List<ConnectivityResult>>((ref) {
  return AppConfig.connectivity.onConnectivityChanged;
});