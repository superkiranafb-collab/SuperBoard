import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final bool isLoading;
  final bool isFullWidth;
  final double? width;
  final double? height;
  final Color? backgroundColor;
  final Color? foregroundColor;
  final IconData? leadingIcon;
  final IconData? trailingIcon;
  final ButtonStyle? style;
  
  const CustomButton({
    super.key,
    required this.text,
    this.onPressed,
    this.isLoading = false,
    this.isFullWidth = false,
    this.width,
    this.height,
    this.backgroundColor,
    this.foregroundColor,
    this.leadingIcon,
    this.trailingIcon,
    this.style,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final effectiveStyle = style ?? theme.elevatedButtonTheme.style;
    
    final child = isLoading
        ? SizedBox(
            width: 20.w,
            height: 20.w,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(
                foregroundColor ?? theme.colorScheme.onPrimary,
              ),
            ),
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (leadingIcon != null) ...[
                Icon(leadingIcon, size: 18.w),
                SizedBox(width: 8.w),
              ],
              Text(
                text,
                style: theme.textTheme.labelLarge?.copyWith(
                  color: foregroundColor ?? theme.colorScheme.onPrimary,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (trailingIcon != null) ...[
                SizedBox(width: 8.w),
                Icon(trailingIcon, size: 18.w),
              ],
            ],
          );
    
    final button = ElevatedButton(
      onPressed: isLoading ? null : onPressed,
      style: effectiveStyle?.copyWith(
        backgroundColor: WidgetStateProperty.all(backgroundColor ?? theme.colorScheme.primary),
        foregroundColor: WidgetStateProperty.all(foregroundColor ?? theme.colorScheme.onPrimary),
        fixedSize: WidgetStateProperty.all(
          Size(
            isFullWidth ? double.infinity : (width ?? 0),
            height ?? 48.h,
          ),
        ),
      ),
      child: child,
    );
    
    if (isFullWidth) {
      return SizedBox(width: double.infinity, child: button);
    }
    
    return button;
  }
}

class CustomOutlinedButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final bool isLoading;
  final bool isFullWidth;
  final double? width;
  final double? height;
  final Color? borderColor;
  final Color? foregroundColor;
  final IconData? leadingIcon;
  final IconData? trailingIcon;
  
  const CustomOutlinedButton({
    super.key,
    required this.text,
    this.onPressed,
    this.isLoading = false,
    this.isFullWidth = false,
    this.width,
    this.height,
    this.borderColor,
    this.foregroundColor,
    this.leadingIcon,
    this.trailingIcon,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    final child = isLoading
        ? SizedBox(
            width: 20.w,
            height: 20.w,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(
                foregroundColor ?? theme.colorScheme.primary,
              ),
            ),
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (leadingIcon != null) ...[
                Icon(leadingIcon, size: 18.w),
                SizedBox(width: 8.w),
              ],
              Text(
                text,
                style: theme.textTheme.labelLarge?.copyWith(
                  color: foregroundColor ?? theme.colorScheme.primary,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (trailingIcon != null) ...[
                SizedBox(width: 8.w),
                Icon(trailingIcon, size: 18.w),
              ],
            ],
          );
    
    final button = OutlinedButton(
      onPressed: isLoading ? null : onPressed,
      style: OutlinedButton.styleFrom(
        foregroundColor: foregroundColor ?? theme.colorScheme.primary,
        side: BorderSide(
          color: borderColor ?? theme.colorScheme.primary,
          width: 1.5,
        ),
        fixedSize: Size(
          isFullWidth ? double.infinity : (width ?? 0),
          height ?? 48.h,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: child,
    );
    
    if (isFullWidth) {
      return SizedBox(width: double.infinity, child: button);
    }
    
    return button;
  }
}

class CustomTextButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final bool isLoading;
  final Color? foregroundColor;
  final IconData? leadingIcon;
  final IconData? trailingIcon;
  
  const CustomTextButton({
    super.key,
    required this.text,
    this.onPressed,
    this.isLoading = false,
    this.foregroundColor,
    this.leadingIcon,
    this.trailingIcon,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    final child = isLoading
        ? SizedBox(
            width: 16.w,
            height: 16.w,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(
                foregroundColor ?? theme.colorScheme.primary,
              ),
            ),
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (leadingIcon != null) ...[
                Icon(leadingIcon, size: 16.w),
                SizedBox(width: 6.w),
              ],
              Text(
                text,
                style: theme.textTheme.labelLarge?.copyWith(
                  color: foregroundColor ?? theme.colorScheme.primary,
                  fontWeight: FontWeight.w500,
                ),
              ),
              if (trailingIcon != null) ...[
                SizedBox(width: 6.w),
                Icon(trailingIcon, size: 16.w),
              ],
            ],
          );
    
    return TextButton(
      onPressed: isLoading ? null : onPressed,
      style: TextButton.styleFrom(
        foregroundColor: foregroundColor ?? theme.colorScheme.primary,
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
      child: child,
    );
  }
}