import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:superboard_mobile/core/theme/app_theme.dart';
import 'package:superboard_mobile/presentation/widgets/custom_button.dart';
import 'package:superboard_mobile/presentation/widgets/custom_text_field.dart';
import 'package:superboard_mobile/presentation/widgets/dashboard_card.dart';

class SalesScreen extends ConsumerStatefulWidget {
  const SalesScreen({super.key});

  @override
  ConsumerState<SalesScreen> createState() => _SalesScreenState();
}

class _SalesScreenState extends ConsumerState<SalesScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _searchController = TextEditingController();
  String _selectedStatus = 'All';
  
  final List<String> _statusFilters = ['All', 'Draft', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'];
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }
  
  @override
  void dispose() {
    _tabController.dispose()
    _searchController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sales'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Orders'),
            Tab(text: 'Customers'),
            Tab(text: 'Quotations'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list_rounded),
            onPressed: _showFilterBottomSheet,
          ),
          IconButton(
            icon: const Icon(Icons.add_rounded),
            onPressed: _showCreateOrderDialog,
          ),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: EdgeInsets.all(16.w),
            child: CustomTextField(
              controller: _searchController,
              label: 'Search Orders',
              hint: 'Search by order number, customer...',
              prefixIcon: Icons.search_rounded,
              onFieldSubmitted: (_) => setState(() {}),
            ),
          ),
          // Status filter chips
          SizedBox(
            height: 48.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              itemCount: _statusFilters.length,
              itemBuilder: (context, index) {
                final status = _statusFilters[index];
                final isSelected = _selectedStatus == status;
                return Padding(
                  padding: EdgeInsets.only(right: 8.w),
                  child: FilterChip(
                    label: Text(status),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() {
                        _selectedStatus = status;
                      });
                    },
                    selectedColor: _getStatusColor(status).withOpacity(0.2),
                    checkmarkColor: _getStatusColor(status),
                    labelStyle: TextStyle(
                      color: isSelected ? _getStatusColor(status) : null,
                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                    ),
                    side: BorderSide(
                      color: isSelected ? _getStatusColor(status) : Theme.of(context).dividerColor,
                    ),
                  ),
                );
              },
            ),
          ),
          // Tab content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildOrdersTab(),
                _buildCustomersTab(),
                _buildQuotationsTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildOrdersTab() {
    final orders = [
      _mockOrder('SO-2024-001', 'Acme Corporation', 'Confirmed', '₹45,000', '2024-01-15', AppTheme.successGreen),
      _mockOrder('SO-2024-002', 'Global Traders', 'Shipped', '₹1,25,000', '2024-01-14', AppTheme.infoBlue),
      _mockOrder('SO-2024-003', 'Metro Distributors', 'Delivered', '₹78,500', '2024-01-13', AppTheme.primaryColor),
      _mockOrder('SO-2024-004', 'Quick Mart', 'Draft', '₹32,000', '2024-01-15', AppTheme.warningOrange),
      _mockOrder('SO-2024-005', 'Super Retail', 'Cancelled', '₹15,000', '2024-01-12', AppTheme.errorColor),
    ];
    
    return ListView.builder(
      padding: EdgeInsets.all(16.w),
      itemCount: orders.length,
      itemBuilder: (context, index) {
        final order = orders[index];
        return _buildOrderCard(context, order);
      },
    );
  }
  
  Widget _buildCustomersTab() {
    final customers = [
      _mockCustomer('CUST-001', 'Acme Corporation', 'Rajesh Kumar', 'rajesh@acme.com', '+91-9876543210', '₹2,50,000', '₹5,00,000', AppTheme.successGreen),
      _mockCustomer('CUST-002', 'Global Traders', 'Priya Sharma', 'priya@global.com', '+91-9876543211', '₹1,80,000', '₹3,00,000', AppTheme.infoBlue),
      _mockCustomer('CUST-003', 'Metro Distributors', 'Amit Singh', 'amit@metro.com', '+91-9876543212', '₹3,20,000', '₹5,00,000', AppTheme.primaryColor),
      _mockCustomer('CUST-004', 'Quick Mart', 'Neha Patel', 'neha@quickmart.com', '+91-9876543213', '₹75,000', '₹1,00,000', AppTheme.warningOrange),
    ];
    
    return ListView.builder(
      padding: EdgeInsets.all(16.w),
      itemCount: customers.length,
      itemBuilder: (context, index) {
        final customer = customers[index];
        return _buildCustomerCard(context, customer);
      },
    );
  }
  
  Widget _buildQuotationsTab() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.description_outlined, size: 64.w, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.3)),
          SizedBox(height: 16.h),
          Text(
            'Quotations',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            'Sales quotations will appear here',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.4),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
  
  Widget _buildOrderCard(BuildContext context, _MockOrder order) {
    return DashboardCard(
      margin: EdgeInsets.only(bottom: 12.h),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 48.w,
                height: 48.w,
                decoration: BoxDecoration(
                  color: order.statusColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  Icons.shopping_cart_rounded,
                  size: 24.w,
                  color: order.statusColor,
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            order.orderNumber,
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                          decoration: BoxDecoration(
                            color: order.statusColor.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            order.status,
                            style: Theme.of(context).textTheme.labelSmall?.copyWith(
                              color: order.statusColor,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 4.h),
                    Text(
                      order.customerName,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    order.amount,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    order.date,
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                    ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 12.h),
          Row(
            children: [
              Expanded(
                child: CustomOutlinedButton(
                  text: 'View',
                  onPressed: () {},
                  isFullWidth: true,
                  leadingIcon: Icons.visibility_rounded,
                ),
              ),
              SizedBox(width: 8.w),
              Expanded(
                child: CustomButton(
                  text: order.status == 'Draft' ? 'Confirm' : 'Details',
                  onPressed: () {},
                  isFullWidth: true,
                  backgroundColor: order.status == 'Draft' ? AppTheme.successGreen : null,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildCustomerCard(BuildContext context, _MockCustomer customer) {
    return DashboardCard(
      margin: EdgeInsets.only(bottom: 12.h),
      child: Row(
        children: [
          CircleAvatar(
            radius: 24.w,
            backgroundColor: customer.statusColor.withOpacity(0.15),
            child: Text(
              customer.name.split(' ').map((n) => n[0]).take(2).join(),
              style: TextStyle(
                color: customer.statusColor,
                fontWeight: FontWeight.w600,
                fontSize: 14.sp,
              ),
            ),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        customer.name,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 2.h),
                      decoration: BoxDecoration(
                        color: customer.statusColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        customer.code,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: customer.statusColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 2.h),
                Text(
                  customer.contactPerson,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                  ),
                ),
                SizedBox(height: 2.h),
                Row(
                  children: [
                    Icon(Icons.email_outlined, size: 12.w, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5)),
                    SizedBox(width: 4.w),
                    Expanded(
                      child: Text(
                        customer.email,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              _buildAmountRow('Outstanding', customer.outstanding, customer.statusColor),
              _buildAmountRow('Credit Limit', customer.creditLimit, AppTheme.infoBlue),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildAmountRow(String label, String amount, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
          ),
        ),
        Text(
          amount,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w600,
            color: color,
          ),
        ),
      ],
    );
  }
  
  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return AppTheme.successGreen;
      case 'shipped':
        return AppTheme.infoBlue;
      case 'delivered':
        return AppTheme.primaryColor;
      case 'draft':
        return AppTheme.warningOrange;
      case 'cancelled':
        return AppTheme.errorColor;
      default:
        return Theme.of(context).colorScheme.onSurface.withOpacity(0.5);
    }
  }
  
  void _showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.all(20.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Filter Orders',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 16.h),
              Wrap(
                spacing: 8.w,
                runSpacing: 8.h,
                children: _statusFilters.map((status) {
                  final isSelected = _selectedStatus == status;
                  return FilterChip(
                    label: Text(status),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() {
                        _selectedStatus = status;
                      });
                      Navigator.pop(context);
                    },
                    selectedColor: _getStatusColor(status).withOpacity(0.2),
                    checkmarkColor: _getStatusColor(status),
                  );
                }).toList(),
              ),
              SizedBox(height: 16.h),
            ],
          ),
        );
      },
    );
  }
  
  void _showCreateOrderDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Create Sales Order'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CustomTextField(
                label: 'Customer',
                hint: 'Select customer',
                prefixIcon: Icons.person_rounded,
              ),
              SizedBox(height: 16.h),
              CustomTextField(
                label: 'Warehouse',
                hint: 'Select warehouse',
                prefixIcon: Icons.warehouse_rounded,
              ),
              SizedBox(height: 16.h),
              CustomTextField(
                label: 'Expected Date',
                hint: 'Select date',
                prefixIcon: Icons.calendar_today_rounded,
              ),
            ],
          ),
        ),
        actions: [
          CustomTextButton(text: 'Cancel', onPressed: () => Navigator.pop(context)),
          CustomButton(text: 'Create Order', onPressed: () => Navigator.pop(context)),
        ],
      ),
    );
  }
  
  _MockOrder _mockOrder(String orderNumber, String customerName, String status, String amount, String date, Color statusColor) {
    return _MockOrder(
      orderNumber: orderNumber,
      customerName: customerName,
      status: status,
      amount: amount,
      date: date,
      statusColor: statusColor,
    );
  }
  
  _MockCustomer _mockCustomer(String code, String name, String contactPerson, String email, String phone, String outstanding, String creditLimit, Color statusColor) {
    return _MockCustomer(
      code: code,
      name: name,
      contactPerson: contactPerson,
      email: email,
      phone: phone,
      outstanding: outstanding,
      creditLimit: creditLimit,
      statusColor: statusColor,
    );
  }
}

class _MockOrder {
  final String orderNumber;
  final String customerName;
  final String status;
  final String amount;
  final String date;
  final Color statusColor;
  
  _MockOrder({
    required this.orderNumber,
    required this.customerName,
    required this.status,
    required this.amount,
    required this.date,
    required this.statusColor,
  });
}

class _MockCustomer {
  final String code;
  final String name;
  final String contactPerson;
  final String email;
  final String phone;
  final String outstanding;
  final String creditLimit;
  final Color statusColor;
  
  _MockCustomer({
    required this.code,
    required this.name,
    required this.contactPerson,
    required this.email,
    required this.phone,
    required this.outstanding,
    required this.creditLimit,
    required this.statusColor,
  });
}