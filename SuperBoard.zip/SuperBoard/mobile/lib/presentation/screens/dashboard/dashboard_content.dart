import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:superboard_mobile/core/theme/app_theme.dart';
import 'package:superboard_mobile/presentation/widgets/dashboard_card.dart';
import 'package:superboard_mobile/presentation/widgets/stat_card.dart';

class DashboardContent extends ConsumerWidget {
  const DashboardContent({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {
              // TODO: Show notifications
            },
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () {
              // TODO: Show settings
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          // TODO: Refresh dashboard data
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: EdgeInsets.all(16.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome section
              _buildWelcomeSection(context),
              SizedBox(height: 24.h),
              // Stats grid
              _buildStatsGrid(context),
              SizedBox(height: 24.h),
              // Quick actions
              _buildQuickActions(context),
              SizedBox(height: 24.h),
              // Recent activity
              _buildRecentActivity(context),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildWelcomeSection(BuildContext context) {
    final hour = DateTime.now().hour;
    String greeting;
    if (hour < 12) {
      greeting = 'Good Morning';
    } else if (hour < 17) {
      greeting = 'Good Afternoon';
    } else {
      greeting = 'Good Evening';
    }
    
    return Container(
      padding: EdgeInsets.all(20.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.primaryColor,
            AppTheme.primaryDark,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryColor.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$greeting! 👋',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  'Here\'s what\'s happening with your business today',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Colors.white.withOpacity(0.9),
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 60.w,
            height: 60.w,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(
              Icons.trending_up_rounded,
              size: 30.w,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildStatsGrid(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12.w,
      mainAxisSpacing: 12.h,
      childAspectRatio: 1.6,
      children: [
        StatCard(
          title: 'Total Revenue',
          value: '₹12.5L',
          subtitle: '+12.5% vs last month',
          icon: Icons.attach_money_rounded,
          iconColor: AppTheme.successGreen,
          backgroundColor: AppTheme.successGreen.withOpacity(0.1),
          trend: Trend.up,
        ),
        StatCard(
          title: 'Pending Orders',
          value: '24',
          subtitle: '5 urgent',
          icon: Icons.shopping_cart_rounded,
          iconColor: AppTheme.warningOrange,
          backgroundColor: AppTheme.warningOrange.withOpacity(0.1),
          trend: Trend.neutral,
        ),
        StatCard(
          title: 'Low Stock Items',
          value: '8',
          subtitle: 'Reorder needed',
          icon: Icons.inventory_rounded,
          iconColor: AppTheme.errorColor,
          backgroundColor: AppTheme.errorColor.withOpacity(0.1),
          trend: Trend.down,
        ),
        StatCard(
          title: 'Active Production',
          value: '3',
          subtitle: '2 completing today',
          icon: Icons.factory_rounded,
          iconColor: AppTheme.infoBlue,
          backgroundColor: AppTheme.infoBlue.withOpacity(0.1),
          trend: Trend.up,
        ),
      ],
    );
  }
  
  Widget _buildQuickActions(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Actions',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 12.h),
        GridView.count(
          crossAxisCount: 4,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12.w,
          mainAxisSpacing: 12.h,
          childAspectRatio: 1.0,
          children: [
            _buildActionItem(
              context,
              icon: Icons.add_shopping_cart_rounded,
              label: 'New Order',
              color: AppTheme.primaryColor,
              onTap: () => context.go('/sales?action=new'),
            ),
            _buildActionItem(
              context,
              icon: Icons.inventory_rounded,
              label: 'Stock Check',
              color: AppTheme.successGreen,
              onTap: () => context.go('/inventory'),
            ),
            _buildActionItem(
              context,
              icon: Icons.factory_rounded,
              label: 'New Production',
              color: AppTheme.warningOrange,
              onTap: () => context.go('/manufacturing?action=new'),
            ),
            _buildActionItem(
              context,
              icon: Icons.local_shipping_rounded,
              label: 'Create Trip',
              color: AppTheme.infoBlue,
              onTap: () {},
            ),
            _buildActionItem(
              context,
              icon: Icons.person_add_rounded,
              label: 'New Customer',
              color: AppTheme.secondaryColor,
              onTap: () {},
            ),
            _buildActionItem(
              context,
              icon: Icons.receipt_long_rounded,
              label: 'Expense Claim',
              color: AppTheme.accentColor,
              onTap: () {},
            ),
            _buildActionItem(
              context,
              icon: Icons.assignment_rounded,
              label: 'Leave Request',
              color: Colors.purple,
              onTap: () {},
            ),
            _buildActionItem(
              context,
              icon: Icons.smart_toy_rounded,
              label: 'AI Assistant',
              color: Colors.deepPurple,
              onTap: () {},
            ),
          ],
        ),
      ],
    );
  }
  
  Widget _buildActionItem(
    BuildContext context, {
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: EdgeInsets.all(12.w),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 44.w,
              height: 44.w,
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, size: 22.w, color: color),
            ),
            SizedBox(height: 8.h),
            Text(
              label,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                fontWeight: FontWeight.w500,
                color: Theme.of(context).colorScheme.onSurface,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildRecentActivity(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Recent Activity',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            TextButton(
              onPressed: () {},
              child: const Text('View All'),
            ),
          ],
        ),
        SizedBox(height: 12.h),
        DashboardCard(
          child: Column(
            children: [
              _buildActivityItem(
                context,
                icon: Icons.shopping_cart_rounded,
                iconColor: AppTheme.primaryColor,
                title: 'New Sales Order #SO-2024-001',
                subtitle: 'Acme Corporation • ₹45,000',
                time: '2 min ago',
              ),
              _buildActivityItem(
                context,
                icon: Icons.inventory_rounded,
                iconColor: AppTheme.successGreen,
                title: 'Stock Receipt #GRN-2024-015',
                subtitle: 'Raw Materials • 500 units received',
                time: '15 min ago',
              ),
              _buildActivityItem(
                context,
                icon: Icons.factory_rounded,
                iconColor: AppTheme.warningOrange,
                title: 'Production Completed #WO-2024-042',
                subtitle: 'Orange Juice Batch #B-2024-089',
                time: '1 hour ago',
              ),
              _buildActivityItem(
                context,
                icon: Icons.local_shipping_rounded,
                iconColor: AppTheme.infoBlue,
                title: 'Delivery Trip #DT-2024-156',
                subtitle: 'Mumbai Route • 8 stops completed',
                time: '3 hours ago',
              ),
              _buildActivityItem(
                context,
                icon: Icons.warning_rounded,
                iconColor: AppTheme.errorColor,
                title: 'Low Stock Alert',
                subtitle: 'Sugar (50kg bags) • Below reorder level',
                time: '5 hours ago',
              ),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _buildActivityItem(
    BuildContext context, {
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required String time,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 10.h),
      child: Row(
        children: [
          Container(
            width: 40.w,
            height: 40.w,
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 20.w, color: iconColor),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                SizedBox(height: 2.h),
                Text(
                  subtitle,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          Text(
            time,
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
            ),
          ),
        ],
      ),
    );
  }
}