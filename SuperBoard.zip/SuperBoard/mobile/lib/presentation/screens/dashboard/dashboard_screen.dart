import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:superboard_mobile/core/theme/app_theme.dart';
import 'package:superboard_mobile/presentation/screens/dashboard/dashboard_content.dart';
import 'package:superboard_mobile/presentation/screens/inventory/inventory_screen.dart';
import 'package:superboard_mobile/presentation/screens/sales/sales_screen.dart';
import 'package:superboard_mobile/presentation/screens/manufacturing/manufacturing_screen.dart';

class DashboardScreen extends ConsumerStatefulWidget {
  final Widget child;
  
  const DashboardScreen({super.key, required this.child});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  int _currentIndex = 0;
  
  final List<_NavItem> _navItems = [
    _NavItem(
      icon: Icons.dashboard_rounded,
      activeIcon: Icons.dashboard_rounded,
      label: 'Dashboard',
      route: '/dashboard',
    ),
    _NavItem(
      icon: Icons.inventory_2_outlined,
      activeIcon: Icons.inventory_2_rounded,
      label: 'Inventory',
      route: '/inventory',
    ),
    _NavItem(
      icon: Icons.shopping_cart_outlined,
      activeIcon: Icons.shopping_cart_rounded,
      label: 'Sales',
      route: '/sales',
    ),
    _NavItem(
      icon: Icons.factory_outlined,
      activeIcon: Icons.factory_rounded,
      label: 'Manufacturing',
      route: '/manufacturing',
    ),
  ];
  
  void _onItemTapped(int index) {
    if (_currentIndex != index) {
      setState(() {
        _currentIndex = index;
      });
      context.go(_navItems[index].route);
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: widget.child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: _onItemTapped,
        height: 72.h,
        indicatorColor: AppTheme.primaryColor.withOpacity(0.1),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        destinations: _navItems.map((item) {
          final isSelected = _navItems.indexOf(item) == _currentIndex;
          return NavigationDestination(
            icon: Icon(item.icon, size: 24),
            selectedIcon: Icon(item.activeIcon, size: 24),
            label: item.label,
          );
        }).toList(),
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final IconData activeIcon;
  final String label;
  final String route;
  
  _NavItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.route,
  });
}