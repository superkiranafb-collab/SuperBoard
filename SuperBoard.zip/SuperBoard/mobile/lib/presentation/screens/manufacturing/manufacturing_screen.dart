import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:superboard_mobile/core/theme/app_theme.dart';
import 'package:superboard_mobile/presentation/widgets/custom_button.dart';
import 'package:superboard_mobile/presentation/widgets/custom_text_field.dart';
import 'package:superboard_mobile/presentation/widgets/dashboard_card.dart';

class ManufacturingScreen extends ConsumerStatefulWidget {
  const ManufacturingScreen({super.key});

  @override
  ConsumerState<ManufacturingScreen> createState() => _ManufacturingScreenState();
}

class _ManufacturingScreenState extends ConsumerState<ManufacturingScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _selectedStatus = 'All';
  
  final List<String> _statusFilters = ['All', 'Planned', 'In Progress', 'Completed', 'On Hold', 'Cancelled'];
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Manufacturing'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Work Orders'),
            Tab(text: 'BOMs'),
            Tab(text: 'Production'),
            Tab(text: 'Quality'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list_rounded),
            onPressed: _showFilterBottomSheet,
          ),
          IconButton(
            icon: const Icon(Icons.add_rounded),
            onPressed: _showCreateWorkOrderDialog,
          ),
        ],
      ),
      body: Column(
        children: [
          // Status filter chips
          SizedBox(
            height: 48.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              itemCount: _statusFilters.length,
              itemBuilder: (context, index) {
                final status = _statusFilters[index];
                final isSelected = _selectedStatus == status;
                return Padding(
                  padding: EdgeInsets.only(right: 8.w),
                  child: FilterChip(
                    label: Text(status),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() {
                        _selectedStatus = status;
                      });
                    },
                    selectedColor: _getStatusColor(status).withOpacity(0.2),
                    checkmarkColor: _getStatusColor(status),
                    labelStyle: TextStyle(
                      color: isSelected ? _getStatusColor(status) : null,
                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                    ),
                    side: BorderSide(
                      color: isSelected ? _getStatusColor(status) : Theme.of(context).dividerColor,
                    ),
                  ),
                );
              },
            ),
          ),
          // Tab content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildWorkOrdersTab(),
                _buildBOMsTab(),
                _buildProductionTab(),
                _buildQualityTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildWorkOrdersTab() {
    final workOrders = [
      _mockWorkOrder('WO-2024-042', 'Orange Juice 1L', 'Batch #B-2024-089', 'In Progress', 1000, 750, '2024-01-15', '2024-01-16', AppTheme.infoBlue),
      _mockWorkOrder('WO-2024-043', 'Atta Wheat Flour 10kg', 'Batch #B-2024-090', 'Planned', 500, 0, '2024-01-16', '2024-01-17', AppTheme.warningOrange),
      _mockWorkOrder('WO-2024-041', 'Apple Juice 1L', 'Batch #B-2024-088', 'Completed', 800, 800, '2024-01-14', '2024-01-15', AppTheme.successGreen),
      _mockWorkOrder('WO-2024-040', 'Mixed Fruit Juice 1L', 'Batch #B-2024-087', 'On Hold', 600, 200, '2024-01-13', '2024-01-14', AppTheme.accentColor),
    ];
    
    return ListView.builder(
      padding: EdgeInsets.all(16.w),
      itemCount: workOrders.length,
      itemBuilder: (context, index) {
        final wo = workOrders[index];
        return _buildWorkOrderCard(context, wo);
      },
    );
  }
  
  Widget _buildBOMsTab() {
    final boms = [
      _mockBOM('BOM-001', 'Orange Juice 1L', 'v1.2', 'Approved', 1000, 5, AppTheme.successGreen),
      _mockBOM('BOM-002', 'Atta Wheat Flour 10kg', 'v1.0', 'Approved', 500, 3, AppTheme.successGreen),
      _mockBOM('BOM-003', 'Apple Juice 1L', 'v1.1', 'Draft', 800, 4, AppTheme.warningOrange),
      _mockBOM('BOM-004', 'Mixed Fruit Juice 1L', 'v1.0', 'Pending Approval', 600, 6, AppTheme.infoBlue),
    ];
    
    return ListView.builder(
      padding: EdgeInsets.all(16.w),
      itemCount: boms.length,
      itemBuilder: (context, index) {
        final bom = boms[index];
        return _buildBOMCard(context, bom);
      },
    );
  }
  
  Widget _buildProductionTab() {
    final production = [
      _mockProduction('PE-2024-015', 'WO-2024-042', 'Orange Juice 1L', 'Batch #B-2024-089', 750, 10, '2024-01-15 14:30', AppTheme.successGreen),
      _mockProduction('PE-2024-014', 'WO-2024-041', 'Apple Juice 1L', 'Batch #B-2024-088', 800, 5, '2024-01-15 10:00', AppTheme.successGreen),
      _mockProduction('PE-2024-013', 'WO-2024-040', 'Mixed Fruit Juice 1L', 'Batch #B-2024-087', 200, 0, '2024-01-14 16:00', AppTheme.infoBlue),
    ];
    
    return ListView.builder(
      padding: EdgeInsets.all(16.w),
      itemCount: production.length,
      itemBuilder: (context, index) {
        final prod = production[index];
        return _buildProductionCard(context, prod);
      },
    );
  }
  
  Widget _buildQualityTab() {
    final qualityChecks = [
      _mockQuality('QC-2024-023', 'WO-2024-042', 'Orange Juice 1L', 'Final Inspection', 'Passed', '2024-01-15 15:00', AppTheme.successGreen),
      _mockQuality('QC-2024-022', 'WO-2024-041', 'Apple Juice 1L', 'In-Process Check', 'Passed', '2024-01-15 11:00', AppTheme.successGreen),
      _mockQuality('QC-2024-021', 'WO-2024-040', 'Mixed Fruit Juice 1L', 'Raw Material Check', 'Pending', '2024-01-14 17:00', AppTheme.warningOrange),
    ];
    
    return ListView.builder(
      padding: EdgeInsets.all(16.w),
      itemCount: qualityChecks.length,
      itemBuilder: (context, index) {
        final qc = qualityChecks[index];
        return _buildQualityCard(context, qc);
      },
    );
  }
  
  Widget _buildWorkOrderCard(BuildContext context, _MockWorkOrder wo) {
    final progress = wo.plannedQty > 0 ? wo.producedQty / wo.plannedQty : 0.0;
    
    return DashboardCard(
      margin: EdgeInsets.only(bottom: 12.h),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 48.w,
                height: 48.w,
                decoration: BoxDecoration(
                  color: wo.statusColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  Icons.factory_rounded,
                  size: 24.w,
                  color: wo.statusColor,
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            wo.workOrderNumber,
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                          decoration: BoxDecoration(
                            color: wo.statusColor.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            wo.status,
                            style: Theme.of(context).textTheme.labelSmall?.copyWith(
                              color: wo.statusColor,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 4.h),
                    Text(
                      wo.productName,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                      ),
                    ),
                    Text(
                      wo.batchNumber,
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${wo.producedQty}/${wo.plannedQty}',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  Text(
                    'Due: ${wo.dueDate}',
                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                    ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 12.h),
          // Progress bar
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Progress',
                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    '${(progress * 100).toInt()}%',
                    style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: wo.statusColor,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 6.h),
              LinearProgressIndicator(
                value: progress,
                backgroundColor: wo.statusColor.withOpacity(0.1),
                valueColor: AlwaysStoppedAnimation<Color>(wo.statusColor),
                minHeight: 6.h,
                borderRadius: BorderRadius.circular(3),
              ),
            ],
          ),
          SizedBox(height: 12.h),
          Row(
            children: [
              Expanded(
                child: CustomOutlinedButton(
                  text: 'View Details',
                  onPressed: () {},
                  isFullWidth: true,
                  leadingIcon: Icons.visibility_rounded,
                ),
              ),
              SizedBox(width: 8.w),
              Expanded(
                child: CustomButton(
                  text: _getActionText(wo.status),
                  onPressed: () {},
                  isFullWidth: true,
                  backgroundColor: _getActionColor(wo.status),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildBOMCard(BuildContext context, _MockBOM bom) {
    return DashboardCard(
      margin: EdgeInsets.only(bottom: 12.h),
      child: Row(
        children: [
          Container(
            width: 48.w,
            height: 48.w,
            decoration: BoxDecoration(
              color: bom.statusColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              Icons.assignment_rounded,
              size: 24.w,
              color: bom.statusColor,
            ),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        bom.productName,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                      decoration: BoxDecoration(
                        color: bom.statusColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        bom.status,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: bom.statusColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.h),
                Text(
                  '${bom.code} • Version ${bom.version}',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                  ),
                ),
                SizedBox(height: 4.h),
                Row(
                  children: [
                    _buildInfoChip(Icons.production_quantity_limits_rounded, '${bom.yieldQty} units', AppTheme.primaryColor),
                    SizedBox(width: 8.w),
                    _buildInfoChip(Icons.inventory_rounded, '${bom.components} components', AppTheme.infoBlue),
                  ],
                ),
              ],
            ),
          ),
          IconButton(
            icon: Icon(Icons.more_vert_rounded, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5)),
            onPressed: () {},
          ),
        ],
      ),
    );
  }
  
  Widget _buildProductionCard(BuildContext context, _MockProduction prod) {
    return DashboardCard(
      margin: EdgeInsets.only(bottom: 12.h),
      child: Row(
        children: [
          Container(
            width: 48.w,
            height: 48.w,
            decoration: BoxDecoration(
              color: prod.statusColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              Icons.production_quantity_limits_rounded,
              size: 24.w,
              color: prod.statusColor,
            ),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        prod.entryNumber,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Text(
                      prod.workOrderNumber,
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.h),
                Text(
                  prod.productName,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                  ),
                ),
                Text(
                  prod.batchNumber,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${prod.quantityProduced} units',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
              if (prod.quantityRejected > 0) ...[
                SizedBox(height: 2.h),
                Text(
                  '${prod.quantityRejected} rejected',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: AppTheme.errorColor,
                  ),
                ),
              ],
              SizedBox(height: 2.h),
              Text(
                prod.timestamp,
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildQualityCard(BuildContext context, _MockQuality qc) {
    return DashboardCard(
      margin: EdgeInsets.only(bottom: 12.h),
      child: Row(
        children: [
          Container(
            width: 48.w,
            height: 48.w,
            decoration: BoxDecoration(
              color: qc.statusColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              Icons.verified_rounded,
              size: 24.w,
              color: qc.statusColor,
            ),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        qc.checkNumber,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                      decoration: BoxDecoration(
                        color: qc.statusColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        qc.result,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: qc.statusColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.h),
                Text(
                  qc.productName,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                  ),
                ),
                Text(
                  qc.checkType,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                qc.workOrderNumber,
                style: Theme.of(context).textTheme.labelMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                ),
              ),
              SizedBox(height: 2.h),
              Text(
                qc.timestamp,
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildInfoChip(IconData icon, String text, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12.w, color: color),
          SizedBox(width: 4.w),
          Text(
            text,
            style: TextStyle(
              fontSize: 11.sp,
              fontWeight: FontWeight.w500,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
  
  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
      case 'approved':
        return AppTheme.successGreen;
      case 'in progress':
        return AppTheme.infoBlue;
      case 'planned':
      case 'draft':
        return AppTheme.warningOrange;
      case 'on hold':
      case 'pending approval':
        return AppTheme.accentColor;
      case 'cancelled':
        return AppTheme.errorColor;
      default:
        return Theme.of(context).colorScheme.onSurface.withOpacity(0.5);
    }
  }
  
  String _getActionText(String status) {
    switch (status.toLowerCase()) {
      case 'planned':
        return 'Start';
      case 'in progress':
        return 'Record Production';
      case 'on hold':
        return 'Resume';
      default:
        return 'Details';
    }
  }
  
  Color? _getActionColor(String status) {
    switch (status.toLowerCase()) {
      case 'planned':
        return AppTheme.successGreen;
      case 'in progress':
        return AppTheme.primaryColor;
      case 'on hold':
        return AppTheme.warningOrange;
      default:
        return null;
    }
  }
  
  void _showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.all(20.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Filter Work Orders',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 16.h),
              Wrap(
                spacing: 8.w,
                runSpacing: 8.h,
                children: _statusFilters.map((status) {
                  final isSelected = _selectedStatus == status;
                  return FilterChip(
                    label: Text(status),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() {
                        _selectedStatus = status;
                      });
                      Navigator.pop(context);
                    },
                    selectedColor: _getStatusColor(status).withOpacity(0.2),
                    checkmarkColor: _getStatusColor(status),
                  );
                }).toList(),
              ),
              SizedBox(height: 16.h),
            ],
          ),
        );
      },
    );
  }
  
  void _showCreateWorkOrderDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Create Work Order'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CustomTextField(
                label: 'BOM',
                hint: 'Select Bill of Materials',
                prefixIcon: Icons.assignment_rounded,
              ),
              SizedBox(height: 16.h),
              CustomTextField(
                label: 'Product',
                hint: 'Select product to manufacture',
                prefixIcon: Icons.inventory_rounded,
              ),
              SizedBox(height: 16.h),
              CustomTextField(
                label: 'Planned Quantity',
                hint: 'Enter quantity',
                prefixIcon: Icons.production_quantity_limits_rounded,
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 16.h),
              CustomTextField(
                label: 'Work Center',
                hint: 'Select work center',
                prefixIcon: Icons.factory_rounded,
              ),
            ],
          ),
        ),
        actions: [
          CustomTextButton(text: 'Cancel', onPressed: () => Navigator.pop(context)),
          CustomButton(text: 'Create Work Order', onPressed: () => Navigator.pop(context)),
        ],
      ),
    );
  }
  
  _MockWorkOrder _mockWorkOrder(String woNumber, String productName, String batchNumber, String status, int plannedQty, int producedQty, String startDate, String dueDate, Color statusColor) {
    return _MockWorkOrder(
      workOrderNumber: woNumber,
      productName: productName,
      batchNumber: batchNumber,
      status: status,
      plannedQty: plannedQty,
      producedQty: producedQty,
      startDate: startDate,
      dueDate: dueDate,
      statusColor: statusColor,
    );
  }
  
  _MockBOM _mockBOM(String code, String productName, String version, String status, int yieldQty, int components, Color statusColor) {
    return _MockBOM(
      code: code,
      productName: productName,
      version: version,
      status: status,
      yieldQty: yieldQty,
      components: components,
      statusColor: statusColor,
    );
  }
  
  _MockProduction _mockProduction(String entryNumber, String woNumber, String productName, String batchNumber, int qtyProduced, int qtyRejected, String timestamp, Color statusColor) {
    return _MockProduction(
      entryNumber: entryNumber,
      workOrderNumber: woNumber,
      productName: productName,
      batchNumber: batchNumber,
      quantityProduced: qtyProduced,
      quantityRejected: qtyRejected,
      timestamp: timestamp,
      statusColor: statusColor,
    );
  }
  
  _MockQuality _mockQuality(String checkNumber, String woNumber, String productName, String checkType, String result, String timestamp, Color statusColor) {
    return _MockQuality(
      checkNumber: checkNumber,
      workOrderNumber: woNumber,
      productName: productName,
      checkType: checkType,
      result: result,
      timestamp: timestamp,
      statusColor: statusColor,
    );
  }
}

class _MockWorkOrder {
  final String workOrderNumber;
  final String productName;
  final String batchNumber;
  final String status;
  final int plannedQty;
  final int producedQty;
  final String startDate;
  final String dueDate;
  final Color statusColor;
  
  _MockWorkOrder({
    required this.workOrderNumber,
    required this.productName,
    required this.batchNumber,
    required this.status,
    required this.plannedQty,
    required this.producedQty,
    required this.startDate,
    required this.dueDate,
    required this.statusColor,
  });
}

class _MockBOM {
  final String code;
  final String productName;
  final String version;
  final String status;
  final int yieldQty;
  final int components;
  final Color statusColor;
  
  _MockBOM({
    required this.code,
    required this.productName,
    required this.version,
    required this.status,
    required this.yieldQty,
    required this.components,
    required this.statusColor,
  });
}

class _MockProduction {
  final String entryNumber;
  final String workOrderNumber;
  final String productName;
  final String batchNumber;
  final int quantityProduced;
  final int quantityRejected;
  final String timestamp;
  final Color statusColor;
  
  _MockProduction({
    required this.entryNumber,
    required this.workOrderNumber,
    required this.productName,
    required this.batchNumber,
    required this.quantityProduced,
    required this.quantityRejected,
    required this.timestamp,
    required this.statusColor,
  });
}

class _MockQuality {
  final String checkNumber;
  final String workOrderNumber;
  final String productName;
  final String checkType;
  final String result;
  final String timestamp;
  final Color statusColor;
  
  _MockQuality({
    required this.checkNumber,
    required this.workOrderNumber,
    required this.productName,
    required this.checkType,
    required this.result,
    required this.timestamp,
    required this.statusColor,
  });
}