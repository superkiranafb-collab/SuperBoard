import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:superboard_mobile/core/theme/app_theme.dart';
import 'package:superboard_mobile/presentation/widgets/custom_button.dart';
import 'package:superboard_mobile/presentation/widgets/custom_text_field.dart';
import 'package:superboard_mobile/presentation/widgets/dashboard_card.dart';

class InventoryScreen extends ConsumerStatefulWidget {
  const InventoryScreen({super.key});

  @override
  ConsumerState<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends ConsumerState<InventoryScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _searchController = TextEditingController();
  String _selectedFilter = 'All';
  
  final List<String> _filters = ['All', 'In Stock', 'Low Stock', 'Out of Stock', 'Manufactured'];
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Inventory'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Products'),
            Tab(text: 'Batches'),
            Tab(text: 'Movements'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list_rounded),
            onPressed: _showFilterBottomSheet,
          ),
          IconButton(
            icon: const Icon(Icons.add_rounded),
            onPressed: _showAddProductDialog,
          ),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: EdgeInsets.all(16.w),
            child: CustomTextField(
              controller: _searchController,
              label: 'Search Products',
              hint: 'Search by name, SKU, or category...',
              prefixIcon: Icons.search_rounded,
              onFieldSubmitted: (_) => setState(() {}),
            ),
          ),
          // Filter chips
          SizedBox(
            height: 48.h,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: 16.w),
              itemCount: _filters.length,
              itemBuilder: (context, index) {
                final filter = _filters[index];
                final isSelected = _selectedFilter == filter;
                return Padding(
                  padding: EdgeInsets.only(right: 8.w),
                  child: FilterChip(
                    label: Text(filter),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() {
                        _selectedFilter = filter;
                      });
                    },
                    selectedColor: AppTheme.primaryColor.withOpacity(0.2),
                    checkmarkColor: AppTheme.primaryColor,
                    labelStyle: TextStyle(
                      color: isSelected ? AppTheme.primaryColor : null,
                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                    ),
                    side: BorderSide(
                      color: isSelected ? AppTheme.primaryColor : Theme.of(context).dividerColor,
                    ),
                  ),
                );
              },
            ),
          ),
          // Tab content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildProductsTab(),
                _buildBatchesTab(),
                _buildMovementsTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildProductsTab() {
    // Mock data for now
    final products = [
      _mockProduct('PRD-001', 'Orange Juice 1L', 'Beverages', 1500, 50, 'kg', AppTheme.successGreen),
      _mockProduct('PRD-002', 'Atta Wheat Flour 10kg', 'Food Grains', 2500, 20, 'bags', AppTheme.warningOrange),
      _mockProduct('PRD-003', 'Apple Juice 1L', 'Beverages', 0, 100, 'units', AppTheme.errorColor),
      _mockProduct('PRD-004', 'Sugar 50kg', 'Raw Materials', 80, 100, 'bags', AppTheme.warningOrange),
      _mockProduct('PRD-005', 'Glass Bottles 1L', 'Packaging', 5000, 1000, 'units', AppTheme.successGreen),
    ];
    
    return ListView.builder(
      padding: EdgeInsets.all(16.w),
      itemCount: products.length,
      itemBuilder: (context, index) {
        final product = products[index];
        return _buildProductCard(context, product);
      },
    );
  }
  
  Widget _buildBatchesTab() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.inventory_2_outlined, size: 64.w, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.3)),
          SizedBox(height: 16.h),
          Text(
            'Batch Tracking',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            'Batch and serial number tracking will appear here',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.4),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
  
  Widget _buildMovementsTab() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.swap_horiz_outlined, size: 64.w, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.3)),
          SizedBox(height: 16.h),
          Text(
            'Stock Movements',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            'Inventory movement history will appear here',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.4),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
  
  Widget _buildProductCard(BuildContext context, _MockProduct product) {
    return DashboardCard(
      margin: EdgeInsets.only(bottom: 12.h),
      child: Row(
        children: [
          Container(
            width: 56.w,
            height: 56.w,
            decoration: BoxDecoration(
              color: product.statusColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              _getCategoryIcon(product.category),
              size: 28.w,
              color: product.statusColor,
            ),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        product.name,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 2.h),
                      decoration: BoxDecoration(
                        color: product.statusColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        product.sku,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: product.statusColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 4.h),
                Text(
                  product.category,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                  ),
                ),
                SizedBox(height: 8.h),
                Row(
                  children: [
                    _buildStockInfo(
                      context,
                      'Available',
                      product.availableStock.toString(),
                      product.unit,
                      product.statusColor,
                    ),
                    SizedBox(width: 16.w),
                    _buildStockInfo(
                      context,
                      'Reserved',
                      product.reservedStock.toString(),
                      product.unit,
                      Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
                    ),
                    SizedBox(width: 16.w),
                    _buildStockInfo(
                      context,
                      'Reorder',
                      product.reorderLevel.toString(),
                      product.unit,
                      AppTheme.warningOrange,
                    ),
                  ],
                ),
              ],
            ),
          ),
          IconButton(
            icon: Icon(Icons.more_vert_rounded, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5)),
            onPressed: () => _showProductActions(product),
          ),
        ],
      ),
    );
  }
  
  Widget _buildStockInfo(BuildContext context, String label, String value, String unit, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
          ),
        ),
        Row(
          children: [
            Text(
              value,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),
            SizedBox(width: 2.w),
            Text(
              unit,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
              ),
            ),
          ],
        ),
      ],
    );
  }
  
  IconData _getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'beverages':
        return Icons.local_drink_rounded;
      case 'food grains':
        return Icons.grain_rounded;
      case 'raw materials':
        return Icons.inventory_rounded;
      case 'packaging':
        return Icons.inventory_2_rounded;
      default:
        return Icons.category_rounded;
    }
  }
  
  void _showFilterBottomSheet() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.all(20.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Filter Products',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 16.h),
              Wrap(
                spacing: 8.w,
                runSpacing: 8.h,
                children: _filters.map((filter) {
                  final isSelected = _selectedFilter == filter;
                  return FilterChip(
                    label: Text(filter),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() {
                        _selectedFilter = filter;
                      });
                      Navigator.pop(context);
                    },
                    selectedColor: AppTheme.primaryColor.withOpacity(0.2),
                    checkmarkColor: AppTheme.primaryColor,
                  );
                }).toList(),
              ),
              SizedBox(height: 16.h),
            ],
          ),
        );
      },
    );
  }
  
  void _showAddProductDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add New Product'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CustomTextField(
                label: 'SKU',
                hint: 'Enter SKU',
                prefixIcon: Icons.qr_code_rounded,
              ),
              SizedBox(height: 16.h),
              CustomTextField(
                label: 'Product Name',
                hint: 'Enter product name',
                prefixIcon: Icons.inventory_rounded,
              ),
              SizedBox(height: 16.h),
              CustomTextField(
                label: 'Category',
                hint: 'Select category',
                prefixIcon: Icons.category_rounded,
              ),
              SizedBox(height: 16.h),
              CustomTextField(
                label: 'Unit of Measure',
                hint: 'kg, units, bags, etc.',
                prefixIcon: Icons.straighten_rounded,
              ),
            ],
          ),
        ),
        actions: [
          CustomTextButton(text: 'Cancel', onPressed: () => Navigator.pop(context)),
          CustomButton(text: 'Add Product', onPressed: () => Navigator.pop(context)),
        ],
      ),
    );
  }
  
  void _showProductActions(_MockProduct product) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.all(20.w),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(Icons.edit_rounded, color: AppTheme.primaryColor),
                title: const Text('Edit Product'),
                onTap: () => Navigator.pop(context),
              ),
              ListTile(
                leading: Icon(Icons.visibility_rounded, color: AppTheme.infoBlue),
                title: const Text('View Details'),
                onTap: () => Navigator.pop(context),
              ),
              ListTile(
                leading: Icon(Icons.add_shopping_cart_rounded, color: AppTheme.successGreen),
                title: const Text('Create Purchase Order'),
                onTap: () => Navigator.pop(context),
              ),
              ListTile(
                leading: Icon(Icons.factory_rounded, color: AppTheme.warningOrange),
                title: const Text('Create Work Order'),
                onTap: () => Navigator.pop(context),
              ),
              ListTile(
                leading: Icon(Icons.delete_rounded, color: AppTheme.errorColor),
                title: const Text('Deactivate'),
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        );
      },
    );
  }
  
  _MockProduct _mockProduct(String sku, String name, String category, int available, int reserved, String unit, Color statusColor) {
    return _MockProduct(
      sku: sku,
      name: name,
      category: category,
      availableStock: available,
      reservedStock: reserved,
      unit: unit,
      reorderLevel: 100,
      statusColor: statusColor,
    );
  }
}

class _MockProduct {
  final String sku;
  final String name;
  final String category;
  final int availableStock;
  final int reservedStock;
  final String unit;
  final int reorderLevel;
  final Color statusColor;
  
  _MockProduct({
    required this.sku,
    required this.name,
    required this.category,
    required this.availableStock,
    required this.reservedStock,
    required this.unit,
    required this.reorderLevel,
    required this.statusColor,
  });
}