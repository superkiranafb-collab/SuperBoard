import 'package:drift/drift.dart';
import 'package:superboard_mobile/data/database/app_database.dart';
import 'package:superboard_mobile/data/models/user.dart';
import 'package:superboard_mobile/data/repositories/base_repository.dart';

class UserRepository extends BaseRepository<UserData, Users, UsersCompanion> {
  UserRepository(super.database);
  
  @override
  Users get table => database.users;
  
  Future<UserData?> getByUsername(String username) {
    return (select(table)..where((tbl) => tbl.username.equals(username))).getSingleOrNull();
  }
  
  Future<UserData?> getByEmail(String email) {
    return (select(table)..where((tbl) => tbl.email.equals(email))).getSingleOrNull();
  }
  
  Future<UserData?> getByUuid(String uuid) {
    return (select(table)..where((tbl) => tbl.uuid.equals(uuid))).getSingleOrNull();
  }
  
  Future<List<UserData>> getByOrganization(String organizationId) {
    return (select(table)..where((tbl) => tbl.organizationId.equals(organizationId))).get();
  }
  
  Future<UserData> create(UserCreate create, String hashedPassword) async {
    final uuid = const Uuid().v4();
    final now = DateTime.now();
    final companion = UsersCompanion(
      uuid: Value(uuid),
      organizationId: Value(create.organizationId),
      username: Value(create.username),
      email: Value(create.email),
      fullName: Value(create.fullName),
      phone: Value(create.phone),
      hashedPassword: Value(hashedPassword),
      role: Value(create.role),
      isActive: const Value(true),
      isSuperuser: const Value(false),
      createdAt: Value(now),
      updatedAt: Value(now),
      isSynced: const Value(false),
    );
    await database.into(table).insert(companion);
    return getByUuid(uuid) as Future<UserData>;
  }
  
  Future<void> updateLastLogin(String uuid) async {
    await (database.update(table)..where((tbl) => tbl.uuid.equals(uuid))).write(UsersCompanion(
      lastLoginAt: Value(DateTime.now()),
      updatedAt: Value(DateTime.now()),
    ));
  }
  
  Future<void> markSynced(String uuid, {int? serverVersion}) async {
    await (database.update(table)..where((tbl) => tbl.uuid.equals(uuid))).write(UsersCompanion(
      isSynced: const Value(true),
      lastSyncedAt: Value(DateTime.now()),
      serverVersion: serverVersion != null ? Value(serverVersion) : const Value.absent(),
    ));
  }
}