import 'package:drift/drift.dart';
import 'package:superboard_mobile/data/database/app_database.dart';
import 'package:superboard_mobile/data/models/product.dart';
import 'package:superboard_mobile/data/repositories/base_repository.dart';

class ProductRepository extends BaseRepository<ProductData, Products, ProductsCompanion> {
  ProductRepository(super.database);
  
  @override
  Products get table => database.products;
  
  Future<ProductData?> getBySku(String sku) {
    return (select(table)..where((tbl) => tbl.sku.equals(sku))).getSingleOrNull();
  }
  
  Future<ProductData?> getByUuid(String uuid) {
    return (select(table)..where((tbl) => tbl.uuid.equals(uuid))).getSingleOrNull();
  }
  
  Future<List<ProductData>> getByOrganization(String organizationId) {
    return (select(table)
          ..where((tbl) => tbl.organizationId.equals(organizationId))
          ..orderBy([(tbl) => OrderingTerm.asc(tbl.name)]))
        .get();
  }
  
  Future<List<ProductData>> searchByName(String organizationId, String query) {
    return (select(table)
          ..where((tbl) => tbl.organizationId.equals(organizationId) & 
              (tbl.name.like('%$query%') | tbl.sku.like('%$query%') | tbl.description.like('%$query%')))
          ..orderBy([(tbl) => OrderingTerm.asc(tbl.name)]))
        .get();
  }
  
  Future<List<ProductData>> getLowStock(String organizationId) {
    return (select(table)
          ..where((tbl) => tbl.organizationId.equals(organizationId) & 
              tbl.quantityOnHand.isSmallerOrEqualValue(tbl.reorderLevel)))
        .get();
  }
  
  Future<ProductData> create(ProductCreate create) async {
    final uuid = const Uuid().v4();
    final now = DateTime.now();
    final companion = ProductsCompanion(
      uuid: Value(uuid),
      organizationId: Value(create.organizationId),
      sku: Value(create.sku),
      name: Value(create.name),
      description: Value(create.description),
      categoryId: Value(create.categoryId),
      uomId: Value(create.uomId),
      hsnCode: Value(create.hsnCode),
      gstRate: Value(create.gstRate),
      isManufactured: Value(create.isManufactured),
      isPurchased: Value(create.isPurchased),
      isSold: Value(create.isSold),
      trackBatch: Value(create.trackBatch),
      trackSerial: Value(create.trackSerial),
      standardCost: Value(create.standardCost),
      standardPrice: Value(create.standardPrice),
      minStockLevel: Value(create.minStockLevel),
      maxStockLevel: Value(create.maxStockLevel),
      reorderLevel: Value(create.reorderLevel),
      reorderQty: Value(create.reorderQty),
      isActive: const Value(true),
      createdAt: Value(now),
      updatedAt: Value(now),
      isSynced: const Value(false),
    );
    await database.into(table).insert(companion);
    return getByUuid(uuid) as Future<ProductData>;
  }
  
  Future<void> markSynced(String uuid, {int? serverVersion}) async {
    await (database.update(table)..where((tbl) => tbl.uuid.equals(uuid))).write(ProductsCompanion(
      isSynced: const Value(true),
      lastSyncedAt: Value(DateTime.now()),
      serverVersion: serverVersion != null ? Value(serverVersion) : const Value.absent(),
    ));
  }
}