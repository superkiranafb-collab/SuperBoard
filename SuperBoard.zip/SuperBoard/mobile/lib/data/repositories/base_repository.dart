import 'package:drift/drift.dart';
import 'package:superboard_mobile/data/database/app_database.dart';

abstract class BaseRepository<T, D extends Table, C extends Insertable<D>> {
  final AppDatabase database;
  
  BaseRepository(this.database);
  
  D get table;
  
  Future<List<T>> getAll({String? organizationId}) {
    var query = select(table);
    if (organizationId != null) {
      // Check if table has organizationId column
      try {
        query = query.where((tbl) => tbl.organizationId.equals(organizationId));
      } catch (e) {
        // Table doesn't have organizationId, skip filter
      }
    }
    return query.get();
  }
  
  Future<T?> getById(String uuid) {
    return (select(table)..where((tbl) => tbl.uuid.equals(uuid))).getSingleOrNull();
  }
  
  Future<int> insert(C companion) {
    return database.into(table).insert(companion);
  }
  
  Future<bool> update(C companion) {
    return database.update(table).replace(companion);
  }
  
  Future<int> delete(String uuid) {
    return (database.delete(table)..where((tbl) => tbl.uuid.equals(uuid))).go();
  }
  
  Future<void> markSynced(String uuid, {int? serverVersion}) {
    final now = DateTime.now();
    final updates = <String, Expression>{};
    updates['is_synced'] = const Constant(true);
    updates['last_synced_at'] = Variable(now);
    if (serverVersion != null) {
      updates['server_version'] = Variable(serverVersion);
    }
    // This needs to be implemented per table since column names vary
  }
  
  Future<List<T>> getUnsynced({String? organizationId}) {
    var query = (select(table)..where((tbl) => tbl.isSynced.equals(false)));
    if (organizationId != null) {
      try {
        query = query.where((tbl) => tbl.organizationId.equals(organizationId));
      } catch (e) {
        // Table doesn't have organizationId, skip filter
      }
    }
    return query.get();
  }
}