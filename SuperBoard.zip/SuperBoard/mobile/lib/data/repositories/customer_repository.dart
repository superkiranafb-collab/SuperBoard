import 'package:drift/drift.dart';
import 'package:superboard_mobile/data/database/app_database.dart';
import 'package:superboard_mobile/data/models/customer.dart';
import 'package:superboard_mobile/data/repositories/base_repository.dart';

class CustomerRepository extends BaseRepository<CustomerData, Customers, CustomersCompanion> {
  CustomerRepository(super.database);
  
  @override
  Customers get table => database.customers;
  
  Future<CustomerData?> getByCode(String code) {
    return (select(table)..where((tbl) => tbl.code.equals(code))).getSingleOrNull();
  }
  
  Future<CustomerData?> getByUuid(String uuid) {
    return (select(table)..where((tbl) => tbl.uuid.equals(uuid))).getSingleOrNull();
  }
  
  Future<List<CustomerData>> getByOrganization(String organizationId) {
    return (select(table)
          ..where((tbl) => tbl.organizationId.equals(organizationId))
          ..orderBy([(tbl) => OrderingTerm.asc(tbl.name)]))
        .get();
  }
  
  Future<List<CustomerData>> searchByName(String organizationId, String query) {
    return (select(table)
          ..where((tbl) => tbl.organizationId.equals(organizationId) & 
              (tbl.name.like('%$query%') | tbl.code.like('%$query%') | tbl.email.like('%$query%') | tbl.phone.like('%$query%')))
          ..orderBy([(tbl) => OrderingTerm.asc(tbl.name)]))
        .get();
  }
  
  Future<CustomerData> create(CustomerCreate create) async {
    final uuid = const Uuid().v4();
    final now = DateTime.now();
    final companion = CustomersCompanion(
      uuid: Value(uuid),
      organizationId: Value(create.organizationId),
      code: Value(create.code),
      name: Value(create.name),
      contactPerson: Value(create.contactPerson),
      email: Value(create.email),
      phone: Value(create.phone),
      gstin: Value(create.gstin),
      pan: Value(create.pan),
      billingAddressLine1: Value(create.billingAddressLine1),
      billingAddressLine2: Value(create.billingAddressLine2),
      billingCity: Value(create.billingCity),
      billingState: Value(create.billingState),
      billingPincode: Value(create.billingPincode),
      billingCountry: Value(create.billingCountry ?? 'India'),
      shippingAddressLine1: Value(create.shippingAddressLine1),
      shippingAddressLine2: Value(create.shippingAddressLine2),
      shippingCity: Value(create.shippingCity),
      shippingState: Value(create.shippingState),
      shippingPincode: Value(create.shippingPincode),
      shippingCountry: Value(create.shippingCountry ?? 'India'),
      paymentTermsId: Value(create.paymentTermsId),
      creditLimit: Value(create.creditLimit),
      isActive: const Value(true),
      createdAt: Value(now),
      updatedAt: Value(now),
      isSynced: const Value(false),
    );
    await database.into(table).insert(companion);
    return getByUuid(uuid) as Future<CustomerData>;
  }
  
  Future<void> updateOutstandingAmount(String uuid, double amount) async {
    await (database.update(table)..where((tbl) => tbl.uuid.equals(uuid))).write(CustomersCompanion(
      outstandingAmount: Value(amount),
      updatedAt: Value(DateTime.now()),
      isSynced: const Value(false),
    ));
  }
  
  Future<void> markSynced(String uuid, {int? serverVersion}) async {
    await (database.update(table)..where((tbl) => tbl.uuid.equals(uuid))).write(CustomersCompanion(
      isSynced: const Value(true),
      lastSyncedAt: Value(DateTime.now()),
      serverVersion: serverVersion != null ? Value(serverVersion) : const Value.absent(),
    ));
  }
}