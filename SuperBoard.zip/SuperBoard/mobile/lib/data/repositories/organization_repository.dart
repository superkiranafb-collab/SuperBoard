import 'package:drift/drift.dart';
import 'package:superboard_mobile/data/database/app_database.dart';
import 'package:superboard_mobile/data/models/organization.dart';
import 'package:superboard_mobile/data/repositories/base_repository.dart';

class OrganizationRepository extends BaseRepository<OrganizationData, Organizations, OrganizationsCompanion> {
  OrganizationRepository(super.database);
  
  @override
  Organizations get table => database.organizations;
  
  Future<OrganizationData?> getByUuid(String uuid) {
    return (select(table)..where((tbl) => tbl.uuid.equals(uuid))).getSingleOrNull();
  }
  
  Future<OrganizationData?> getDefault() {
    return (select(table)..where((tbl) => tbl.isActive.equals(true))).getSingleOrNull();
  }
  
  Future<OrganizationData> create(OrganizationCreate create) async {
    final uuid = const Uuid().v4();
    final now = DateTime.now();
    final companion = OrganizationsCompanion(
      uuid: Value(uuid),
      name: Value(create.name),
      legalName: Value(create.legalName),
      gstin: Value(create.gstin),
      pan: Value(create.pan),
      cin: Value(create.cin),
      addressLine1: Value(create.addressLine1),
      addressLine2: Value(create.addressLine2),
      city: Value(create.city),
      state: Value(create.state),
      pincode: Value(create.pincode),
      country: Value(create.country ?? 'India'),
      phone: Value(create.phone),
      email: Value(create.email),
      website: Value(create.website),
      isActive: const Value(true),
      createdAt: Value(now),
      updatedAt: Value(now),
      isSynced: const Value(false),
    );
    await database.into(table).insert(companion);
    return getByUuid(uuid) as Future<OrganizationData>;
  }
  
  Future<void> updateOrganization(String uuid, OrganizationCreate update) async {
    final now = DateTime.now();
    await (database.update(table)..where((tbl) => tbl.uuid.equals(uuid))).write(OrganizationsCompanion(
      name: Value(update.name),
      legalName: Value(update.legalName),
      gstin: Value(update.gstin),
      pan: Value(update.pan),
      cin: Value(update.cin),
      addressLine1: Value(update.addressLine1),
      addressLine2: Value(update.addressLine2),
      city: Value(update.city),
      state: Value(update.state),
      pincode: Value(update.pincode),
      country: Value(update.country ?? 'India'),
      phone: Value(update.phone),
      email: Value(update.email),
      website: Value(update.website),
      updatedAt: Value(now),
      isSynced: const Value(false),
    ));
  }
  
  Future<void> markSynced(String uuid, {int? serverVersion}) async {
    await (database.update(table)..where((tbl) => tbl.uuid.equals(uuid))).write(OrganizationsCompanion(
      isSynced: const Value(true),
      lastSyncedAt: Value(DateTime.now()),
      serverVersion: serverVersion != null ? Value(serverVersion) : const Value.absent(),
    ));
  }
}