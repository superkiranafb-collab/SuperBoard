import 'package:drift/drift.dart';
import 'package:superboard_mobile/data/database/app_database.dart';
import 'package:superboard_mobile/data/models/sales_order.dart';
import 'package:superboard_mobile/data/repositories/base_repository.dart';

class SalesOrderRepository extends BaseRepository<SalesOrderData, SalesOrders, SalesOrdersCompanion> {
  SalesOrderRepository(super.database);
  
  @override
  SalesOrders get table => database.salesOrders;
  
  Future<SalesOrderData?> getByOrderNumber(String orderNumber) {
    return (select(table)..where((tbl) => tbl.orderNumber.equals(orderNumber))).getSingleOrNull();
  }
  
  Future<SalesOrderData?> getByUuid(String uuid) {
    return (select(table)..where((tbl) => tbl.uuid.equals(uuid))).getSingleOrNull();
  }
  
  Future<List<SalesOrderData>> getByOrganization(String organizationId) {
    return (select(table)
          ..where((tbl) => tbl.organizationId.equals(organizationId))
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.orderDate)]))
        .get();
  }
  
  Future<List<SalesOrderData>> getByCustomer(String customerId) {
    return (select(table)
          ..where((tbl) => tbl.customerId.equals(customerId))
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.orderDate)]))
        .get();
  }
  
  Future<List<SalesOrderData>> getByStatus(String organizationId, String status) {
    return (select(table)
          ..where((tbl) => tbl.organizationId.equals(organizationId) & tbl.status.equals(status))
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.orderDate)]))
        .get();
  }
  
  Future<List<SalesOrderLineData>> getLines(String salesOrderId) {
    return (select(database.salesOrderLines)
          ..where((tbl) => tbl.salesOrderId.equals(salesOrderId))
          ..orderBy([(tbl) => OrderingTerm.asc(tbl.lineNumber)]))
        .get();
  }
  
  Future<SalesOrderData> create(SalesOrderCreate create) async {
    final uuid = const Uuid().v4();
    final now = DateTime.now();
    
    // Calculate totals
    double subtotal = 0;
    double taxAmount = 0;
    double discountAmount = 0;
    
    for (final line in create.lines) {
      final lineSubtotal = line.quantity * line.unitPrice;
      final lineDiscount = lineSubtotal * (line.discountPercent / 100);
      final lineTax = (lineSubtotal - lineDiscount) * (line.taxRate / 100);
      subtotal += lineSubtotal;
      discountAmount += lineDiscount;
      taxAmount += lineTax;
    }
    
    final totalAmount = subtotal + taxAmount - discountAmount;
    
    final orderCompanion = SalesOrdersCompanion(
      uuid: Value(uuid),
      organizationId: Value(create.organizationId),
      orderNumber: Value('SO-${DateTime.now().millisecondsSinceEpoch}'),
      customerId: Value(create.customerId),
      warehouseId: Value(create.warehouseId),
      orderDate: Value(create.orderDate),
      expectedDate: Value(create.expectedDate),
      status: const Value('draft'),
      subtotal: Value(subtotal),
      taxAmount: Value(taxAmount),
      discountAmount: Value(discountAmount),
      totalAmount: Value(totalAmount),
      notes: Value(create.notes),
      createdAt: Value(now),
      updatedAt: Value(now),
      isSynced: const Value(false),
    );
    
    await database.into(table).insert(orderCompanion);
    
    // Insert lines
    for (int i = 0; i < create.lines.length; i++) {
      final line = create.lines[i];
      final lineSubtotal = line.quantity * line.unitPrice;
      final lineDiscount = lineSubtotal * (line.discountPercent / 100);
      final lineTax = (lineSubtotal - lineDiscount) * (line.taxRate / 100);
      final lineTotal = lineSubtotal + lineTax - lineDiscount;
      
      final lineCompanion = SalesOrderLinesCompanion(
        uuid: Value(const Uuid().v4()),
        organizationId: Value(create.organizationId),
        salesOrderId: Value(uuid),
        productId: Value(line.productId),
        quantity: Value(line.quantity),
        unitPrice: Value(line.unitPrice),
        discountPercent: Value(line.discountPercent),
        discountAmount: Value(lineDiscount),
        taxRate: Value(line.taxRate),
        taxAmount: Value(lineTax),
        lineTotal: Value(lineTotal),
        lineNumber: Value(i + 1),
        createdAt: Value(now),
        updatedAt: Value(now),
        isSynced: const Value(false),
      );
      
      await database.into(database.salesOrderLines).insert(lineCompanion);
    }
    
    return getByUuid(uuid) as Future<SalesOrderData>;
  }
  
  Future<void> updateStatus(String uuid, String status) async {
    await (database.update(table)..where((tbl) => tbl.uuid.equals(uuid))).write(SalesOrdersCompanion(
      status: Value(status),
      updatedAt: Value(DateTime.now()),
      isSynced: const Value(false),
    ));
  }
  
  Future<void> markSynced(String uuid, {int? serverVersion}) async {
    await (database.update(table)..where((tbl) => tbl.uuid.equals(uuid))).write(SalesOrdersCompanion(
      isSynced: const Value(true),
      lastSyncedAt: Value(DateTime.now()),
      serverVersion: serverVersion != null ? Value(serverVersion) : const Value.absent(),
    ));
  }
}