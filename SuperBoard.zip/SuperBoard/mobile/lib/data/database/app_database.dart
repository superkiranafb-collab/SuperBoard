import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:sqlite3/sqlite3.dart';
import 'package:sqlite3_flutter_libs/sqlite3_flutter_libs.dart';

part 'app_database.g.dart';

class Organizations extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get name => text()();
  TextColumn get legalName => text().nullable()();
  TextColumn get gstin => text().nullable()();
  TextColumn get pan => text().nullable()();
  TextColumn get cin => text().nullable()();
  TextColumn get addressLine1 => text().nullable()();
  TextColumn get addressLine2 => text().nullable()();
  TextColumn get city => text().nullable()();
  TextColumn get state => text().nullable()();
  TextColumn get pincode => text().nullable()();
  TextColumn get country => text().withDefault(const Constant('India'))();
  TextColumn get phone => text().nullable()();
  TextColumn get email => text().nullable()();
  TextColumn get website => text().nullable()();
  TextColumn get logoUrl => text().nullable()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class Users extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get username => text()();
  TextColumn get email => text()();
  TextColumn get fullName => text().nullable()();
  TextColumn get phone => text().nullable()();
  TextColumn get hashedPassword => text().nullable()();
  TextColumn get avatarUrl => text().nullable()();
  TextColumn get role => text().withDefault(const Constant('employee'))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  BoolColumn get isSuperuser => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastLoginAt => dateTime().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class Warehouses extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get code => text()();
  TextColumn get name => text()();
  TextColumn get addressLine1 => text().nullable()();
  TextColumn get addressLine2 => text().nullable()();
  TextColumn get city => text().nullable()();
  TextColumn get state => text().nullable()();
  TextColumn get pincode => text().nullable()();
  TextColumn get country => text().withDefault(const Constant('India'))();
  TextColumn get contactPerson => text().nullable()();
  TextColumn get contactPhone => text().nullable()();
  TextColumn get contactEmail => text().nullable()();
  BoolColumn get isDefault => boolean().withDefault(const Constant(false))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class Products extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get sku => text()();
  TextColumn get name => text()();
  TextColumn get description => text().nullable()();
  TextColumn get categoryId => text().nullable()();
  TextColumn get uomId => text()();
  TextColumn get hsnCode => text().nullable()();
  RealColumn get gstRate => real().withDefault(const Constant(0.0))();
  BoolColumn get isManufactured => boolean().withDefault(const Constant(false))();
  BoolColumn get isPurchased => boolean().withDefault(const Constant(true))();
  BoolColumn get isSold => boolean().withDefault(const Constant(true))();
  BoolColumn get trackBatch => boolean().withDefault(const Constant(false))();
  BoolColumn get trackSerial => boolean().withDefault(const Constant(false))();
  RealColumn get standardCost => real().withDefault(const Constant(0.0))();
  RealColumn get standardPrice => real().withDefault(const Constant(0.0))();
  RealColumn get minStockLevel => real().withDefault(const Constant(0.0))();
  RealColumn get maxStockLevel => real().withDefault(const Constant(0.0))();
  RealColumn get reorderLevel => real().withDefault(const Constant(0.0))();
  RealColumn get reorderQty => real().withDefault(const Constant(0.0))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class Customers extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get code => text()();
  TextColumn get name => text()();
  TextColumn get contactPerson => text().nullable()();
  TextColumn get email => text().nullable()();
  TextColumn get phone => text().nullable()();
  TextColumn get gstin => text().nullable()();
  TextColumn get pan => text().nullable()();
  TextColumn get billingAddressLine1 => text().nullable()();
  TextColumn get billingAddressLine2 => text().nullable()();
  TextColumn get billingCity => text().nullable()();
  TextColumn get billingState => text().nullable()();
  TextColumn get billingPincode => text().nullable()();
  TextColumn get billingCountry => text().withDefault(const Constant('India'))();
  TextColumn get shippingAddressLine1 => text().nullable()();
  TextColumn get shippingAddressLine2 => text().nullable()();
  TextColumn get shippingCity => text().nullable()();
  TextColumn get shippingState => text().nullable()();
  TextColumn get shippingPincode => text().nullable()();
  TextColumn get shippingCountry => text().withDefault(const Constant('India'))();
  TextColumn get paymentTermsId => text().nullable()();
  RealColumn get creditLimit => real().withDefault(const Constant(0.0))();
  RealColumn get outstandingAmount => real().withDefault(const Constant(0.0))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class Suppliers extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get code => text()();
  TextColumn get name => text()();
  TextColumn get contactPerson => text().nullable()();
  TextColumn get email => text().nullable()();
  TextColumn get phone => text().nullable()();
  TextColumn get gstin => text().nullable()();
  TextColumn get pan => text().nullable()();
  TextColumn get addressLine1 => text().nullable()();
  TextColumn get addressLine2 => text().nullable()();
  TextColumn get city => text().nullable()();
  TextColumn get state => text().nullable()();
  TextColumn get pincode => text().nullable()();
  TextColumn get country => text().withDefault(const Constant('India'))();
  TextColumn get paymentTermsId => text().nullable()();
  RealColumn get creditLimit => real().withDefault(const Constant(0.0))();
  RealColumn get outstandingAmount => real().withDefault(const Constant(0.0))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class InventoryItems extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get productId => text()();
  TextColumn get warehouseId => text()();
  TextColumn get batchId => text().nullable()();
  TextColumn get serialNumber => text().nullable()();
  RealColumn get quantityOnHand => real().withDefault(const Constant(0.0))();
  RealColumn get quantityReserved => real().withDefault(const Constant(0.0))();
  RealColumn get quantityAvailable => real().withDefault(const Constant(0.0))();
  RealColumn get quantityOnOrder => real().withDefault(const Constant(0.0))();
  RealColumn get averageCost => real().withDefault(const Constant(0.0))();
  RealColumn get lastCost => real().withDefault(const Constant(0.0))();
  DateTimeColumn get lastMovementDate => dateTime().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class InventoryBatches extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get productId => text()();
  TextColumn get batchNumber => text()();
  TextColumn get warehouseId => text()();
  RealColumn get quantity => real().withDefault(const Constant(0.0))();
  RealColumn get quantityReserved => real().withDefault(const Constant(0.0))();
  RealColumn get quantityAvailable => real().withDefault(const Constant(0.0))();
  DateTimeColumn get manufacturingDate => dateTime().nullable()();
  DateTimeColumn get expiryDate => dateTime().nullable()();
  RealColumn get cost => real().withDefault(const Constant(0.0))();
  TextColumn get status => text().withDefault(const Constant('active'))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class InventoryMovements extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get productId => text()();
  TextColumn get warehouseId => text()();
  TextColumn get batchId => text().nullable()();
  TextColumn get movementType => text()();
  TextColumn get referenceType => text().nullable()();
  TextColumn get referenceId => text().nullable()();
  RealColumn get quantity => real()();
  RealColumn get unitCost => real().withDefault(const Constant(0.0))();
  RealColumn get totalCost => real().withDefault(const Constant(0.0))();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get movementDate => dateTime().withDefault(currentDateAndTime)();
  TextColumn get createdBy => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class SalesOrders extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get orderNumber => text()();
  TextColumn get customerId => text()();
  TextColumn get warehouseId => text().nullable()();
  DateTimeColumn get orderDate => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get expectedDate => dateTime().nullable()();
  TextColumn get status => text().withDefault(const Constant('draft'))();
  RealColumn get subtotal => real().withDefault(const Constant(0.0))();
  RealColumn get taxAmount => real().withDefault(const Constant(0.0))();
  RealColumn get discountAmount => real().withDefault(const Constant(0.0))();
  RealColumn get totalAmount => real().withDefault(const Constant(0.0))();
  TextColumn get notes => text().nullable()();
  TextColumn get createdBy => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class SalesOrderLines extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get salesOrderId => text()();
  TextColumn get productId => text()();
  RealColumn get quantity => real()();
  RealColumn get unitPrice => real()();
  RealColumn get discountPercent => real().withDefault(const Constant(0.0))();
  RealColumn get discountAmount => real().withDefault(const Constant(0.0))();
  RealColumn get taxRate => real().withDefault(const Constant(0.0))();
  RealColumn get taxAmount => real().withDefault(const Constant(0.0))();
  RealColumn get lineTotal => real()();
  IntColumn get lineNumber => integer()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class PurchaseOrders extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get orderNumber => text()();
  TextColumn get supplierId => text()();
  TextColumn get warehouseId => text().nullable()();
  DateTimeColumn get orderDate => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get expectedDate => dateTime().nullable()();
  TextColumn get status => text().withDefault(const Constant('draft'))();
  RealColumn get subtotal => real().withDefault(const Constant(0.0))();
  RealColumn get taxAmount => real().withDefault(const Constant(0.0))();
  RealColumn get discountAmount => real().withDefault(const Constant(0.0))();
  RealColumn get totalAmount => real().withDefault(const Constant(0.0))();
  TextColumn get notes => text().nullable()();
  TextColumn get createdBy => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class PurchaseOrderLines extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get purchaseOrderId => text()();
  TextColumn get productId => text()();
  RealColumn get quantity => real()();
  RealColumn get unitPrice => real()();
  RealColumn get discountPercent => real().withDefault(const Constant(0.0))();
  RealColumn get discountAmount => real().withDefault(const Constant(0.0))();
  RealColumn get taxRate => real().withDefault(const Constant(0.0))();
  RealColumn get taxAmount => real().withDefault(const Constant(0.0))();
  RealColumn get lineTotal => real()();
  IntColumn get lineNumber => integer()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class BillOfMaterials extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get productId => text()();
  TextColumn get version => text().withDefault(const Constant('1.0'))();
  TextColumn get status => text().withDefault(const Constant('draft'))();
  RealColumn get yieldQuantity => real().withDefault(const Constant(1.0))();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get effectiveFrom => dateTime().nullable()();
  DateTimeColumn get effectiveTo => dateTime().nullable()();
  TextColumn get approvedBy => text().nullable()();
  DateTimeColumn get approvedAt => dateTime().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class BomLines extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get bomId => text()();
  TextColumn get productId => text()();
  RealColumn get quantity => real()();
  RealColumn get scrapPercent => real().withDefault(const Constant(0.0))();
  TextColumn get notes => text().nullable()();
  IntColumn get lineNumber => integer()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class WorkCenters extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get code => text()();
  TextColumn get name => text()();
  TextColumn get description => text().nullable()();
  TextColumn get workCenterType => text().withDefault(const Constant('production'))();
  RealColumn get capacityPerHour => real().withDefault(const Constant(0.0))();
  RealColumn get efficiencyPercent => real().withDefault(const Constant(100.0))();
  RealColumn get costPerHour => real().withDefault(const Constant(0.0))();
  TextColumn get supervisorId => text().nullable()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class WorkOrders extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get workOrderNumber => text()();
  TextColumn get bomId => text()();
  TextColumn get productId => text()();
  TextColumn get workCenterId => text().nullable()();
  RealColumn get plannedQuantity => real()();
  RealColumn get producedQuantity => real().withDefault(const Constant(0.0))();
  RealColumn get rejectedQuantity => real().withDefault(const Constant(0.0))();
  TextColumn get status => text().withDefault(const Constant('planned'))();
  TextColumn get priority => text().withDefault(const Constant('normal'))();
  DateTimeColumn get plannedStartDate => dateTime().nullable()();
  DateTimeColumn get plannedEndDate => dateTime().nullable()();
  DateTimeColumn get actualStartDate => dateTime().nullable()();
  DateTimeColumn get actualEndDate => dateTime().nullable()();
  TextColumn get notes => text().nullable()();
  TextColumn get createdBy => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class MaterialIssues extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get workOrderId => text()();
  TextColumn get issueNumber => text()();
  TextColumn get status => text().withDefault(const Constant('pending'))();
  DateTimeColumn get issueDate => dateTime().withDefault(currentDateAndTime)();
  TextColumn get issuedBy => text().nullable()();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class MaterialIssueLines extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get materialIssueId => text()();
  TextColumn get productId => text()();
  TextColumn get batchId => text().nullable()();
  RealColumn get quantityRequired => real()();
  RealColumn get quantityIssued => real().withDefault(const Constant(0.0))();
  RealColumn get unitCost => real().withDefault(const Constant(0.0))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class ProductionEntries extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get workOrderId => text()();
  TextColumn get entryNumber => text()();
  RealColumn get quantityProduced => real()();
  RealColumn get quantityRejected => real().withDefault(const Constant(0.0))();
  TextColumn get rejectionReason => text().nullable()();
  DateTimeColumn get productionDate => dateTime().withDefault(currentDateAndTime)();
  TextColumn get recordedBy => text().nullable()();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class QualityChecks extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get workOrderId => text().nullable()();
  TextColumn get productionEntryId => text().nullable()();
  TextColumn get checkType => text()();
  TextColumn get status => text().withDefault(const Constant('pending'))();
  RealColumn get sampleSize => real().withDefault(const Constant(0.0))();
  RealColumn get passedQuantity => real().withDefault(const Constant(0.0))();
  RealColumn get failedQuantity => real().withDefault(const Constant(0.0))();
  TextColumn get checkedBy => text().nullable()();
  DateTimeColumn get checkedAt => dateTime().nullable()();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class QualityCheckParameters extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get qualityCheckId => text()();
  TextColumn get parameterName => text()();
  TextColumn get expectedValue => text().nullable()();
  TextColumn get actualValue => text().nullable()();
  TextColumn get unit => text().nullable()();
  TextColumn get result => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class BatchReleases extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get productionEntryId => text()();
  TextColumn get batchNumber => text()();
  TextColumn get status => text().withDefault(const Constant('pending'))();
  DateTimeColumn get releaseDate => dateTime().nullable()();
  TextColumn get releasedBy => text().nullable()();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class ChartOfAccounts extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get code => text()();
  TextColumn get name => text()();
  TextColumn get accountType => text()();
  TextColumn get parentId => text().nullable()();
  TextColumn get description => text().nullable()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  BoolColumn get isControlAccount => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class JournalEntries extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get entryNumber => text()();
  DateTimeColumn get entryDate => dateTime().withDefault(currentDateAndTime)();
  TextColumn get referenceType => text().nullable()();
  TextColumn get referenceId => text().nullable()();
  TextColumn get narration => text().nullable()();
  TextColumn get status => text().withDefault(const Constant('draft'))();
  RealColumn get totalDebit => real().withDefault(const Constant(0.0))();
  RealColumn get totalCredit => real().withDefault(const Constant(0.0))();
  TextColumn get createdBy => text().nullable()();
  TextColumn get postedBy => text().nullable()();
  DateTimeColumn get postedAt => dateTime().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class JournalEntryLines extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get journalEntryId => text()();
  TextColumn get accountId => text()();
  RealColumn get debitAmount => real().withDefault(const Constant(0.0))();
  RealColumn get creditAmount => real().withDefault(const Constant(0.0))();
  TextColumn get narration => text().nullable()();
  IntColumn get lineNumber => integer()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class ExpenseClaims extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get claimNumber => text()();
  TextColumn get employeeId => text()();
  DateTimeColumn get claimDate => dateTime().withDefault(currentDateAndTime)();
  RealColumn get totalAmount => real().withDefault(const Constant(0.0))();
  TextColumn get status => text().withDefault(const Constant('draft'))();
  TextColumn get approvedBy => text().nullable()();
  DateTimeColumn get approvedAt => dateTime().nullable()();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class ExpenseClaimLines extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get expenseClaimId => text()();
  TextColumn get expenseCategoryId => text()();
  DateTimeColumn get expenseDate => dateTime().withDefault(currentDateAndTime)();
  RealColumn get amount => real()();
  TextColumn get description => text().nullable()();
  TextColumn get receiptUrl => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class GstReturns extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get returnType => text()();
  TextColumn get period => text()();
  DateTimeColumn get filingDate => dateTime().nullable()();
  TextColumn get status => text().withDefault(const Constant('draft'))();
  RealColumn get totalTaxableValue => real().withDefault(const Constant(0.0))();
  RealColumn get totalIgst => real().withDefault(const Constant(0.0))();
  RealColumn get totalCgst => real().withDefault(const Constant(0.0))();
  RealColumn get totalSgst => real().withDefault(const Constant(0.0))();
  RealColumn get totalCess => real().withDefault(const Constant(0.0))();
  TextColumn get gstPortalRef => text().nullable()();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class Attendance extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get employeeId => text()();
  DateTimeColumn get attendanceDate => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get checkInTime => dateTime().nullable()();
  DateTimeColumn get checkOutTime => dateTime().nullable()();
  RealColumn get workHours => real().withDefault(const Constant(0.0))();
  RealColumn get overtimeHours => real().withDefault(const Constant(0.0))();
  TextColumn get status => text().withDefault(const Constant('present'))();
  TextColumn get checkInLocation => text().nullable()();
  TextColumn get checkOutLocation => text().nullable()();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class Shifts extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get code => text()();
  TextColumn get name => text()();
  TextColumn get startTime => text()();
  TextColumn get endTime => text()();
  RealColumn get durationHours => real()();
  TextColumn get daysOfWeek => text().withDefault(const Constant('1,2,3,4,5'))();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class LeaveApplications extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get employeeId => text()();
  TextColumn get leaveTypeId => text()();
  DateTimeColumn get startDate => dateTime()();
  DateTimeColumn get endDate => dateTime()();
  RealColumn get totalDays => real()();
  TextColumn get status => text().withDefault(const Constant('pending'))();
  TextColumn get reason => text().nullable()();
  TextColumn get approvedBy => text().nullable()();
  DateTimeColumn get approvedAt => dateTime().nullable()();
  TextColumn get rejectionReason => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class Vehicles extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get registrationNumber => text()();
  TextColumn get vehicleType => text()();
  TextColumn get model => text().nullable()();
  TextColumn get capacity => text().nullable()();
  RealColumn get maxWeightKg => real().nullable()();
  RealColumn get maxVolumeM3 => real().nullable()();
  TextColumn get driverId => text().nullable()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  BoolColumn get gpsEnabled => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastGpsUpdate => dateTime().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class Drivers extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get employeeId => text().nullable()();
  TextColumn get licenseNumber => text()();
  DateTimeColumn get licenseExpiry => dateTime().nullable()();
  TextColumn get phone => text().nullable()();
  TextColumn get emergencyContact => text().nullable()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class DeliveryTrips extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get tripNumber => text()();
  TextColumn get vehicleId => text()();
  TextColumn get driverId => text()();
  TextColumn get status => text().withDefault(const Constant('planned'))();
  DateTimeColumn get plannedStartTime => dateTime().nullable()();
  DateTimeColumn get actualStartTime => dateTime().nullable()();
  DateTimeColumn get plannedEndTime => dateTime().nullable()();
  DateTimeColumn get actualEndTime => dateTime().nullable()();
  RealColumn get totalDistanceKm => real().withDefault(const Constant(0.0))();
  RealColumn get fuelCost => real().withDefault(const Constant(0.0))();
  RealColumn get tollCost => real().withDefault(const Constant(0.0))();
  RealColumn get otherExpenses => real().withDefault(const Constant(0.0))();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class TripStops extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get tripId => text()();
  TextColumn get stopType => text()();
  TextColumn get referenceType => text().nullable()();
  TextColumn get referenceId => text().nullable()();
  TextColumn get address => text().nullable()();
  RealColumn get latitude => real().nullable()();
  RealColumn get longitude => real().nullable()();
  IntColumn get sequence => integer()();
  DateTimeColumn get plannedArrival => dateTime().nullable()();
  DateTimeColumn get actualArrival => dateTime().nullable()();
  DateTimeColumn get actualDeparture => dateTime().nullable()();
  TextColumn get status => text().withDefault(const Constant('pending'))();
  TextColumn get notes => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class Routes extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get code => text()();
  TextColumn get name => text()();
  TextColumn get description => text().nullable()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class RouteStops extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get organizationId => text()();
  TextColumn get routeId => text()();
  TextColumn get stopType => text()();
  TextColumn get referenceType => text().nullable()();
  TextColumn get referenceId => text().nullable()();
  TextColumn get address => text().nullable()();
  RealColumn get latitude => real().nullable()();
  RealColumn get longitude => real().nullable()();
  IntColumn get sequence => integer()();
  IntColumn get estimatedDurationMinutes => integer().withDefault(const Constant(0))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  IntColumn get serverVersion => integer().withDefault(const Constant(0))();
  BoolColumn get isSynced => boolean().withDefault(const Constant(false))();
  DateTimeColumn get lastSyncedAt => dateTime().nullable()();
}

class SyncQueue extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get uuid => text().unique()();
  TextColumn get tableName => text()();
  TextColumn get recordUuid => text()();
  TextColumn get operation => text()();
  TextColumn get payload => text()();
  IntColumn get retryCount => integer().withDefault(const Constant(0))();
  TextColumn get status => text().withDefault(const Constant('pending'))();
  TextColumn get errorMessage => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
  DateTimeColumn get lastAttemptAt => dateTime().nullable()();
  DateTimeColumn get nextRetryAt => dateTime().nullable()();
}

@DriftDatabase(tables: [
  Organizations,
  Users,
  Warehouses,
  Products,
  Customers,
  Suppliers,
  InventoryItems,
  InventoryBatches,
  InventoryMovements,
  SalesOrders,
  SalesOrderLines,
  PurchaseOrders,
  PurchaseOrderLines,
  BillOfMaterials,
  BomLines,
  WorkCenters,
  WorkOrders,
  MaterialIssues,
  MaterialIssueLines,
  ProductionEntries,
  QualityChecks,
  QualityCheckParameters,
  BatchReleases,
  ChartOfAccounts,
  JournalEntries,
  JournalEntryLines,
  ExpenseClaims,
  ExpenseClaimLines,
  GstReturns,
  Attendance,
  Shifts,
  LeaveApplications,
  Vehicles,
  Drivers,
  DeliveryTrips,
  TripStops,
  Routes,
  RouteStops,
  SyncQueue,
])
class AppDatabase extends _$AppDatabase {
  AppDatabase(super.executor);
  
  @override
  int get schemaVersion => 1;
  
  @override
  MigrationStrategy get migration {
    return MigrationStrategy(
      onCreate: (Migrator m) async {
        await m.createAll();
        // Create indexes for better query performance
        await customStatement('CREATE INDEX IF NOT EXISTS idx_organizations_uuid ON organizations(uuid)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_users_org ON users(organization_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_warehouses_org ON warehouses(organization_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_products_org ON products(organization_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_products_sku ON products(sku)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_customers_org ON customers(organization_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_suppliers_org ON suppliers(organization_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_inventory_items_product ON inventory_items(product_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_inventory_items_warehouse ON inventory_items(warehouse_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_inventory_batches_product ON inventory_batches(product_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_inventory_movements_product ON inventory_movements(product_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_sales_orders_customer ON sales_orders(customer_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_sales_orders_date ON sales_orders(order_date)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_purchase_orders_supplier ON purchase_orders(supplier_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_work_orders_bom ON work_orders(bom_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_work_orders_status ON work_orders(status)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_attendance_employee ON attendance(employee_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(attendance_date)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_delivery_trips_vehicle ON delivery_trips(vehicle_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_delivery_trips_driver ON delivery_trips(driver_id)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_sync_queue_status ON sync_queue(status)');
        await customStatement('CREATE INDEX IF NOT EXISTS idx_sync_queue_table ON sync_queue(table_name)');
      },
      onUpgrade: (Migrator m, int from, int to) async {
        // Handle future migrations
      },
    );
  }
  
  // Sync status helpers
  Future<List<SyncQueueData>> getPendingSyncItems() {
    return (select(syncQueue)
          ..where((tbl) => tbl.status.equals('pending'))
          ..orderBy([(tbl) => OrderingTerm.asc(tbl.createdAt)]))
        .get();
  }
  
  Future<void> markSyncCompleted(String uuid) async {
    await (update(syncQueue)..where((tbl) => tbl.uuid.equals(uuid)))
      .write(SyncQueueCompanion(
        status: const Value('completed'),
        lastAttemptAt: Value(DateTime.now()),
      ));
  }
  
  Future<void> markSyncFailed(String uuid, String error) async {
    await (update(syncQueue)..where((tbl) => tbl.uuid.equals(uuid)))
      .write(SyncQueueCompanion(
        status: const Value('failed'),
        errorMessage: Value(error),
        lastAttemptAt: Value(DateTime.now()),
        retryCount: syncQueue.retryCount + 1,
      ));
  }
  
  Future<void> addToSyncQueue({
    required String tableName,
    required String recordUuid,
    required String operation,
    required String payload,
  }) async {
    await into(syncQueue).insert(SyncQueueCompanion(
      uuid: Value(const Uuid().v4()),
      tableName: Value(tableName),
      recordUuid: Value(recordUuid),
      operation: Value(operation),
      payload: Value(payload),
      status: const Value('pending'),
      createdAt: Value(DateTime.now()),
    ));
  }
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dbFolder = await getApplicationDocumentsDirectory();
    final file = File(p.join(dbFolder.path, 'superboard.db'));
    
    if (sqlite3.runtimeType.toString().contains('Sqlite3Factory')) {
      sqlite3.open.overrideFor(file.path, () => sqlite3.openV2(
        file.path,
        SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX,
      ));
    }
    
    return NativeDatabase.createInBackground(file);
  });
}