import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:superboard_mobile/core/config/app_config.dart';
import 'package:superboard_mobile/data/database/app_database.dart';
import 'package:superboard_mobile/data/repositories/organization_repository.dart';
import 'package:superboard_mobile/data/repositories/user_repository.dart';
import 'package:superboard_mobile/data/repositories/product_repository.dart';
import 'package:superboard_mobile/data/repositories/customer_repository.dart';
import 'package:superboard_mobile/data/repositories/sales_order_repository.dart';

class SyncService extends ChangeNotifier {
  final AppDatabase _database;
  final OrganizationRepository _organizationRepository;
  final UserRepository _userRepository;
  final ProductRepository _productRepository;
  final CustomerRepository _customerRepository;
  final SalesOrderRepository _salesOrderRepository;
  
  final Connectivity _connectivity = Connectivity();
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;
  
  bool _isSyncing = false;
  bool _isOnline = false;
  String? _lastError;
  DateTime? _lastSyncTime;
  int _pendingCount = 0;
  
  bool get isSyncing => _isSyncing;
  bool get isOnline => _isOnline;
  String? get lastError => _lastError;
  DateTime? get lastSyncTime => _lastSyncTime;
  int get pendingCount => _pendingCount;
  
  SyncService({
    required AppDatabase database,
    required OrganizationRepository organizationRepository,
    required UserRepository userRepository,
    required ProductRepository productRepository,
    required CustomerRepository customerRepository,
    required SalesOrderRepository salesOrderRepository,
  }) : _database = database,
       _organizationRepository = organizationRepository,
       _userRepository = userRepository,
       _productRepository = productRepository,
       _customerRepository = customerRepository,
       _salesOrderRepository = salesOrderRepository {
    _initConnectivity();
    _loadPendingCount();
  }
  
  void _initConnectivity() {
    _connectivitySubscription = _connectivity.onConnectivityChanged.listen((results) {
      final wasOnline = _isOnline;
      _isOnline = results.any((r) => r != ConnectivityResult.none);
      
      if (!wasOnline && _isOnline) {
        // Came online, trigger sync
        syncAll();
      }
      
      notifyListeners();
    });
    
    // Check initial connectivity
    _connectivity.checkConnectivity().then((results) {
      _isOnline = results.any((r) => r != ConnectivityResult.none);
      notifyListeners();
    });
  }
  
  Future<void> _loadPendingCount() async {
    final pending = await _database.getPendingSyncItems();
    _pendingCount = pending.length;
    notifyListeners();
  }
  
  Future<void> syncAll() async {
    if (_isSyncing || !_isOnline) return;
    
    _isSyncing = true;
    _lastError = null;
    notifyListeners();
    
    try {
      await _syncPendingChanges();
      await _pullServerChanges();
      _lastSyncTime = DateTime.now();
      await _loadPendingCount();
    } catch (e) {
      _lastError = e.toString();
    } finally {
      _isSyncing = false;
      notifyListeners();
    }
  }
  
  Future<void> _syncPendingChanges() async {
    final pendingItems = await _database.getPendingSyncItems();
    
    for (final item in pendingItems) {
      try {
        await _processSyncItem(item);
        await _database.markSyncCompleted(item.uuid);
      } catch (e) {
        await _database.markSyncFailed(item.uuid, e.toString());
        // Continue with other items
      }
    }
  }
  
  Future<void> _processSyncItem(SyncQueueData item) async {
    final dio = AppConfig.dio;
    final endpoint = _getEndpointForTable(item.tableName);
    final method = _getMethodForOperation(item.operation);
    
    final response = await dio.request(
      endpoint,
      data: item.payload,
      options: Options(method: method),
    );
    
    if (response.statusCode! >= 400) {
      throw Exception('Server error: ${response.statusCode}');
    }
    
    // Update local record with server version if returned
    if (response.data != null && response.data['version'] != null) {
      await _updateLocalVersion(item.tableName, item.recordUuid, response.data['version']);
    }
  }
  
  String _getEndpointForTable(String tableName) {
    switch (tableName) {
      case 'organizations':
        return '/organizations';
      case 'users':
        return '/users';
      case 'products':
        return '/products';
      case 'customers':
        return '/customers';
      case 'sales_orders':
        return '/sales/orders';
      case 'purchase_orders':
        return '/purchase/orders';
      case 'work_orders':
        return '/manufacturing/work-orders';
      case 'attendance':
        return '/hr/attendance';
      case 'delivery_trips':
        return '/logistics/trips';
      default:
        return '/$tableName';
    }
  }
  
  String _getMethodForOperation(String operation) {
    switch (operation) {
      case 'create':
        return 'POST';
      case 'update':
        return 'PUT';
      case 'delete':
        return 'DELETE';
      default:
        return 'POST';
    }
  }
  
  Future<void> _updateLocalVersion(String tableName, String recordUuid, int version) async {
    // This would update the server_version column for the specific table
    // Implementation depends on the table structure
  }
  
  Future<void> _pullServerChanges() async {
    // Pull changes from server since last sync
    // This would typically use a /sync endpoint that returns changes since a timestamp
    final dio = AppConfig.dio;
    final since = _lastSyncTime?.toIso8601String() ?? '';
    
    try {
      final response = await dio.get('/sync/changes', queryParameters: {'since': since});
      
      if (response.statusCode == 200 && response.data != null) {
        await _applyServerChanges(response.data);
      }
    } catch (e) {
      // Log error but don't fail the whole sync
      debugPrint('Failed to pull server changes: $e');
    }
  }
  
  Future<void> _applyServerChanges(Map<String, dynamic> changes) async {
    // Apply server changes to local database
    // This would involve upserting records for each table
  }
  
  Future<void> queueForSync({
    required String tableName,
    required String recordUuid,
    required String operation,
    required Map<String, dynamic> payload,
  }) async {
    await _database.addToSyncQueue(
      tableName: tableName,
      recordUuid: recordUuid,
      operation: operation,
      payload: payload.toString(),
    );
    await _loadPendingCount();
  }
  
  Future<void> forceSync() async {
    await syncAll();
  }
  
  @override
  void dispose() {
    _connectivitySubscription?.cancel();
    super.dispose();
  }
}