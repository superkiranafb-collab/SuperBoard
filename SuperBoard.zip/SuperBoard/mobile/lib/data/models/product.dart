import 'package:freezed_annotation/freezed_annotation.dart';

part 'product.freezed.dart';
part 'product.g.dart';

@freezed
class Product with _$Product {
  const factory Product({
    required String uuid,
    required String organizationId,
    required String sku,
    required String name,
    String? description,
    String? categoryId,
    required String uomId,
    String? hsnCode,
    @Default(0.0) double gstRate,
    @Default(false) bool isManufactured,
    @Default(true) bool isPurchased,
    @Default(true) bool isSold,
    @Default(false) bool trackBatch,
    @Default(false) bool trackSerial,
    @Default(0.0) double standardCost,
    @Default(0.0) double standardPrice,
    @Default(0.0) double minStockLevel,
    @Default(0.0) double maxStockLevel,
    @Default(0.0) double reorderLevel,
    @Default(0.0) double reorderQty,
    @Default(true) bool isActive,
    required DateTime createdAt,
    required DateTime updatedAt,
  }) = _Product;

  factory Product.fromJson(Map<String, dynamic> json) => _$ProductFromJson(json);
}

@freezed
class ProductCreate with _$ProductCreate {
  const factory ProductCreate({
    required String organizationId,
    required String sku,
    required String name,
    String? description,
    String? categoryId,
    required String uomId,
    String? hsnCode,
    @Default(0.0) double gstRate,
    @Default(false) bool isManufactured,
    @Default(true) bool isPurchased,
    @Default(true) bool isSold,
    @Default(false) bool trackBatch,
    @Default(false) bool trackSerial,
    @Default(0.0) double standardCost,
    @Default(0.0) double standardPrice,
    @Default(0.0) double minStockLevel,
    @Default(0.0) double maxStockLevel,
    @Default(0.0) double reorderLevel,
    @Default(0.0) double reorderQty,
  }) = _ProductCreate;

  factory ProductCreate.fromJson(Map<String, dynamic> json) => _$ProductCreateFromJson(json);
}