import 'package:freezed_annotation/freezed_annotation.dart';

part 'sales_order.freezed.dart';
part 'sales_order.g.dart';

@freezed
class SalesOrder with _$SalesOrder {
  const factory SalesOrder({
    required String uuid,
    required String organizationId,
    required String orderNumber,
    required String customerId,
    String? warehouseId,
    required DateTime orderDate,
    DateTime? expectedDate,
    @Default('draft') String status,
    @Default(0.0) double subtotal,
    @Default(0.0) double taxAmount,
    @Default(0.0) double discountAmount,
    @Default(0.0) double totalAmount,
    String? notes,
    String? createdBy,
    required DateTime createdAt,
    required DateTime updatedAt,
    @Default([]) List<SalesOrderLine> lines,
  }) = _SalesOrder;

  factory SalesOrder.fromJson(Map<String, dynamic> json) => _$SalesOrderFromJson(json);
}

@freezed
class SalesOrderLine with _$SalesOrderLine {
  const factory SalesOrderLine({
    required String uuid,
    required String organizationId,
    required String salesOrderId,
    required String productId,
    required double quantity,
    required double unitPrice,
    @Default(0.0) double discountPercent,
    @Default(0.0) double discountAmount,
    @Default(0.0) double taxRate,
    @Default(0.0) double taxAmount,
    required double lineTotal,
    required int lineNumber,
    required DateTime createdAt,
    required DateTime updatedAt,
  }) = _SalesOrderLine;

  factory SalesOrderLine.fromJson(Map<String, dynamic> json) => _$SalesOrderLineFromJson(json);
}

@freezed
class SalesOrderCreate with _$SalesOrderCreate {
  const factory SalesOrderCreate({
    required String organizationId,
    required String customerId,
    String? warehouseId,
    required DateTime orderDate,
    DateTime? expectedDate,
    String? notes,
    required List<SalesOrderLineCreate> lines,
  }) = _SalesOrderCreate;

  factory SalesOrderCreate.fromJson(Map<String, dynamic> json) => _$SalesOrderCreateFromJson(json);
}

@freezed
class SalesOrderLineCreate with _$SalesOrderLineCreate {
  const factory SalesOrderLineCreate({
    required String productId,
    required double quantity,
    required double unitPrice,
    @Default(0.0) double discountPercent,
    @Default(0.0) double taxRate,
  }) = _SalesOrderLineCreate;

  factory SalesOrderLineCreate.fromJson(Map<String, dynamic> json) => _$SalesOrderLineCreateFromJson(json);
}