import 'package:freezed_annotation/freezed_annotation.dart';

part 'customer.freezed.dart';
part 'customer.g.dart';

@freezed
class Customer with _$Customer {
  const factory Customer({
    required String uuid,
    required String organizationId,
    required String code,
    required String name,
    String? contactPerson,
    String? email,
    String? phone,
    String? gstin,
    String? pan,
    String? billingAddressLine1,
    String? billingAddressLine2,
    String? billingCity,
    String? billingState,
    String? billingPincode,
    @Default('India') String billingCountry,
    String? shippingAddressLine1,
    String? shippingAddressLine2,
    String? shippingCity,
    String? shippingState,
    String? shippingPincode,
    @Default('India') String shippingCountry,
    String? paymentTermsId,
    @Default(0.0) double creditLimit,
    @Default(0.0) double outstandingAmount,
    @Default(true) bool isActive,
    required DateTime createdAt,
    required DateTime updatedAt,
  }) = _Customer;

  factory Customer.fromJson(Map<String, dynamic> json) => _$CustomerFromJson(json);
}

@freezed
class CustomerCreate with _$CustomerCreate {
  const factory CustomerCreate({
    required String organizationId,
    required String code,
    required String name,
    String? contactPerson,
    String? email,
    String? phone,
    String? gstin,
    String? pan,
    String? billingAddressLine1,
    String? billingAddressLine2,
    String? billingCity,
    String? billingState,
    String? billingPincode,
    String? billingCountry,
    String? shippingAddressLine1,
    String? shippingAddressLine2,
    String? shippingCity,
    String? shippingState,
    String? shippingPincode,
    String? shippingCountry,
    String? paymentTermsId,
    @Default(0.0) double creditLimit,
  }) = _CustomerCreate;

  factory CustomerCreate.fromJson(Map<String, dynamic> json) => _$CustomerCreateFromJson(json);
}