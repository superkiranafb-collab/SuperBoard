import 'package:freezed_annotation/freezed_annotation.dart';

part 'organization.freezed.dart';
part 'organization.g.dart';

@freezed
class Organization with _$Organization {
  const factory Organization({
    required String uuid,
    required String name,
    String? legalName,
    String? gstin,
    String? pan,
    String? cin,
    String? addressLine1,
    String? addressLine2,
    String? city,
    String? state,
    String? pincode,
    @Default('India') String country,
    String? phone,
    String? email,
    String? website,
    String? logoUrl,
    @Default(true) bool isActive,
    required DateTime createdAt,
    required DateTime updatedAt,
  }) = _Organization;

  factory Organization.fromJson(Map<String, dynamic> json) => _$OrganizationFromJson(json);
}

@freezed
class OrganizationCreate with _$OrganizationCreate {
  const factory OrganizationCreate({
    required String name,
    String? legalName,
    String? gstin,
    String? pan,
    String? cin,
    String? addressLine1,
    String? addressLine2,
    String? city,
    String? state,
    String? pincode,
    String? country,
    String? phone,
    String? email,
    String? website,
  }) = _OrganizationCreate;

  factory OrganizationCreate.fromJson(Map<String, dynamic> json) => _$OrganizationCreateFromJson(json);
}