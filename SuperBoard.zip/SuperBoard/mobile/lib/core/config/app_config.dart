import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:dio/dio.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:drift/drift.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:sqlite3_flutter_libs/sqlite3_flutter_libs.dart';
import 'package:sqlite3/sqlite3.dart';
import 'package:superboard_mobile/data/database/app_database.dart';

class AppConfig {
  static const String _baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:8000/api/v1',
  );
  
  static const String _wsUrl = String.fromEnvironment(
    'WS_BASE_URL',
    defaultValue: 'ws://10.0.2.2:8000/ws',
  );
  
  static late final FlutterSecureStorage _secureStorage;
  static late final Dio _dio;
  static late final Connectivity _connectivity;
  static late final AppDatabase _database;
  
  static String get baseUrl => _baseUrl;
  static String get wsUrl => _wsUrl;
  static FlutterSecureStorage get secureStorage => _secureStorage;
  static Dio get dio => _dio;
  static Connectivity get connectivity => _connectivity;
  static AppDatabase get database => _database;
  
  static Future<void> initialize() async {
    _secureStorage = const FlutterSecureStorage(
      aOptions: AndroidOptions(encryptedSharedPreferences: true),
      iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock_this_device),
    );
    
    _dio = Dio(BaseOptions(
      baseUrl: _baseUrl,
      connectTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
      sendTimeout: const Duration(seconds: 30),
      headers: {'Content-Type': 'application/json'},
    ));
    
    _dio.interceptors.add(LogInterceptor(
      requestBody: true,
      responseBody: true,
      requestHeader: false,
      responseHeader: false,
    ));
    
    _connectivity = Connectivity();
    
    _database = await _initDatabase();
  }
  
  static Future<AppDatabase> _initDatabase() async {
    final dbFolder = await getApplicationDocumentsDirectory();
    final file = File(p.join(dbFolder.path, 'superboard.db'));
    
    if (sqlite3.runtimeType.toString().contains('Sqlite3Factory')) {
      sqlite3.open.overrideFor(file.path, () => sqlite3.openV2(
        file.path,
        SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX,
      ));
    }
    
    return AppDatabase(NativeDatabase.createInBackground(file));
  }
  
  static void setAuthToken(String? token) {
    if (token != null) {
      _dio.options.headers['Authorization'] = 'Bearer $token';
    } else {
      _dio.options.headers.remove('Authorization');
    }
  }
  
  static Future<void> clearAuth() async {
    await _secureStorage.delete(key: 'access_token');
    await _secureStorage.delete(key: 'refresh_token');
    _dio.options.headers.remove('Authorization');
  }
}