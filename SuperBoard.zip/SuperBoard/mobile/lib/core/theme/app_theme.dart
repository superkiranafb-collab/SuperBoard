import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const Color primaryColor = Color(0xFF1E3A8A);
  static const Color primaryLight = Color(0xFF3B82F6);
  static const Color primaryDark = Color(0xFF1E40AF);
  static const Color secondaryColor = Color(0xFF059669);
  static const Color accentColor = Color(0xFFF59E0B);
  static const Color errorColor = Color(0xFFDC2626);
  static const Color surfaceColor = Color(0xFFF8FAFC);
  static const Color backgroundColor = Color(0xFFFFFFFF);
  static const Color onPrimary = Color(0xFFFFFFFF);
  static const Color onSurface = Color(0xFF0F172A);
  static const Color onBackground = Color(0xFF0F172A);
  static const Color dividerColor = Color(0xFFE2E8F0);
  
  static const Color successGreen = Color(0xFF10B981);
  static const Color warningOrange = Color(0xFFF59E0B);
  static const Color infoBlue = Color(0xFF3B82F6);
  
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: const ColorScheme.light(
        primary: primaryColor,
        primaryContainer: primaryLight,
        secondary: secondaryColor,
        secondaryContainer: Color(0xFFD1FAE5),
        tertiary: accentColor,
        tertiaryContainer: Color(0xFFFEF3C7),
        error: errorColor,
        errorContainer: Color(0xFFFEF2F2),
        surface: surfaceColor,
        onSurface: onSurface,
        onPrimary: onPrimary,
        onSecondary: onPrimary,
        onTertiary: onPrimary,
        onError: onPrimary,
        outline: dividerColor,
        outlineVariant: Color(0xFFCBD5E1),
        shadow: Color(0x1A0F172A),
      ),
      textTheme: GoogleFonts.interTextTheme().copyWith(
        displayLarge: GoogleFonts.inter(fontSize: 57, fontWeight: FontWeight.w700, letterSpacing: -0.25, color: onSurface),
        displayMedium: GoogleFonts.inter(fontSize: 45, fontWeight: FontWeight.w700, letterSpacing: 0, color: onSurface),
        displaySmall: GoogleFonts.inter(fontSize: 36, fontWeight: FontWeight.w600, letterSpacing: 0, color: onSurface),
        headlineLarge: GoogleFonts.inter(fontSize: 32, fontWeight: FontWeight.w600, letterSpacing: 0, color: onSurface),
        headlineMedium: GoogleFonts.inter(fontSize: 28, fontWeight: FontWeight.w600, letterSpacing: 0, color: onSurface),
        headlineSmall: GoogleFonts.inter(fontSize: 24, fontWeight: FontWeight.w600, letterSpacing: 0, color: onSurface),
        titleLarge: GoogleFonts.inter(fontSize: 22, fontWeight: FontWeight.w500, letterSpacing: 0, color: onSurface),
        titleMedium: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w500, letterSpacing: 0.15, color: onSurface),
        titleSmall: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 0.1, color: onSurface),
        bodyLarge: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w400, letterSpacing: 0.5, color: onSurface),
        bodyMedium: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400, letterSpacing: 0.25, color: onSurface),
        bodySmall: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w400, letterSpacing: 0.4, color: onSurface.withOpacity(0.7)),
        labelLarge: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 0.1, color: onPrimary),
        labelMedium: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w500, letterSpacing: 0.5, color: onSurface),
        labelSmall: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w500, letterSpacing: 0.5, color: onSurface.withOpacity(0.7)),
      ),
      appBarTheme: AppBarTheme(
        centerTitle: false,
        elevation: 0,
        scrolledUnderElevation: 1,
        backgroundColor: backgroundColor,
        foregroundColor: onSurface,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: GoogleFonts.inter(fontSize: 20, fontWeight: FontWeight.w600, color: onSurface),
        toolbarTextStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w500, color: onSurface),
        iconTheme: const IconThemeData(color: onSurface, size: 24),
        actionsIconTheme: const IconThemeData(color: onSurface, size: 24),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        color: surfaceColor,
        surfaceTintColor: Colors.transparent,
        margin: EdgeInsets.zero,
        clipBehavior: Clip.antiAlias,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          elevation: 0,
          backgroundColor: primaryColor,
          foregroundColor: onPrimary,
          disabledBackgroundColor: primaryColor.withOpacity(0.4),
          disabledForegroundColor: onPrimary.withOpacity(0.6),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          textStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600, letterSpacing: 0.1),
          minimumSize: const Size(88, 48),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: primaryColor,
          foregroundColor: onPrimary,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          textStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: primaryColor,
          side: const BorderSide(color: primaryColor, width: 1.5),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          textStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: primaryColor,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          textStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w500),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surfaceColor,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: dividerColor, width: 1),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: dividerColor, width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: primaryColor, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: errorColor, width: 1),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: errorColor, width: 2),
        ),
        disabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: dividerColor.withOpacity(0.5), width: 1),
        ),
        labelStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400, color: onSurface.withOpacity(0.6)),
        hintStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400, color: onSurface.withOpacity(0.4)),
        errorStyle: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w400, color: errorColor),
        floatingLabelStyle: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w500, color: primaryColor),
        prefixIconColor: onSurface.withOpacity(0.5),
        suffixIconColor: onSurface.withOpacity(0.5),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: primaryColor.withOpacity(0.1),
        disabledColor: primaryColor.withOpacity(0.05),
        selectedColor: primaryColor.withOpacity(0.2),
        secondarySelectedColor: secondaryColor.withOpacity(0.2),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        labelStyle: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w500, color: primaryColor),
        secondaryLabelStyle: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w500, color: onPrimary),
        brightness: Brightness.light,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        side: BorderSide.none,
      ),
      dividerTheme: DividerThemeData(
        color: dividerColor,
        thickness: 1,
        space: 1,
      ),
      listTileTheme: ListTileThemeData(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        tileColor: Colors.transparent,
        selectedTileColor: primaryColor.withOpacity(0.1),
        iconColor: onSurface.withOpacity(0.6),
        textColor: onSurface,
        titleTextStyle: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w500, color: onSurface),
        subtitleTextStyle: GoogleFonts.inter(fontSize: 13, fontWeight: FontWeight.w400, color: onSurface.withOpacity(0.6)),
        leadingAndTrailingTextStyle: GoogleFonts.inter(fontSize: 13, fontWeight: FontWeight.w400, color: onSurface.withOpacity(0.6)),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: surfaceColor,
        selectedItemColor: primaryColor,
        unselectedItemColor: onSurface.withOpacity(0.5),
        selectedLabelStyle: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w500),
        unselectedLabelStyle: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w400),
        type: BottomNavigationBarType.fixed,
        elevation: 8,
        surfaceTintColor: Colors.transparent,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: surfaceColor,
        indicatorColor: primaryColor.withOpacity(0.1),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, color: primaryColor);
          }
          return GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w400, color: onSurface.withOpacity(0.6));
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return IconThemeData(color: primaryColor, size: 24);
          }
          return IconThemeData(color: onSurface.withOpacity(0.6), size: 24);
        }),
        height: 64,
        surfaceTintColor: Colors.transparent,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: backgroundColor,
        surfaceTintColor: Colors.transparent,
        elevation: 24,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        titleTextStyle: GoogleFonts.inter(fontSize: 20, fontWeight: FontWeight.w600, color: onSurface),
        contentTextStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400, color: onSurface),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: backgroundColor,
        surfaceTintColor: Colors.transparent,
        elevation: 24,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
        modalBackgroundColor: backgroundColor,
        clipBehavior: Clip.antiAlias,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: onSurface,
        contentTextStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400, color: onPrimary),
        actionTextColor: accentColor,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        elevation: 8,
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: primaryColor,
        foregroundColor: onPrimary,
        elevation: 4,
        focusElevation: 6,
        hoverElevation: 6,
        highlightElevation: 8,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        extendedTextStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600),
      ),
      tabBarTheme: TabBarThemeData(
        labelColor: primaryColor,
        unselectedLabelColor: onSurface.withOpacity(0.5),
        labelStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600),
        unselectedLabelStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400),
        indicator: UnderlineTabIndicator(
          borderSide: const BorderSide(color: primaryColor, width: 3),
          borderRadius: BorderRadius.circular(2),
          insets: const EdgeInsets.symmetric(horizontal: 16),
        ),
        dividerColor: dividerColor,
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: primaryColor,
        linearTrackColor: Color(0xFFDBEAFE),
        circularTrackColor: Color(0xFFDBEAFE),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return primaryColor;
          return onSurface.withOpacity(0.4);
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return primaryColor.withOpacity(0.3);
          return onSurface.withOpacity(0.15);
        }),
        trackOutlineColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return primaryColor;
          return dividerColor;
        }),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return primaryColor;
          return Colors.transparent;
        }),
        checkColor: WidgetStateProperty.all(onPrimary),
        side: BorderSide(color: dividerColor, width: 1.5),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      ),
      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return primaryColor;
          return onSurface.withOpacity(0.4);
        }),
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: primaryColor,
        inactiveTrackColor: primaryColor.withOpacity(0.2),
        thumbColor: primaryColor,
        overlayColor: primaryColor.withOpacity(0.15),
        valueIndicatorColor: primaryColor,
        valueIndicatorTextStyle: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w500, color: onPrimary),
      ),
      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: onSurface.withOpacity(0.9),
          borderRadius: BorderRadius.circular(8),
        ),
        textStyle: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w400, color: onPrimary),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        preferBelow: true,
        verticalOffset: 8,
      ),
      extensions: <ThemeExtension<dynamic>>[
        _CustomColors.light,
      ],
    );
  }
  
  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFF60A5FA),
        primaryContainer: Color(0xFF1E3A8A),
        secondary: Color(0xFF34D399),
        secondaryContainer: Color(0xFF064E3B),
        tertiary: Color(0xFFFBBF24),
        tertiaryContainer: Color(0xFF78350F),
        error: Color(0xFFF87171),
        errorContainer: Color(0xFF7F1D1D),
        surface: Color(0xFF1E293B),
        onSurface: Color(0xFFF1F5F9),
        onPrimary: Color(0xFF0F172A),
        onSecondary: Color(0xFF0F172A),
        onTertiary: Color(0xFF0F172A),
        onError: Color(0xFF0F172A),
        outline: Color(0xFF334155),
        outlineVariant: Color(0xFF475569),
        shadow: Color(0x33000000),
      ),
      textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme).copyWith(
        displayLarge: GoogleFonts.inter(fontSize: 57, fontWeight: FontWeight.w700, letterSpacing: -0.25, color: Color(0xFFF1F5F9)),
        displayMedium: GoogleFonts.inter(fontSize: 45, fontWeight: FontWeight.w700, letterSpacing: 0, color: Color(0xFFF1F5F9)),
        displaySmall: GoogleFonts.inter(fontSize: 36, fontWeight: FontWeight.w600, letterSpacing: 0, color: Color(0xFFF1F5F9)),
        headlineLarge: GoogleFonts.inter(fontSize: 32, fontWeight: FontWeight.w600, letterSpacing: 0, color: Color(0xFFF1F5F9)),
        headlineMedium: GoogleFonts.inter(fontSize: 28, fontWeight: FontWeight.w600, letterSpacing: 0, color: Color(0xFFF1F5F9)),
        headlineSmall: GoogleFonts.inter(fontSize: 24, fontWeight: FontWeight.w600, letterSpacing: 0, color: Color(0xFFF1F5F9)),
        titleLarge: GoogleFonts.inter(fontSize: 22, fontWeight: FontWeight.w500, letterSpacing: 0, color: Color(0xFFF1F5F9)),
        titleMedium: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w500, letterSpacing: 0.15, color: Color(0xFFF1F5F9)),
        titleSmall: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 0.1, color: Color(0xFFF1F5F9)),
        bodyLarge: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w400, letterSpacing: 0.5, color: Color(0xFFF1F5F9)),
        bodyMedium: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400, letterSpacing: 0.25, color: Color(0xFFF1F5F9)),
        bodySmall: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w400, letterSpacing: 0.4, color: Color(0xFF94A3B8)),
        labelLarge: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 0.1, color: Color(0xFF0F172A)),
        labelMedium: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w500, letterSpacing: 0.5, color: Color(0xFFF1F5F9)),
        labelSmall: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w500, letterSpacing: 0.5, color: Color(0xFF94A3B8)),
      ),
      appBarTheme: AppBarTheme(
        centerTitle: false,
        elevation: 0,
        scrolledUnderElevation: 1,
        backgroundColor: Color(0xFF0F172A),
        foregroundColor: Color(0xFFF1F5F9),
        surfaceTintColor: Colors.transparent,
        titleTextStyle: GoogleFonts.inter(fontSize: 20, fontWeight: FontWeight.w600, color: Color(0xFFF1F5F9)),
        toolbarTextStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w500, color: Color(0xFFF1F5F9)),
        iconTheme: const IconThemeData(color: Color(0xFFF1F5F9), size: 24),
        actionsIconTheme: const IconThemeData(color: Color(0xFFF1F5F9), size: 24),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        color: Color(0xFF1E293B),
        surfaceTintColor: Colors.transparent,
        margin: EdgeInsets.zero,
        clipBehavior: Clip.antiAlias,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          elevation: 0,
          backgroundColor: Color(0xFF3B82F6),
          foregroundColor: Color(0xFF0F172A),
          disabledBackgroundColor: Color(0xFF3B82F6).withOpacity(0.4),
          disabledForegroundColor: Color(0xFF0F172A).withOpacity(0.6),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          textStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600, letterSpacing: 0.1),
          minimumSize: const Size(88, 48),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: Color(0xFF3B82F6),
          foregroundColor: Color(0xFF0F172A),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          textStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: Color(0xFF60A5FA),
          side: const BorderSide(color: Color(0xFF60A5FA), width: 1.5),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          textStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: Color(0xFF60A5FA),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          textStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w500),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Color(0xFF1E293B),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFF334155), width: 1),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFF334155), width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFF60A5FA), width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFF87171), width: 1),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFFF87171), width: 2),
        ),
        disabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Color(0xFF1E293B), width: 1),
        ),
        labelStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xFF94A3B8)),
        hintStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xFF64748B)),
        errorStyle: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w400, color: Color(0xFFF87171)),
        floatingLabelStyle: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w500, color: Color(0xFF60A5FA)),
        prefixIconColor: Color(0xFF94A3B8),
        suffixIconColor: Color(0xFF94A3B8),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: Color(0xFF1E3A8A).withOpacity(0.3),
        disabledColor: Color(0xFF1E3A8A).withOpacity(0.1),
        selectedColor: Color(0xFF1E3A8A).withOpacity(0.5),
        secondarySelectedColor: Color(0xFF059669).withOpacity(0.3),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        labelStyle: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w500, color: Color(0xFF60A5FA)),
        secondaryLabelStyle: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w500, color: Color(0xFF0F172A)),
        brightness: Brightness.dark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        side: BorderSide.none,
      ),
      dividerTheme: DividerThemeData(
        color: Color(0xFF334155),
        thickness: 1,
        space: 1,
      ),
      listTileTheme: ListTileThemeData(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        tileColor: Colors.transparent,
        selectedTileColor: Color(0xFF1E3A8A).withOpacity(0.3),
        iconColor: Color(0xFF94A3B8),
        textColor: Color(0xFFF1F5F9),
        titleTextStyle: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w500, color: Color(0xFFF1F5F9)),
        subtitleTextStyle: GoogleFonts.inter(fontSize: 13, fontWeight: FontWeight.w400, color: Color(0xFF94A3B8)),
        leadingAndTrailingTextStyle: GoogleFonts.inter(fontSize: 13, fontWeight: FontWeight.w400, color: Color(0xFF94A3B8)),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: Color(0xFF1E293B),
        selectedItemColor: Color(0xFF60A5FA),
        unselectedItemColor: Color(0xFF94A3B8),
        selectedLabelStyle: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w500),
        unselectedLabelStyle: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w400),
        type: BottomNavigationBarType.fixed,
        elevation: 8,
        surfaceTintColor: Colors.transparent,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: Color(0xFF1E293B),
        indicatorColor: Color(0xFF1E3A8A).withOpacity(0.3),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, color: Color(0xFF60A5FA));
          }
          return GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w400, color: Color(0xFF94A3B8));
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return IconThemeData(color: Color(0xFF60A5FA), size: 24);
          }
          return IconThemeData(color: Color(0xFF94A3B8), size: 24);
        }),
        height: 64,
        surfaceTintColor: Colors.transparent,
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: Color(0xFF1E293B),
        surfaceTintColor: Colors.transparent,
        elevation: 24,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        titleTextStyle: GoogleFonts.inter(fontSize: 20, fontWeight: FontWeight.w600, color: Color(0xFFF1F5F9)),
        contentTextStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xFFF1F5F9)),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: Color(0xFF1E293B),
        surfaceTintColor: Colors.transparent,
        elevation: 24,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
        modalBackgroundColor: Color(0xFF1E293B),
        clipBehavior: Clip.antiAlias,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: Color(0xFFF1F5F9),
        contentTextStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400, color: Color(0xFF0F172A)),
        actionTextColor: Color(0xFFFBBF24),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        elevation: 8,
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: Color(0xFF3B82F6),
        foregroundColor: Color(0xFF0F172A),
        elevation: 4,
        focusElevation: 6,
        hoverElevation: 6,
        highlightElevation: 8,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        extendedTextStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600),
      ),
      tabBarTheme: TabBarThemeData(
        labelColor: Color(0xFF60A5FA),
        unselectedLabelColor: Color(0xFF94A3B8),
        labelStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600),
        unselectedLabelStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w400),
        indicator: UnderlineTabIndicator(
          borderSide: const BorderSide(color: Color(0xFF60A5FA), width: 3),
          borderRadius: BorderRadius.circular(2),
          insets: const EdgeInsets.symmetric(horizontal: 16),
        ),
        dividerColor: Color(0xFF334155),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: Color(0xFF60A5FA),
        linearTrackColor: Color(0xFF1E3A8A),
        circularTrackColor: Color(0xFF1E3A8A),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return Color(0xFF3B82F6);
          return Color(0xFF94A3B8);
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return Color(0xFF3B82F6).withOpacity(0.3);
          return Color(0xFF334155);
        }),
        trackOutlineColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return Color(0xFF3B82F6);
          return Color(0xFF334155);
        }),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return Color(0xFF3B82F6);
          return Colors.transparent;
        }),
        checkColor: WidgetStateProperty.all(Color(0xFF0F172A)),
        side: BorderSide(color: Color(0xFF334155), width: 1.5),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      ),
      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return Color(0xFF3B82F6);
          return Color(0xFF94A3B8);
        }),
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: Color(0xFF3B82F6),
        inactiveTrackColor: Color(0xFF3B82F6).withOpacity(0.2),
        thumbColor: Color(0xFF3B82F6),
        overlayColor: Color(0xFF3B82F6).withOpacity(0.15),
        valueIndicatorColor: Color(0xFF3B82F6),
        valueIndicatorTextStyle: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w500, color: Color(0xFF0F172A)),
      ),
      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: Color(0xFFF1F5F9).withOpacity(0.9),
          borderRadius: BorderRadius.circular(8),
        ),
        textStyle: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w400, color: Color(0xFF0F172A)),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        preferBelow: true,
        verticalOffset: 8,
      ),
      extensions: <ThemeExtension<dynamic>>[
        _CustomColors.dark,
      ],
    );
  }
}

class _CustomColors extends ThemeExtension<_CustomColors> {
  final Color successLight;
  final Color successDark;
  final Color warningLight;
  final Color warningDark;
  final Color infoLight;
  final Color infoDark;
  final Color pendingLight;
  final Color pendingDark;
  final Color approvedLight;
  final Color approvedDark;
  final Color rejectedLight;
  final Color rejectedDark;
  
  const _CustomColors._({
    required this.successLight,
    required this.successDark,
    required this.warningLight,
    required this.warningDark,
    required this.infoLight,
    required this.infoDark,
    required this.pendingLight,
    required this.pendingDark,
    required this.approvedLight,
    required this.approvedDark,
    required this.rejectedLight,
    required this.rejectedDark,
  });
  
  static const _CustomColors light = _CustomColors._(
    successLight: Color(0xFFD1FAE5),
    successDark: Color(0xFF065F46),
    warningLight: Color(0xFFFEF3C7),
    warningDark: Color(0xFF92400E),
    infoLight: Color(0xFFDBEAFE),
    infoDark: Color(0xFF1E40AF),
    pendingLight: Color(0xFFFEF3C7),
    pendingDark: Color(0xFF92400E),
    approvedLight: Color(0xFFD1FAE5),
    approvedDark: Color(0xFF065F46),
    rejectedLight: Color(0xFFFEF2F2),
    rejectedDark: Color(0xFF991B1B),
  );
  
  static const _CustomColors dark = _CustomColors._(
    successLight: Color(0xFF064E3B),
    successDark: Color(0xFFD1FAE5),
    warningLight: Color(0xFF78350F),
    warningDark: Color(0xFFFEF3C7),
    infoLight: Color(0xFF1E3A8A),
    infoDark: Color(0xFFDBEAFE),
    pendingLight: Color(0xFF78350F),
    pendingDark: Color(0xFFFEF3C7),
    approvedLight: Color(0xFF064E3B),
    approvedDark: Color(0xFFD1FAE5),
    rejectedLight: Color(0xFF7F1D1D),
    rejectedDark: Color(0xFFFEF2F2),
  );
  
  @override
  _CustomColors copyWith({
    Color? successLight,
    Color? successDark,
    Color? warningLight,
    Color? warningDark,
    Color? infoLight,
    Color? infoDark,
    Color? pendingLight,
    Color? pendingDark,
    Color? approvedLight,
    Color? approvedDark,
    Color? rejectedLight,
    Color? rejectedDark,
  }) {
    return _CustomColors._(
      successLight: successLight ?? this.successLight,
      successDark: successDark ?? this.successDark,
      warningLight: warningLight ?? this.warningLight,
      warningDark: warningDark ?? this.warningDark,
      infoLight: infoLight ?? this.infoLight,
      infoDark: infoDark ?? this.infoDark,
      pendingLight: pendingLight ?? this.pendingLight,
      pendingDark: pendingDark ?? this.pendingDark,
      approvedLight: approvedLight ?? this.approvedLight,
      approvedDark: approvedDark ?? this.approvedDark,
      rejectedLight: rejectedLight ?? this.rejectedLight,
      rejectedDark: rejectedDark ?? this.rejectedDark,
    );
  }
  
  @override
  _CustomColors lerp(ThemeExtension<_CustomColors>? other, double t) {
    if (other is! _CustomColors) return this;
    return _CustomColors._(
      successLight: Color.lerp(successLight, other.successLight, t)!,
      successDark: Color.lerp(successDark, other.successDark, t)!,
      warningLight: Color.lerp(warningLight, other.warningLight, t)!,
      warningDark: Color.lerp(warningDark, other.warningDark, t)!,
      infoLight: Color.lerp(infoLight, other.infoLight, t)!,
      infoDark: Color.lerp(infoDark, other.infoDark, t)!,
      pendingLight: Color.lerp(pendingLight, other.pendingLight, t)!,
      pendingDark: Color.lerp(pendingDark, other.pendingDark, t)!,
      approvedLight: Color.lerp(approvedLight, other.approvedLight, t)!,
      approvedDark: Color.lerp(approvedDark, other.approvedDark, t)!,
      rejectedLight: Color.lerp(rejectedLight, other.rejectedLight, t)!,
      rejectedDark: Color.lerp(rejectedDark, other.rejectedDark, t)!,
    );
  }
}